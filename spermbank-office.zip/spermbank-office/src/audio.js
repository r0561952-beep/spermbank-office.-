// ===== Процедурный звук на WebAudio (без файлов) =====
import { S } from './state.js';

let ctx = null, master = null, noiseBuf = null, fanNode = null, fanGain = null;

export function initAudio() {
  if (ctx) { if (ctx.state === 'suspended') ctx.resume(); return; }
  try {
    ctx = new (window.AudioContext || window.webkitAudioContext)();
    master = ctx.createGain();
    master.gain.value = S.settings.sound ? 0.55 : 0;
    master.connect(ctx.destination);
    noiseBuf = ctx.createBuffer(1, ctx.sampleRate * 2, ctx.sampleRate);
    const d = noiseBuf.getChannelData(0);
    for (let i = 0; i < d.length; i++) d[i] = Math.random() * 2 - 1;
    // гул вентилятора
    fanNode = ctx.createBufferSource();
    fanNode.buffer = noiseBuf; fanNode.loop = true;
    const lp = ctx.createBiquadFilter(); lp.type = 'lowpass'; lp.frequency.value = 420;
    fanGain = ctx.createGain(); fanGain.gain.value = 0;
    fanNode.connect(lp); lp.connect(fanGain); fanGain.connect(master);
    fanNode.start();
  } catch (e) { ctx = null; }
}

export function setSoundOn(on) {
  S.settings.sound = on;
  if (master) master.gain.value = on ? 0.55 : 0;
}
export function suspendAudio() { if (ctx && ctx.state === 'running') ctx.suspend(); }
export function resumeAudio() { if (ctx && ctx.state === 'suspended') ctx.resume(); }

export function setFanHum(level) {
  if (!fanGain) return;
  fanGain.gain.setTargetAtTime(level * 0.09, ctx.currentTime, 0.3);
}

function tone(freq, dur, type = 'sine', vol = 0.2, when = 0, slideTo = null) {
  if (!ctx || !S.settings.sound) return;
  const t = ctx.currentTime + when;
  const o = ctx.createOscillator(), g = ctx.createGain();
  o.type = type; o.frequency.setValueAtTime(freq, t);
  if (slideTo) o.frequency.exponentialRampToValueAtTime(slideTo, t + dur);
  g.gain.setValueAtTime(0.0001, t);
  g.gain.exponentialRampToValueAtTime(vol, t + 0.01);
  g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
  o.connect(g); g.connect(master);
  o.start(t); o.stop(t + dur + 0.05);
}

function noise(dur, vol = 0.2, when = 0, freq = 2000, type = 'bandpass', q = 1) {
  if (!ctx || !S.settings.sound) return;
  const t = ctx.currentTime + when;
  const s = ctx.createBufferSource(); s.buffer = noiseBuf;
  const f = ctx.createBiquadFilter(); f.type = type; f.frequency.value = freq; f.Q.value = q;
  const g = ctx.createGain();
  g.gain.setValueAtTime(vol, t); g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
  s.connect(f); f.connect(g); g.connect(master);
  s.start(t, Math.random()); s.stop(t + dur + 0.05);
}

export const sfx = {
  click() { noise(0.03, 0.25, 0, 3500); tone(1800, 0.02, 'square', 0.03); },
  tap() { tone(660, 0.05, 'triangle', 0.08); },
  key() { noise(0.025, 0.15, 0, 4000 + Math.random() * 2000); },
  msg() { tone(880, 0.09, 'sine', 0.15); tone(1320, 0.12, 'sine', 0.12, 0.08); },
  notify() { tone(660, 0.1, 'sine', 0.15); tone(990, 0.1, 'sine', 0.15, 0.1); tone(1320, 0.18, 'sine', 0.13, 0.2); },
  sent() { tone(500, 0.08, 'sine', 0.08, 0, 900); },
  coin() { tone(988, 0.08, 'square', 0.07); tone(1319, 0.25, 'square', 0.07, 0.08); },
  cash() { [0, 0.06, 0.12].forEach((w, i) => tone(1200 + i * 300, 0.12, 'triangle', 0.1, w)); noise(0.3, 0.12, 0.15, 6000, 'highpass'); },
  error() { tone(180, 0.25, 'sawtooth', 0.1); tone(140, 0.3, 'sawtooth', 0.1, 0.12); },
  fail() { tone(400, 0.2, 'triangle', 0.12, 0, 200); tone(260, 0.35, 'triangle', 0.12, 0.18, 120); },
  success() { [523, 659, 784, 1047].forEach((f, i) => tone(f, 0.18, 'triangle', 0.12, i * 0.08)); },
  levelup() { [523, 659, 784, 1047, 1319].forEach((f, i) => tone(f, 0.25, 'square', 0.06, i * 0.1)); },
  ding() { tone(2093, 1.2, 'sine', 0.18); tone(4186, 0.6, 'sine', 0.05); },
  slurp() { noise(0.5, 0.15, 0, 900, 'bandpass', 3); tone(300, 0.4, 'sine', 0.04, 0.05, 500); },
  water() { for (let i = 0; i < 6; i++) tone(700 + Math.random() * 600, 0.08, 'sine', 0.06, i * 0.07, 300); },
  meow() { tone(700, 0.35, 'sawtooth', 0.05, 0, 1100); tone(1100, 0.3, 'sawtooth', 0.04, 0.3, 600); },
  whoosh() { noise(0.4, 0.15, 0, 800, 'bandpass', 0.7); },
  knock() { noise(0.06, 0.4, 0, 300, 'lowpass'); noise(0.06, 0.4, 0.15, 300, 'lowpass'); },
  bsod() { tone(110, 0.8, 'square', 0.12); tone(55, 1.2, 'square', 0.1, 0.1); },
  ring() {
    for (let k = 0; k < 2; k++) for (let i = 0; i < 10; i++) {
      tone(i % 2 ? 480 : 440, 0.05, 'square', 0.06, k * 0.6 + i * 0.05);
    }
  },
  boot(os) {
    const seqs = {
      '95': [[392, 0], [523, 0.25], [659, 0.5], [784, 0.75], [1047, 1.0]],
      xp: [[622, 0], [415, 0.2], [466, 0.45], [622, 0.7], [932, 1.0]],
      '7': [[523, 0], [659, 0.2], [784, 0.4], [988, 0.6]],
      '11': [[784, 0], [1047, 0.15], [1319, 0.3]],
      q: [[220, 0], [330, 0.1], [440, 0.2], [660, 0.3], [880, 0.4], [1760, 0.5]],
    };
    (seqs[os] || seqs['95']).forEach(([f, w]) => { tone(f, 0.6, 'sine', 0.1, w); tone(f / 2, 0.6, 'triangle', 0.05, w); });
  },
  modem(dur = 4) {
    // имитация дозвона модема: гудок, набор номера, рукопожатие
    tone(425, 0.6, 'sine', 0.08);
    const digits = [697, 770, 852, 941];
    for (let i = 0; i < 7; i++) { tone(digits[i % 4], 0.07, 'sine', 0.08, 0.7 + i * 0.1); tone(1209 + (i % 3) * 127, 0.07, 'sine', 0.06, 0.7 + i * 0.1); }
    tone(2100, 0.5, 'sine', 0.06, 1.5);
    tone(1650, 0.3, 'sawtooth', 0.04, 2.1, 980);
    noise(Math.max(0.5, dur - 2.4), 0.12, 2.4, 1800, 'bandpass', 0.6);
    for (let i = 0; i < 8; i++) tone(1000 + Math.random() * 1500, 0.12, 'square', 0.025, 2.4 + i * 0.18);
  },
};

export function vibrate(ms) {
  try {
    if (window.AndroidApp && window.AndroidApp.vibrate) window.AndroidApp.vibrate(ms);
    else if (navigator.vibrate) navigator.vibrate(ms);
  } catch (e) { /* ignore */ }
}
