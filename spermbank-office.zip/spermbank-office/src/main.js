// ===== СПЕРМбанк: Офис — точка входа =====
import { S, bus, save, fmt, pick, clockStr, clamp, remotePing } from './state.js';
import { NETS, RANDOM_TIPS } from './data.js';
import { Scene } from './scene.js';
import { G } from './game.js';
import { CM } from './clients.js';
import { UI } from './ui.js';
import { OS } from './os.js';
import { initAudio, sfx, suspendAudio, resumeAudio, setFanHum } from './audio.js';

const $ = (s) => document.querySelector(s);
let coolerAt = -999;

function handleTap(a) {
  switch (a) {
    case 'pc': OS.enter(); break;
    case 'fan': G.toggleFan(); break;
    case 'phone':
      if (G.phone && !G.phone.answered) UI.answerCall();
      else { sfx.tap(); UI.toast('📞 Телефон молчит. Сюда звонят клиенты, начальник, мама… и мошенники'); }
      break;
    case 'mug': G.drink(); break;
    case 'bell': sfx.ding(); UI.coffeeMenu(); break;
    case 'waiter': UI.toast('🤵 Жорик: «Сию минуту, уже несу!»'); break;
    case 'plant': G.waterPlant(); break;
    case 'lamp': G.toggleLamp(); break;
    case 'cat': sfx.meow(); UI.toast('🐱 Кот удачи машет лапкой: +15% чаевых от довольных клиентов'); break;
    case 'router': sfx.tap(); UI.toast(`📶 ${NETS[S.net].name}: пинг ~${Math.round(remotePing())} мс. Улучшить — в «СПЕРМ.Маркете» на компьютере`); break;
    case 'w0': case 'w1': sfx.tap(); UI.workersPanel(); break;
    case 'clock': sfx.tap(); UI.toast(`🕐 Сейчас ${clockStr()}. Рабочий день — до 18:00`); break;
    case 'window': sfx.tap(); UI.toast(pick(['❄️ За окном снег. Скоро Новый год — и годовой отчёт…', '🏙 Вид на город. Где-то там клиенты ждут ответа.', '🌆 Красиво. Но работа сама себя не сделает.'])); break;
    case 'board': sfx.tap(); UI.toast('📋 «План на квартал. Дедлайн: вчера». Классика.'); break;
    case 'tree': sfx.success(); UI.toast('🎄 Ёлочка мигает. Коллеги грустят в 2 раза медленнее!'); break;
    case 'cooler':
      if (S.minute - coolerAt < 60) UI.toast('💧 Ты недавно пил воду. Загляни через часик');
      else { coolerAt = S.minute; S.energy = clamp(S.energy + 6, 0, 100); sfx.water(); UI.toast('💧 Глоток холодной воды: +6 бодрости', 'good'); }
      break;
    default: break;
  }
}

function updateHint() {
  let t = '';
  if (G.inOS || G.paused) t = '';
  else if (S.tutorial === 1) t = '👆 Нажми на монитор, чтобы сесть за компьютер. Проведи пальцем — осмотреться';
  else if (G.mug && S.energy < 60) t = '☕ Нажми на кружку, чтобы выпить кофе';
  else if (S.energy < 25 && !G.waiterBusy) t = '😴 Бодрость на исходе: нажми колокольчик 🔔 и закажи кофе';
  else if (S.fanStalled) t = '🌀 Вентилятор заглох — стукни по нему (нажми)';
  else if (!S.fanOn && S.heat > 50) t = '🌀 Компьютер греется — включи вентилятор (нажми на него)';
  else if (CM.waitingCount() > 0 && S.tutorial < 4) t = '💬 Клиенты ждут — садись за компьютер';
  UI.setHint(t);
}

function start() {
  try {
    Scene.init($('#game'));
  } catch (e) {
    console.error(e);
    $('#splash-status').textContent = '😢 Ваше устройство не поддерживает 3D-графику (WebGL).';
    return;
  }
  OS.init();
  G.paused = true;
  G.start();
  Scene.onTap = handleTap;

  $('#b-pc').onclick = () => OS.enter();
  $('#b-coffee').onclick = () => { sfx.ding(); UI.coffeeMenu(); };
  $('#b-team').onclick = () => { sfx.tap(); UI.workersPanel(); };
  $('#b-menu').onclick = () => { sfx.tap(); UI.menu(); };

  bus.on('toast', (t, type) => UI.toast(t, type));
  bus.on('paid', (c, reward) => { UI.floatAt('pc', '+' + fmt(reward)); if (S.tutorial === 3) S.tutorial = 4; });
  bus.on('workerIncome', (i, n) => { if (!G.inOS) UI.floatAt('w' + i, '+' + fmt(n), '#a5d6a7'); });
  bus.on('rankup', (r) => UI.rankUp(r));
  bus.on('ach', (a) => UI.toast(`🏆 Достижение: ${a.icon} ${a.name}`, 'ach', 4200));
  bus.on('phone', (ringing) => UI.showCall(ringing));
  bus.on('dayEnd', () => { if (OS.open) OS.exit(); setTimeout(() => UI.daySummary(), 500); });
  bus.on('newDay', () => UI.toast(`☀️ День ${S.day}! Новые цели — в «Почте» на компьютере`, 'good', 4000));
  bus.on('asleep', () => { $('#sleep').classList.remove('hidden'); });
  bus.on('wake', () => { $('#sleep').classList.add('hidden'); });

  let last = performance.now(), hudT = 0, tipT = 90;
  Scene.start(() => {
    const now = performance.now();
    let dt = (now - last) / 1000; last = now;
    if (dt > 0.1) dt = 0.1;
    G.update(dt);
    Scene.frame(dt);
    UI.updateLabels();
    hudT += dt;
    if (hudT > 0.2) { hudT = 0; UI.updateHUD(); updateHint(); }
    if (!G.paused && S.tutorial >= 4) { tipT -= dt; if (tipT <= 0) { tipT = 150; if (!G.inOS) UI.toast(pick(RANDOM_TIPS), 'info', 4000); } }
  });

  // Android: кнопка «Назад» и сворачивание
  window.onAndroidBack = () => {
    if (UI.stack.length) { UI.closeTop(); return true; }
    if (OS.open) { OS.back(); return true; }
    UI.menu();
    return true;
  };
  let wasPaused = false, hiddenNow = false;
  window.onAppPause = () => { if (hiddenNow) return; hiddenNow = true; wasPaused = G.paused; G.paused = true; save(); suspendAudio(); };
  window.onAppResume = () => { if (!hiddenNow) return; hiddenNow = false; G.paused = wasPaused; resumeAudio(); };
  document.addEventListener('visibilitychange', () => { if (document.hidden) window.onAppPause(); else window.onAppResume(); });
  window.addEventListener('beforeunload', save);

  $('#splash-status').textContent = S.tutorial === 0 ? 'Офис готов. Вас ждут!' : `С возвращением! День ${S.day}, ${S.money.toLocaleString('ru-RU')} ₽ на счету.`;
  const btn = $('#b-start');
  btn.textContent = S.tutorial === 0 ? 'Начать первую смену' : 'Продолжить смену';
  btn.classList.remove('hidden');
  btn.onclick = () => {
    initAudio();
    setFanHum(S.fanOn && !S.fanStalled ? (S.fan + 1) * 0.6 : 0);
    sfx.success();
    $('#splash').classList.add('fade');
    setTimeout(() => $('#splash').remove(), 500);
    if (S.tutorial === 0) UI.intro(() => { S.tutorial = 1; G.paused = false; CM.spawnT = 5; save(); });
    else { G.paused = false; if (S.tutorial < 1) S.tutorial = 1; }
    // на случай, если день закончился при прошлом закрытии
    if (S.minute >= 540) G.endDay();
  };
  // разблокировка звука при первом касании
  document.addEventListener('pointerdown', () => initAudio(), { once: true });
}

// отладка: открыть index.html#debug
if (location.hash.includes('debug')) window.__dbg = { S, G, CM, OS, UI, Scene, bus };

if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', start); else start();
