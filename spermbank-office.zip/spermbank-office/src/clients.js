// ===== Менеджер клиентов: очередь, диалоги, счета, терпение =====
import { S, bus, rand, randi, pick, shuffle, clamp, net, maxChats, rankIdx, rank, addMoney, addRep, online, has, fmt } from './state.js';
import { SCENARIOS, LEAVE_LINES, WAIT_LINES, THANKS_LINES } from './scenarios.js';
import { sfx, vibrate } from './audio.js';

let seq = 1;

function genId() { return `${randi(100, 999)} ${randi(100, 999)} ${randi(100, 999)}`; }

export const CM = {
  active: [],
  queue: [],
  spawnT: 5,
  recent: [],

  waitingCount() {
    return this.active.filter((c) => ['wait', 'invoice', 'remote', 'task'].includes(c.state)).length + this.queue.length;
  },
  liveCount() { return this.active.filter((c) => c.state !== 'done' && c.state !== 'left').length; },

  pickScenario(filter) {
    const r = rankIdx();
    let pool = SCENARIOS.filter((s) => (s.minRank || 0) <= r && (!filter || filter(s)));
    const fresh = pool.filter((s) => !this.recent.includes(s.id) && !this.active.some((c) => c.sc.id === s.id));
    if (fresh.length) pool = fresh;
    // VIP-клиенты реже
    const sc = pick(pool.filter((s) => !s.vip || Math.random() < 0.5)) || pick(pool);
    this.recent.push(sc.id);
    if (this.recent.length > 6) this.recent.shift();
    return sc;
  },

  spawn(force = false, sc = null) {
    sc = sc || this.pickScenario();
    const c = {
      id: seq++, sc, step: 0, mood: randi(50, 68), state: 'arrive', msgs: [], unread: 0,
      pending: null, pat: 0, maxPat: 0, warned: false, remoteId: null, opts: null, removeT: 0, reward: 0,
    };
    if (force || this.liveCount() < maxChats()) this.activate(c);
    else { c.qPat = 70; this.queue.push(c); }
    bus.emit('clients');
  },

  activate(c) {
    this.active.push(c);
    sfx.notify(); vibrate(40);
    this.sys(c, `${c.sc.av} ${c.sc.who} (${c.sc.org}) начал(а) чат`);
    this.say(c, c.sc.steps[0].c, 'wait');
    bus.emit('newclient', c);
  },

  patienceMax(state) {
    let p = state === 'remote' || state === 'task' ? 110 : 50;
    if (S.workers[1].lvl >= 10) p *= 1.5;
    return p;
  },

  push(c, from, text) {
    c.msgs.push({ from, text });
    if (c.msgs.length > 40) c.msgs.shift();
  },
  sys(c, text) { this.push(c, 'sys', text); },

  typingDelay(lines) {
    const len = lines.join(' ').length;
    return 0.5 + net().ping / 1000 * 1.4 + Math.min(1.8, len * 0.012);
  },

  // клиент «печатает», затем пишет строки и переходит в состояние
  say(c, lines, nextState, after) {
    lines = lines.filter(Boolean);
    c.state = 'typing';
    c.pending = {
      t: this.typingDelay(lines),
      fn: () => {
        lines.forEach((l) => this.push(c, 'c', l));
        if (lines.length) { c.unread++; sfx.msg(); }
        this.enter(c, nextState);
        if (after) after();
      },
    };
    bus.emit('clients');
  },

  enter(c, st) {
    c.state = st;
    c.warned = false;
    c.pat = c.maxPat = this.patienceMax(st);
    if (st === 'wait') {
      const step = c.sc.steps[c.step];
      c.opts = shuffle(step.o);
      let best = 0;
      c.opts.forEach((o, i) => { if (o[1] > c.opts[best][1]) best = i; });
      c.best = best;
    } else if (st === 'invoice') {
      this.sys(c, '💡 Клиент готов платить — выставьте счёт');
    } else if (st === 'remote') {
      this.sys(c, '🖥 Нужна удалённая помощь. Откройте «ДальнийСтол»');
    } else if (st === 'task') {
      this.sys(c, '🧮 Нужен расчёт. Нажмите «Выполнить расчёт»');
    } else if (st === 'left') {
      this.leave(c, true);
    }
    bus.emit('clients');
  },

  choose(c, i) {
    if (c.state !== 'wait' || !c.opts) return;
    const opt = c.opts[i];
    c.opts = null;
    sfx.sent();
    if (S.energy < 12) {
      c.state = 'yawn';
      this.sys(c, '😴 Вы зеваете и печатаете медленнее…');
      c.pending = { t: 1.6, fn: () => this.apply(c, opt) };
      bus.emit('clients');
      return;
    }
    this.apply(c, opt);
  },

  apply(c, opt) {
    const [text, delta, next, reply] = opt;
    this.push(c, 'me', text);
    c.mood = clamp(c.mood + delta, 0, 100);
    if (c.mood <= 0 && next !== 'fail') {
      this.say(c, [reply, pick(LEAVE_LINES)], 'left');
      return;
    }
    if (typeof next === 'number') {
      c.step = next;
      this.say(c, [reply, ...c.sc.steps[next].c], 'wait');
    } else if (next === 'pay') {
      this.say(c, [reply || 'Хорошо, выставляйте счёт.'], 'invoice');
    } else if (next === 'fail') {
      this.say(c, [reply || pick(LEAVE_LINES)], 'left');
    } else if (next === 'remote') {
      c.remoteId = genId();
      this.say(c, [reply, `Мой ID в «ДальнемСтоле»: ${c.remoteId}`], 'remote');
    } else if (next === 'task') {
      this.say(c, [reply || 'Вот данные.'], 'task');
    }
  },

  calcReward(c) {
    let r = c.sc.base * rank().mult * (0.55 + c.mood / 100 * 0.75);
    if (c.kind === 'remote') r *= 1.5 * (S.workers[0].lvl >= 10 ? 1.5 : 1);
    if (c.kind === 'task') r *= 1.3;
    if (S.workers[1].lvl >= 6) r *= 1.2;
    if (c.mood >= 80) r *= 1 + 0.15 + (has('cat') ? 0.15 : 0);
    return Math.max(10, Math.round(r / 10) * 10);
  },

  invoice(c) {
    if (c.state !== 'invoice') return;
    const reward = this.calcReward(c);
    c.reward = reward;
    sfx.sent();
    this.push(c, 'me', `📄 Счёт на ${fmt(reward)} выставлен`);
    c.state = 'paying';
    c.pending = {
      t: 0.7 + net().ping / 1000 * 2.4,
      fn: () => {
        addMoney(reward, 'client');
        const plantOk = has('plant') && S.plantDay === S.day;
        let rep = Math.max(1, Math.round(1 + c.mood / 30));
        if (plantOk) rep = Math.round(rep * 1.1 + 0.4);
        addRep(rep);
        S.stats.clients++; S.dayStats.clients++;
        if (c.kind === 'remote') { S.stats.remotes++; S.dayStats.remotes++; }
        if (c.kind === 'task') { S.stats.tasks++; S.dayStats.tasks++; }
        this.sys(c, `✅ Оплата получена: +${fmt(reward)} · репутация +${rep}`);
        this.push(c, 'c', pick(THANKS_LINES));
        sfx.cash(); vibrate(30);
        c.state = 'done'; c.removeT = 4;
        bus.emit('paid', c, reward);
        bus.emit('clients');
      },
    };
    bus.emit('clients');
  },

  // результат удалёнки / мини-игры
  resolve(c, ok, mistakes = 0) {
    if (c.state !== 'remote' && c.state !== 'task') return;
    c.kind = c.state;
    if (ok) {
      c.mood = clamp(c.mood + 15 - mistakes * 12, 1, 100);
      this.sys(c, mistakes ? `✅ Готово (ошибок: ${mistakes})` : '✅ Всё сделано идеально!');
      this.say(c, [c.sc.done || 'Отлично! Выставляйте счёт.'], 'invoice');
    } else {
      c.mood = clamp(c.mood - 35, 0, 100);
      this.sys(c, '❌ Задача не выполнена');
      if (c.mood <= 0) this.say(c, ['Ничего не работает! ' + pick(LEAVE_LINES)], 'left');
      else this.say(c, ['Эх, ничего не вышло… Ладно, выставляйте счёт, хоть за старание.'], 'invoice');
    }
  },

  leave(c, silent) {
    if (!silent) this.push(c, 'c', pick(LEAVE_LINES));
    c.state = 'left';
    c.removeT = 4;
    c.pending = null;
    S.stats.failed++;
    addRep(-3);
    this.sys(c, '🚪 Клиент ушёл недовольным · репутация −3');
    sfx.fail();
    bus.emit('clients');
  },

  remove(c) {
    this.active = this.active.filter((x) => x !== c);
    bus.emit('clients');
  },

  forceRemoteClient() {
    const sc = this.pickScenario((s) => !!s.remote);
    this.spawn(true, sc);
  },

  clearAll() { this.active = []; this.queue = []; bus.emit('clients'); },

  update(dt, blocked) {
    // появление клиентов
    if (!blocked && S.minute < 520) {
      this.spawnT -= dt;
      if (this.spawnT <= 0) {
        const total = this.liveCount() + this.queue.length;
        if (total < maxChats() + 2) this.spawn();
        this.spawnT = rand(13, 26) * (1 - Math.min(0.35, rankIdx() * 0.05));
      }
    }
    // очередь
    while (this.queue.length && this.liveCount() < maxChats()) this.activate(this.queue.shift());
    for (const q of this.queue.slice()) {
      q.qPat -= dt;
      if (q.qPat <= 0) { this.queue = this.queue.filter((x) => x !== q); addRep(-1); bus.emit('clients'); }
    }
    const stalled = online.outage > 0;
    for (const c of this.active.slice()) {
      if (c.pending && !(stalled && c.state !== 'yawn')) {
        c.pending.t -= dt;
        if (c.pending.t <= 0) { const f = c.pending.fn; c.pending = null; f(); }
      }
      if (['wait', 'invoice', 'remote', 'task'].includes(c.state) && !stalled && !blocked && !c.inSession) {
        c.pat -= dt;
        if (!c.warned && c.pat < c.maxPat * 0.35) {
          c.warned = true; c.mood = clamp(c.mood - 6, 0, 100);
          this.push(c, 'c', pick(WAIT_LINES)); c.unread++; sfx.msg();
          bus.emit('clients');
        }
        if (c.pat <= 0) this.leave(c);
      }
      if (c.state === 'done' || c.state === 'left') {
        c.removeT -= dt;
        if (c.removeT <= 0) this.remove(c);
      }
    }
  },
};
