// ===== Компьютерная ОС: темы по эпохам, окна, приложения =====
import { S, bus, fmt, esc, clockStr, rankIdx, online, has, maxChats, save } from './state.js';
import { PCS, NETS, FANS, ITEMS, RANKS, ACH } from './data.js';
import { G } from './game.js';
import { CM } from './clients.js';
import { Scene } from './scene.js';
import { UI, h, ARROW } from './ui.js';
import { sfx } from './audio.js';
import { runRemote } from './remote.js';
import { runMinigame } from './minigames.js';

const APPS = [
  { id: 'chat', ic: '💬', name: 'СПЕРМ.Чат' },
  { id: 'remote', ic: '🛰', name: 'ДальнийСтол' },
  { id: 'mail', ic: '📧', name: 'Почта' },
  { id: 'market', ic: '🛒', name: 'СПЕРМ.Маркет' },
  { id: 'team', ic: '👥', name: 'Коллеги' },
  { id: 'profile', ic: '🏅', name: 'Мой профиль' },
  { id: 'coffee', ic: '☕', name: 'Заказать кофе' },
  { id: 'exit', ic: '🚪', name: 'Встать из-за ПК' },
];
const STATE_TXT = { arrive: '…', typing: 'печатает…', yawn: '…', wait: '✍ ждёт ответа', invoice: '💰 ждёт счёт', paying: '⏳ оплата…', remote: '🛰 ждёт подключения', task: '🧮 ждёт расчёт', done: '✅ оплачено', left: '🚪 ушёл' };
const moodEmoji = (m) => (m > 80 ? '😄' : m > 60 ? '🙂' : m > 40 ? '😐' : m > 20 ? '😠' : '🤬');

export const OS = { open: false, booted: false, cur: null, wins: {}, chatSel: null, loaded: {}, remoteSession: null, mgActive: false, marketTab: 'pc', mailTab: 'goals', openMail: null };
let el, q, cursor;
const HOURGLASS = '<svg class="hgl" width="16" height="24" viewBox="0 0 14 20"><path d="M1 1h12v2c0 3-4 5-4 7s4 4 4 7v2H1v-2c0-3 4-5 4-7S1 6 1 3z" fill="#fff" stroke="#000"/><path d="M4 4h6l-3 4zM3.5 17.5c0-2 3.5-3 3.5-5 0 2 3.5 3 3.5 5z" fill="#c8a24a"/></svg>';

OS.init = function () {
  el = document.getElementById('os');
  el.innerHTML = `<div class="os-screen"><div class="os-desktop"><div class="os-icons"></div><div class="os-wins"></div><div class="os-hintbar hidden"></div></div>
    <div class="os-taskbar"><button class="os-start"></button><div class="os-tasks"></div><div class="os-tray"><span class="tr-net"></span><span class="tr-temp"></span><span class="tr-money"></span><span class="tr-clock"></span></div></div>
    <div class="os-startmenu hidden"></div><div class="os-boot hidden"></div><div class="os-bsod hidden"></div></div>`;
  q = (s) => el.querySelector(s);
  const icons = q('.os-icons');
  APPS.forEach((a) => {
    const b = h(`<button class="os-icon" data-app="${a.id}"><span class="ic">${a.ic}</span><span class="lb">${a.name}</span><i class="badge"></i></button>`);
    b.onclick = () => { sfx.click(); OS.openApp(a.id); };
    icons.appendChild(b);
  });
  q('.os-start').onclick = () => { sfx.click(); OS.toggleStart(); };
  // курсор мыши: на касание «едет» к пальцу, мышью — следует сразу
  const scr = q('.os-screen');
  cursor = h('<div class="os-cursor"><span class="arrow"></span><span class="busy"></span></div>');
  scr.appendChild(cursor);
  const moveCursor = (e, instant) => {
    const r = scr.getBoundingClientRect();
    cursor.style.transitionDuration = instant ? '0s' : (0.1 + (1 - PCS[S.pc].speed) * 0.35).toFixed(2) + 's';
    cursor.style.left = (e.clientX - r.left) + 'px';
    cursor.style.top = (e.clientY - r.top) + 'px';
  };
  scr.addEventListener('pointerdown', (e) => {
    moveCursor(e, e.pointerType === 'mouse');
    cursor.classList.add('press'); setTimeout(() => cursor.classList.remove('press'), 140);
  }, true);
  scr.addEventListener('pointermove', (e) => { if (e.pointerType === 'mouse') moveCursor(e, true); }, true);
  q('.os-desktop').addEventListener('pointerdown', (e) => { if (!e.target.closest('.os-startmenu')) OS.closeStart(); });

  bus.on('clients', () => { if (!OS.open) return; if (OS.cur === 'chat') renderChat(); else if (OS.cur === 'remote' && !OS.remoteSession) renderRemote(); OS.badges(); });
  bus.on('newclient', (c) => { if (OS.open && OS.cur !== 'chat') UI.toast(`💬 Новый клиент: ${c.sc.av} ${c.sc.who}`, 'info', 2200); });
  bus.on('tick', () => { if (OS.open) { OS.tray(); updatePatience(); } });
  bus.on('mail', () => { OS.badges(); if (OS.cur === 'mail') renderMail(); });
  bus.on('goals', () => { OS.badges(); if (OS.cur === 'mail') renderMail(); });
  bus.on('money', () => { if (OS.open) { OS.tray(); if (OS.cur === 'market') renderMarket(); } });
  bus.on('workers', () => { if (OS.cur === 'team') renderTeam(); });
  bus.on('bsod', () => OS.bsod());
  bus.on('pc', () => { if (OS.open) { UI.toast('🔧 Новый компьютер установлен! Перезагрузка…', 'good'); Object.keys(OS.wins).forEach((id) => OS.closeApp(id)); OS.boot(); } else OS.booted = false; });
  OS.applyTheme();
};

OS.applyTheme = function () {
  const os = PCS[S.pc].os;
  el.className = `os t-${os}${OS.open ? ' show' : ''}${el.classList.contains('hidden') ? ' hidden' : ''}`;
  q('.os-start').innerHTML = { '95': '🖥 <b>Пуск</b>', xp: 'пуск', '7': '⊞', '11': '⊞', q: '◈ КВАНТ' }[os];
  cursor.querySelector('.arrow').innerHTML = os === 'q' ? ARROW('rgba(0,255,255,0.25)', '#0ff') : ARROW();
  cursor.querySelector('.busy').innerHTML = os === '95' || os === 'xp' ? HOURGLASS : '<div class="ring"></div>';
  OS.tray(); OS.badges();
};

// ---------- вход / выход ----------
OS.enter = function () {
  if (OS.open || Scene.camMode !== 'free') return;
  sfx.click();
  Scene.zoomToPC(() => {
    OS.open = true; G.inOS = true;
    el.classList.remove('hidden');
    OS.applyTheme();
    requestAnimationFrame(() => el.classList.add('show'));
    setTimeout(() => { if (OS.open) Scene.renderEnabled = false; }, 350);
    if (S.tutorial < 2) S.tutorial = 2;
    if (!OS.booted) OS.boot(); else OS.afterEnter();
  });
};
OS.afterEnter = function () {
  OS.hint();
  if (!OS.cur && CM.active.length) OS.openApp('chat');
};
OS.exit = function () {
  if (!OS.open) return;
  if (OS.mgActive) { UI.toast('Сначала закончите расчёт', 'warn'); return; }
  OS.closeStart();
  OS.open = false; G.inOS = false;
  Scene.renderEnabled = true;
  el.classList.remove('show');
  setTimeout(() => { if (!OS.open) el.classList.add('hidden'); }, 300);
  Scene.zoomOut();
  sfx.whoosh();
};
OS.back = function () {
  if (!q('.os-startmenu').classList.contains('hidden')) { OS.closeStart(); return true; }
  if (OS.mgActive) return true;
  if (OS.cur) { OS.closeApp(OS.cur); return true; }
  OS.exit(); return true;
};

OS.hint = function () {
  const hb = q('.os-hintbar');
  let t = '';
  if (S.tutorial === 2 && !OS.cur) t = '👆 Открой «СПЕРМ.Чат» — там пишут клиенты';
  if (G.osBusy) t = '';
  hb.textContent = t; hb.classList.toggle('hidden', !t);
};

// ---------- загрузка ОС ----------
OS.boot = function () {
  const os = PCS[S.pc].os, dur = PCS[S.pc].boot;
  G.osBusy = true; OS.booted = false; OS.loaded = {};
  OS.applyTheme();
  const b = q('.os-boot'); b.className = 'os-boot boot-' + os;
  const name = PCS[S.pc].osName;
  if (os === '95') {
    b.innerHTML = '';
    const lines = ['СПЕРМ BIOS v4.51PG, (C) 1996', `Процессор: ${PCS[S.pc].name} 66 МГц`, 'Тест памяти: 8192K OK', 'Обнаружен дисковод A: 3,5"', 'Обнаружен винчестер C: 540 МБ', '', `Запуск ${name}…`];
    lines.forEach((l, i) => setTimeout(() => { b.appendChild(h(`<div>${l || '&nbsp;'}</div>`)); sfx.key(); }, i * dur * 0.07));
    setTimeout(() => b.appendChild(h(`<div class="splash95">${name}</div>`)), dur * 0.6);
  } else if (os === 'xp') b.innerHTML = `<div>${name}<small>СПЕРМ Edition</small><div class="bar"></div></div>`;
  else if (os === '7') b.innerHTML = `<div><div class="orb"></div>Запуск ${name}</div>`;
  else if (os === '11') b.innerHTML = '<div><div class="logo"><i></i><i></i><i></i><i></i></div><div class="sp"></div></div>';
  else b.innerHTML = '<div>КВАНТ·ОС<small>синхронизация кубитов… готово</small></div>';
  b.classList.remove('hidden');
  q('.os-hintbar').classList.add('hidden');
  setTimeout(() => {
    b.classList.add('hidden'); b.innerHTML = '';
    G.osBusy = false; OS.booted = true;
    sfx.boot(os);
    OS.cursorBusy(true); setTimeout(() => OS.cursorBusy(false), 300 + (1 - PCS[S.pc].speed) * 1200);
    if (OS.open) OS.afterEnter();
  }, dur);
};

OS.bsod = function () {
  if (!OS.open) return;
  G.osBusy = true; G.bsodShow = true;
  if (OS.remoteSession && OS.wins.remote) { const body = OS.wins.remote.querySelector('.win-body'); if (body._abort) body._abort(); }
  const os = PCS[S.pc].os;
  const b = q('.os-bsod');
  const modern = os === '11' || os === 'q' || os === '7';
  b.className = 'os-bsod' + (modern ? ' modern' : '');
  b.innerHTML = modern
    ? `<div class="sad">:(</div><p style="font-size:20px">На вашем ПК возникла проблема: он перегрелся.</p><p>Код остановки: CPU_TOO_HOT_PLEASE_FAN<br>Совет: включите вентилятор и купите охлаждение получше.</p><p>Перезапуск… 100%</p>`
    : `<p style="text-align:center"><span class="hl">${PCS[S.pc].osName}</span></p><p>Произошла неустранимая ошибка 0E в 0028:C0011E36 (ПЕРЕГРЕВ.VXD).</p><p>* Процессор раскалился как утюг.<br>* Включите вентилятор. Пожалуйста.<br>* Нажмите любую клавишу… шучу, перезагрузка сама.</p>`;
  b.classList.remove('hidden');
  sfx.bsod();
  UI.toast('💙 Синий экран! Компьютер перегрелся', 'bad');
  setTimeout(() => {
    b.classList.add('hidden'); G.bsodShow = false;
    Object.keys(OS.wins).forEach((id) => OS.closeApp(id));
    OS.boot();
  }, 3600);
};

// ---------- меню «Пуск» ----------
OS.toggleStart = function () {
  const m = q('.os-startmenu');
  if (!m.classList.contains('hidden')) { OS.closeStart(); return; }
  m.innerHTML = `<div class="side">${PCS[S.pc].osName}</div><div class="head">👤 ${RANKS[rankIdx()].name}</div><div class="items"></div>`;
  const items = m.querySelector('.items');
  APPS.forEach((a) => { const b = h(`<button>${a.ic} ${a.name}</button>`); b.onclick = () => { sfx.click(); OS.closeStart(); OS.openApp(a.id); }; items.appendChild(b); });
  items.appendChild(h('<hr>'));
  const help = h('<button>❓ Как играть</button>'); help.onclick = () => { OS.closeStart(); UI.help(); }; items.appendChild(help);
  const rb = h('<button>🔄 Перезагрузка</button>'); rb.onclick = () => { OS.closeStart(); if (OS.mgActive) return; Object.keys(OS.wins).forEach((id) => OS.closeApp(id)); OS.boot(); }; items.appendChild(rb);
  const ex = h('<button>🚪 Встать из-за компьютера</button>'); ex.onclick = () => { OS.closeStart(); OS.exit(); }; items.appendChild(ex);
  m.classList.remove('hidden');
};
OS.cursorBusy = function (on) { if (cursor) cursor.classList.toggle('is-busy', !!on); };
OS.closeStart = function () { if (q) q('.os-startmenu').classList.add('hidden'); };

// ---------- окна ----------
OS.openApp = function (id, arg) {
  if (G.osBusy) return;
  if (id === 'coffee') { UI.coffeeMenu(); return; }
  if (id === 'exit') { OS.exit(); return; }
  OS.closeStart();
  const app = APPS.find((a) => a.id === id);
  let w = OS.wins[id];
  if (!w) {
    w = h(`<div class="win"><div class="win-title"><span>${app.ic}</span><span class="wt">${app.name}</span><button class="wb min">_</button><button class="wb close">✕</button></div><div class="win-body"></div></div>`);
    w.querySelector('.min').onclick = () => { sfx.click(); w.classList.add('hidden'); OS.cur = null; OS.tasks(); };
    w.querySelector('.close').onclick = () => { sfx.click(); OS.closeApp(id); };
    q('.os-wins').appendChild(w);
    OS.wins[id] = w;
  }
  Object.entries(OS.wins).forEach(([k, v]) => v.classList.toggle('hidden', k !== id));
  OS.cur = id;
  if (id === 'chat' && S.tutorial === 2) { S.tutorial = 3; OS.hint(); }
  const body = w.querySelector('.win-body');
  const delay = Math.round((1 - PCS[S.pc].speed) * 1700);
  const doRender = () => render(id, arg);
  if (!OS.loaded[id] && delay > 150) {
    OS.loaded[id] = true;
    body.innerHTML = `<div class="loading"><div><span class="hg">⏳</span><br>Загрузка «${app.name}»…</div></div>`;
    OS.cursorBusy(true);
    setTimeout(() => { OS.cursorBusy(false); if (OS.wins[id] && OS.wins[id].querySelector('.win-body') === body) { body.innerHTML = ''; if (OS.cur === id) doRender(); } }, delay);
  } else { OS.loaded[id] = true; doRender(); }
  OS.tasks();
};
OS.closeApp = function (id) {
  const w = OS.wins[id]; if (!w) return;
  if (id === 'remote' && OS.remoteSession) { const b = w.querySelector('.win-body'); if (b._abort) b._abort(); }
  w.remove(); delete OS.wins[id];
  if (OS.cur === id) OS.cur = null;
  OS.tasks();
};
OS.tasks = function () {
  OS.hint();
  const t = q('.os-tasks'); t.innerHTML = '';
  Object.keys(OS.wins).forEach((id) => {
    const a = APPS.find((x) => x.id === id);
    const b = h(`<button class="os-task ${OS.cur === id ? 'on' : ''}">${a.ic} ${a.name}</button>`);
    b.onclick = () => { sfx.click(); if (OS.cur === id) { OS.wins[id].classList.add('hidden'); OS.cur = null; OS.tasks(); } else OS.openApp(id); };
    t.appendChild(b);
  });
};
OS.tray = function () {
  if (!q) return;
  const out = online.outage > 0;
  q('.tr-net').textContent = out ? '❌' : '📶 ' + NETS[S.net].short;
  const temp = Math.round(35 + (S.heat - 30) / 70 * 60);
  const te = q('.tr-temp'); te.textContent = `🌡${temp}°`; te.style.color = S.heat > 85 ? '#e53935' : '';
  q('.tr-money').textContent = fmt(S.money);
  q('.tr-clock').textContent = clockStr();
};
OS.badges = function () {
  if (!q) return;
  const set = (id, n) => { const b = el.querySelector(`.os-icon[data-app="${id}"] .badge`); if (b) b.textContent = n > 0 ? n : ''; };
  set('chat', CM.active.filter((c) => c.unread > 0 || ['wait', 'invoice', 'remote', 'task'].includes(c.state)).length);
  set('remote', CM.active.filter((c) => c.state === 'remote').length);
  set('mail', S.emails.filter((m) => !m.read).length + (S.goals || []).filter((g) => g.done && !g.claimed).length);
};

function render(id, arg) {
  if (id === 'chat') renderChat();
  else if (id === 'remote') renderRemote(arg);
  else if (id === 'mail') renderMail();
  else if (id === 'market') renderMarket();
  else if (id === 'team') renderTeam();
  else if (id === 'profile') renderProfile();
  OS.badges();
}
const body0 = (w) => w.querySelector('.win-body');
const bodyOf = (id) => OS.wins[id] && OS.wins[id].querySelector('.win-body');

// ---------- СПЕРМ.Чат ----------
function renderChat() {
  const body = bodyOf('chat'); if (!body || body.querySelector('.loading')) return;
  const list = CM.active;
  if (!list.length) {
    body.innerHTML = `<div class="empty"><div><div class="big">📭</div>Пока никто не пишет.<br><small>Клиенты появятся с минуты на минуту${CM.queue.length ? ` (в очереди: ${CM.queue.length})` : ''}.<br>Одновременно чатов: ${maxChats()} — больше даст новый ПК или второй монитор.</small></div></div>`;
    return;
  }
  if (!OS.chatSel || !list.find((c) => c.id === OS.chatSel)) {
    const pr = list.find((c) => ['wait', 'invoice', 'remote', 'task'].includes(c.state)) || list[0];
    OS.chatSel = pr.id;
  }
  const c = list.find((x) => x.id === OS.chatSel);
  c.unread = 0;
  const items = list.map((x) => `<button class="ci ${x.id === c.id ? 'on' : ''}" data-id="${x.id}"><span class="av">${x.sc.av}</span><span class="meta"><b>${esc(x.sc.who)}</b><span class="st">${STATE_TXT[x.state] || ''}</span></span>${x.unread ? '<span class="dot"></span>' : ''}<i class="pat" data-pid="${x.id}"></i></button>`).join('')
    + (CM.queue.length ? `<div class="ci queue">⏳ В очереди: ${CM.queue.length}</div>` : '');
  const msgs = c.msgs.map((m) => `<div class="msg ${m.from}">${esc(m.text)}</div>`).join('');
  let foot = '';
  if (c.state === 'typing' || c.state === 'arrive') foot = `<div class="typing">${esc(c.sc.who)} печатает<span class="dots"></span></div>`;
  else if (c.state === 'yawn') foot = '<div class="typing">😴 Вы зеваете…</div>';
  else if (c.state === 'wait' && c.opts) {
    const hint = S.workers[1].lvl >= 3;
    foot = c.opts.map((o, i) => `<button class="opt ${hint && i === c.best ? 'best' : ''}" data-i="${i}">${esc(o[0])}${hint && i === c.best ? '<em>⭐</em>' : ''}</button>`).join('');
  } else if (c.state === 'invoice') foot = `<button class="act inv">📄 Выставить счёт · ~${fmt(CM.calcReward(Object.assign({}, c, { kind: c.kind })))}</button>`;
  else if (c.state === 'paying') foot = '<div class="typing">⏳ Платёж проходит через банк<span class="dots"></span> (скорость зависит от интернета)</div>';
  else if (c.state === 'remote') foot = `<button class="act rem">🛰 Подключиться через ДальнийСтол · ID ${c.remoteId}</button>`;
  else if (c.state === 'task') foot = '<button class="act tsk">🧮 Выполнить расчёт</button>';
  else foot = '<div class="typing">Диалог завершён</div>';
  body.innerHTML = `<div class="chat"><div class="chat-list">${items}</div><div class="chat-main">
    ${online.outage > 0 ? '<div class="offline">❌ Нет интернета — сообщения не доходят</div>' : ''}
    <div class="chat-head"><span class="av">${c.sc.av}</span><span class="nm"><b>${esc(c.sc.who)}</b>${esc(c.sc.org)}${c.sc.vip ? ' · 👑 VIP' : ''}</span><span class="mood"><span>${moodEmoji(c.mood)}</span>${Math.round(c.mood)}%</span></div>
    <div class="patbar"><i data-pat="${c.id}"></i></div>
    <div class="chat-msgs">${msgs}</div><div class="chat-foot">${foot}</div></div></div>`;
  body.querySelectorAll('.ci[data-id]').forEach((b) => { b.onclick = () => { sfx.tap(); OS.chatSel = +b.dataset.id; renderChat(); }; });
  body.querySelectorAll('.opt').forEach((b) => { b.onclick = () => { body.querySelectorAll('.opt').forEach((x) => { x.disabled = true; }); CM.choose(c, +b.dataset.i); }; });
  const inv = body.querySelector('.inv'); if (inv) inv.onclick = () => { inv.disabled = true; CM.invoice(c); };
  const rem = body.querySelector('.rem'); if (rem) rem.onclick = () => { sfx.click(); OS.openApp('remote', c); };
  const tsk = body.querySelector('.tsk'); if (tsk) tsk.onclick = () => OS.startTask(c);
  const box = body.querySelector('.chat-msgs'); box.scrollTop = box.scrollHeight;
  updatePatience();
}
function updatePatience() {
  if (OS.cur !== 'chat') return;
  const body = bodyOf('chat'); if (!body) return;
  CM.active.forEach((c) => {
    const k = c.maxPat ? Math.max(0, c.pat / c.maxPat) : 1;
    const active = ['wait', 'invoice', 'remote', 'task'].includes(c.state);
    body.querySelectorAll(`[data-pat="${c.id}"],[data-pid="${c.id}"]`).forEach((i) => { i.style.width = (active ? k * 100 : 0) + '%'; i.classList.toggle('low', k < 0.35); });
  });
}

OS.startTask = function (c) {
  if (OS.mgActive || c.state !== 'task') return;
  OS.mgActive = true; c.inSession = true;
  sfx.click();
  runMinigame(q('.os-screen'), c.sc.task).then((res) => {
    OS.mgActive = false; c.inSession = false;
    CM.resolve(c, res.ok, res.mistakes);
    OS.chatSel = c.id;
    if (OS.open) OS.openApp('chat');
  });
};

// ---------- ДальнийСтол ----------
function renderRemote(arg) {
  const body = bodyOf('remote'); if (!body) return;
  if (OS.remoteSession) { if (arg && arg !== OS.remoteSession) UI.toast('Сначала завершите текущую сессию', 'warn'); return; }
  if (arg && arg.state === 'remote') {
    const c = arg;
    OS.remoteSession = c; c.inSession = true;
    runRemote(body, c).then((res) => {
      OS.remoteSession = null; c.inSession = false;
      CM.resolve(c, res.ok, res.mistakes);
      OS.chatSel = c.id;
      if (OS.wins.remote) OS.closeApp('remote');
      if (OS.open && !G.osBusy) OS.openApp('chat');
    });
    return;
  }
  const reqs = CM.active.filter((c) => c.state === 'remote');
  if (!reqs.length) {
    body.innerHTML = '<div class="empty"><div><div class="big">🛰</div><b>ДальнийСтол</b><br><small>Нет запросов на подключение.<br>Когда клиенту нужна помощь, он пришлёт ID в чат.</small></div></div>';
    return;
  }
  body.innerHTML = `<div class="rd-list scroll"><b>Запросы на подключение:</b>${reqs.map((c) => `<div class="rd-req"><span class="av">${c.sc.av}</span><span class="i"><b>${esc(c.sc.who)}</b><br>ID ${c.remoteId}</span><button class="ob pri" data-id="${c.id}">Подключиться</button></div>`).join('')}</div>`;
  body.querySelectorAll('[data-id]').forEach((b) => { b.onclick = () => { const c = CM.active.find((x) => x.id === +b.dataset.id); if (c) renderRemote(c); }; });
}

// ---------- Почта ----------
function renderMail() {
  const body = bodyOf('mail'); if (!body) return;
  const goals = S.goals || [];
  const unread = S.emails.filter((m) => !m.read).length;
  body.innerHTML = `<div class="tabs"><button class="tab ${OS.mailTab === 'goals' ? 'on' : ''}" data-t="goals">🎯 Цели дня</button><button class="tab ${OS.mailTab === 'mail' ? 'on' : ''}" data-t="mail">📨 Письма${unread ? ` (${unread})` : ''}</button></div><div class="pane"></div>`;
  const pane = body.querySelector('.pane');
  body.querySelectorAll('.tab').forEach((t) => { t.onclick = () => { sfx.tap(); OS.mailTab = t.dataset.t; renderMail(); }; });
  if (OS.mailTab === 'goals') {
    pane.innerHTML = `<p style="margin:0 0 8px;font-size:13px">От: <b>Аркадий Борисович</b> — задачи на день ${S.day}. Премии сгорают в конце дня!</p>` + goals.map((g, i) => {
      const v = Math.min(g.n, S.dayStats[g.stat] || 0);
      return `<div class="goal"><span style="font-size:22px">${g.claimed ? '✅' : g.done ? '🎁' : '🎯'}</span><div class="gi">${esc(g.text)}<div class="gp"><i style="width:${v / g.n * 100}%"></i></div><small>${g.stat === 'earned' ? fmt(v) + ' / ' + fmt(g.n) : v + ' / ' + g.n}</small></div>
        ${g.claimed ? '<span style="font-size:12px">получено</span>' : `<button class="ob ${g.done ? 'pri' : ''}" data-g="${i}" ${g.done ? '' : 'disabled'}>Премия ${fmt(g.reward)}</button>`}</div>`;
    }).join('');
    pane.querySelectorAll('[data-g]').forEach((b) => { b.onclick = () => { G.claimGoal(+b.dataset.g); }; });
  } else {
    pane.innerHTML = S.emails.map((m) => `<div class="mail ${m.read ? '' : 'unread'}"><button class="mh" data-m="${m.id}">${m.read ? '📭' : '📩'} <span><b>${esc(m.subj)}</b><br><small>${esc(m.from)}</small></span><span class="when">${esc(m.when)}</span></button>${OS.openMail === m.id ? `<div class="mb">${esc(m.body)}</div>` : ''}</div>`).join('') || '<div class="empty">Писем нет</div>';
    pane.querySelectorAll('[data-m]').forEach((b) => { b.onclick = () => { sfx.tap(); const m = S.emails.find((x) => String(x.id) === b.dataset.m); OS.openMail = OS.openMail === m.id ? null : m.id; m.read = true; renderMail(); OS.badges(); }; });
  }
}

// ---------- СПЕРМ.Маркет ----------
function renderMarket() {
  const body = bodyOf('market'); if (!body || body.querySelector('.loading')) return;
  const scroll = body.querySelector('.pane') ? body.querySelector('.pane').scrollTop : 0;
  const tabs = [['pc', '🖥 Компьютер'], ['net', '📶 Интернет'], ['fan', '🌀 Охлаждение'], ['item', '🪴 На стол']];
  body.innerHTML = `<div class="tabs">${tabs.map(([k, n]) => `<button class="tab ${OS.marketTab === k ? 'on' : ''}" data-t="${k}">${n}</button>`).join('')}</div><div class="pane"><div class="shop-head"><span>Доставка мгновенно, прямо на стол 🚚</span><b>Баланс: ${fmt(S.money)}</b></div><div class="items"></div></div>`;
  body.querySelectorAll('.tab').forEach((t) => { t.onclick = () => { sfx.tap(); OS.marketTab = t.dataset.t; renderMarket(); }; });
  const box = body.querySelector('.items');
  const card = (nm, spec, desc, price, state, onBuy) => {
    const c = h(`<div class="item ${state === 'cur' ? 'cur' : state === 'lock' ? 'lock' : ''}"><div class="nm">${nm}</div><div class="spec">${spec}</div><div>${desc}</div>
      ${state === 'cur' ? '<button class="ob" disabled>✓ Установлено</button>' : state === 'old' ? '<button class="ob" disabled>Устарело</button>' : state === 'lock' ? '<button class="ob" disabled>🔒 Сначала предыдущий</button>' : `<button class="ob pri buy" ${S.money < price ? 'disabled' : ''}>Купить · ${fmt(price)}</button>`}</div>`);
    const b = c.querySelector('.buy'); if (b) b.onclick = onBuy;
    box.appendChild(c);
  };
  const tierState = (i, cur) => (i < cur ? 'old' : i === cur ? 'cur' : i === cur + 1 ? 'buy' : 'lock');
  if (OS.marketTab === 'pc') PCS.forEach((p, i) => card(`🖥 ${p.name} <small>(${p.year})</small>`, `ОС: ${p.osName} · 💬 чатов: ${p.chats} · ⚡ скорость ${Math.round(p.speed * 100)}% · 🌡 нагрев ×${p.heat}`, p.desc, p.price, tierState(i, S.pc), () => G.buy('pc', i)));
  if (OS.marketTab === 'net') NETS.forEach((n, i) => card(`📶 ${n.name}`, `Пинг ${n.ping} мс · подключение ${(n.connect / 1000).toFixed(1)} с · обрывы ${Math.round(n.drop * 100)}%`, n.desc, n.price, tierState(i, S.net), () => G.buy('net', i)));
  if (OS.marketTab === 'fan') FANS.forEach((f, i) => card(`🌀 ${f.name}`, `Охлаждение: ${f.cool}/с${f.flaky ? ' · иногда глохнет' : ''}`, f.desc, f.price, tierState(i, S.fan), () => G.buy('fan', i)));
  if (OS.marketTab === 'item') ITEMS.forEach((it) => card(`${it.icon} ${it.name}`, '', it.desc, it.price, has(it.id) ? 'cur' : 'buy', () => G.buy('item', it.id)));
  body.querySelector('.pane').scrollTop = scroll;
}

// ---------- Коллеги ----------
function renderTeam() {
  const body = bodyOf('team'); if (!body || body.querySelector('.loading')) return;
  body.innerHTML = '<div class="pane" style="height:100%"></div>';
  const pane = body.querySelector('.pane');
  pane.style.color = 'inherit';
  UI.renderWorkers(pane, renderTeam);
  pane.querySelectorAll('.worker').forEach((w) => { w.style.background = 'rgba(127,127,127,0.12)'; });
}

// ---------- Профиль ----------
function renderProfile() {
  const body = bodyOf('profile'); if (!body) return;
  const r = rankIdx(), nx = RANKS[r + 1], st = S.stats;
  const k = nx ? (S.rep - RANKS[r].rep) / (nx.rep - RANKS[r].rep) : 1;
  body.innerHTML = `<div class="pane" style="height:100%"><div class="prof"><div class="big">🧑‍💼</div><div><b style="font-size:17px">${RANKS[r].name}</b><br>Репутация: ${Math.floor(S.rep)}${nx ? ` / ${nx.rep} до «${nx.name}»` : ' (максимум!)'}<div class="rb"><i style="width:${k * 100}%"></i></div><small>Клиенты платят ×${RANKS[r].mult}</small></div></div>
    <div class="osgrid"><div><span>День</span><b>${S.day}</b></div><div><span>Заработано всего</span><b>${fmt(st.earned)}</b></div><div><span>Клиентов</span><b>${st.clients}</b></div><div><span>Ушли недовольными</span><b>${st.failed}</b></div>
    <div><span>Удалёнок</span><b>${st.remotes}</b></div><div><span>Расчётов</span><b>${st.tasks}</b></div><div><span>Кофе</span><b>${st.coffee}</b></div><div><span>Синих экранов</span><b>${st.bsod}</b></div></div>
    <b>🏆 Достижения ${Object.keys(S.ach).length}/${ACH.length}</b><div class="ach-grid" style="margin-top:6px">${ACH.map((a) => `<div class="ach ${S.ach[a.id] ? '' : 'locked'}" style="background:rgba(127,127,127,.12)"><div class="i">${a.icon}</div><div><b>${a.name}</b><br>${a.desc}</div></div>`).join('')}</div></div>`;
}
