// ===== Процедурные low-poly модели =====
import * as THREE from 'three';
import { RoundedBoxGeometry } from 'three/addons/geometries/RoundedBoxGeometry.js';

const matCache = new Map();
export function mat(color, o = {}) {
  const key = color + '|' + JSON.stringify(o);
  if (!matCache.has(key)) matCache.set(key, new THREE.MeshStandardMaterial(Object.assign({ color, roughness: 0.75, metalness: 0.05 }, o)));
  return matCache.get(key);
}
export const glow = (color, intensity = 1) => new THREE.MeshStandardMaterial({ color: '#000', emissive: color, emissiveIntensity: intensity, roughness: 1 });
export const basic = (color, o = {}) => new THREE.MeshBasicMaterial(Object.assign({ color }, o));

function shade(m) { m.castShadow = true; m.receiveShadow = true; return m; }
export function box(w, h, d, m, r = 0) {
  const g = r > 0 ? new RoundedBoxGeometry(w, h, d, 2, Math.min(r, w / 2 - 0.001, h / 2 - 0.001, d / 2 - 0.001)) : new THREE.BoxGeometry(w, h, d);
  return shade(new THREE.Mesh(g, m));
}
export const cyl = (rt, rb, h, m, seg = 20) => shade(new THREE.Mesh(new THREE.CylinderGeometry(rt, rb, h, seg), m));
export const sph = (r, m, ws = 16, hs = 12) => shade(new THREE.Mesh(new THREE.SphereGeometry(r, ws, hs), m));
export const cap = (r, len, m) => shade(new THREE.Mesh(new THREE.CapsuleGeometry(r, len, 4, 10), m));
export const tor = (r, t, m, arc = Math.PI * 2) => shade(new THREE.Mesh(new THREE.TorusGeometry(r, t, 8, 24, arc), m));
export function at(o, x, y, z, rx = 0, ry = 0, rz = 0) { o.position.set(x, y, z); o.rotation.set(rx, ry, rz); return o; }
export function grp(...children) { const g = new THREE.Group(); children.forEach((c) => g.add(c)); return g; }

export function canvasTex(w, h, draw) {
  const c = document.createElement('canvas');
  c.width = w; c.height = h;
  const ctx = c.getContext('2d');
  draw(ctx, w, h);
  const t = new THREE.CanvasTexture(c);
  t.colorSpace = THREE.SRGBColorSpace;
  t.anisotropy = 4;
  t.userData.ctx = ctx; t.userData.canvas = c;
  return t;
}

function taperBox(w, h, d, back) {
  const g = new THREE.BoxGeometry(w, h, d);
  const p = g.attributes.position;
  for (let i = 0; i < p.count; i++) if (p.getZ(i) < 0) { p.setX(i, p.getX(i) * back); p.setY(i, p.getY(i) * back - h * 0.04); }
  g.computeVertexNormals();
  return g;
}

// ---------- клавиатура ----------
function keyTex(base, key, glowKeys) {
  return canvasTex(256, 96, (c, w, h) => {
    c.fillStyle = base; c.fillRect(0, 0, w, h);
    const rows = 5, cols = 15;
    for (let r = 0; r < rows; r++) for (let k = 0; k < cols; k++) {
      let kw = 14, x = 6 + k * 16.5;
      if (r === 4 && k > 3 && k < 10) { if (k === 4) { c.fillStyle = key; c.fillRect(x, 6 + r * 17.5, 16.5 * 6 - 3, 14); } continue; }
      c.fillStyle = glowKeys ? `hsl(${(k * 24 + r * 30) % 360},100%,60%)` : key;
      c.fillRect(x, 6 + r * 17.5, kw, 14);
    }
  });
}
export function buildKeyboard(style) {
  const g = new THREE.Group();
  const cfg = {
    beige: ['#d9d0b4', '#efe8d2', '#cfc5a6'], silver: ['#b8bcc2', '#e3e5e8', '#9aa0a8'],
    black: ['#1d1f24', '#33363d', '#15171a'], rgb: ['#111', '#222', '#0d0d0d'], holo: ['#0b1220', '#123', '#081018'],
  }[style];
  const body = box(0.44, 0.025, 0.15, mat(cfg[0]), 0.008);
  body.position.y = 0.0125; body.rotation.x = 0.05;
  g.add(body);
  const t = keyTex(cfg[2], cfg[1], style === 'rgb');
  const topM = style === 'rgb' || style === 'holo'
    ? new THREE.MeshStandardMaterial({ map: t, emissive: '#fff', emissiveMap: t, emissiveIntensity: style === 'holo' ? 0.6 : 1.2 })
    : new THREE.MeshStandardMaterial({ map: t, roughness: 0.8 });
  const top = new THREE.Mesh(new THREE.PlaneGeometry(0.42, 0.135), topM);
  top.rotation.x = -Math.PI / 2 + 0.05; top.position.set(0, 0.0265, 0);
  g.add(top);
  g.userData.top = topM;
  return g;
}
export function buildMouse(style) {
  const colors = { beige: '#e3dcc4', silver: '#c9cdd2', black: '#202228', rgb: '#151515', holo: '#0b1726' };
  const g = new THREE.Group();
  const pad = box(0.2, 0.004, 0.17, mat(style === 'beige' ? '#2d4a7a' : '#1b1c20'), 0.002);
  pad.position.y = 0.002; g.add(pad);
  const m = box(0.055, 0.03, 0.09, mat(colors[style], { roughness: 0.4 }), 0.02);
  m.position.set(0, 0.019, 0); g.add(m);
  if (style === 'rgb' || style === 'holo') {
    const l = box(0.04, 0.004, 0.004, glow(style === 'rgb' ? '#ff2fd0' : '#3ff', 2));
    l.position.set(0, 0.012, -0.046); g.add(l);
  }
  return g;
}

// ---------- компьютеры по эпохам ----------
export function buildPC(tier, screenTex) {
  const g = new THREE.Group();
  const fx = { spin: [], rgb: [], holo: [] };
  const scrMat = new THREE.MeshBasicMaterial({ map: screenTex, toneMapped: false });
  let screen, tower = null;
  if (tier === 0) {
    const beige = mat('#d8cfb2', { roughness: 0.6 });
    const caseM = box(0.48, 0.13, 0.42, beige, 0.01); caseM.position.set(0, 0.065, 0); g.add(caseM);
    const slot = box(0.12, 0.012, 0.005, mat('#333')); slot.position.set(0.12, 0.075, 0.211); g.add(slot);
    const bay = box(0.16, 0.035, 0.005, mat('#c9bfa0')); bay.position.set(0.12, 0.035, 0.211); g.add(bay);
    const led = box(0.012, 0.008, 0.005, glow('#3f3', 2)); led.position.set(-0.18, 0.09, 0.212); g.add(led);
    const led2 = box(0.012, 0.008, 0.005, glow('#fa0', 2)); led2.position.set(-0.155, 0.09, 0.212); g.add(led2);
    fx.led = led2;
    const btn = box(0.03, 0.02, 0.008, mat('#bdb497')); btn.position.set(-0.17, 0.05, 0.212); g.add(btn);
    const base = cyl(0.12, 0.13, 0.02, beige); base.position.set(0, 0.14, -0.02); g.add(base);
    const crt = new THREE.Mesh(taperBox(0.44, 0.38, 0.4, 0.6), beige); crt.castShadow = true; crt.receiveShadow = true;
    crt.position.set(0, 0.34, -0.03); g.add(crt);
    const inset = box(0.37, 0.29, 0.01, mat('#3a3a36')); inset.position.set(0, 0.355, 0.172); g.add(inset);
    screen = new THREE.Mesh(new THREE.PlaneGeometry(0.34, 0.26), scrMat);
    screen.position.set(0, 0.355, 0.178);
    const pled = box(0.01, 0.01, 0.005, glow('#3f3', 2)); pled.position.set(0.17, 0.185, 0.172); g.add(pled);
  } else if (tier === 1) {
    const silver = mat('#b9bdc3', { roughness: 0.45, metalness: 0.3 });
    const base = cyl(0.11, 0.12, 0.015, silver); base.scale.z = 0.7; base.position.set(0, 0.008, 0); g.add(base);
    const neck = box(0.05, 0.14, 0.03, silver); neck.position.set(0, 0.08, -0.03); g.add(neck);
    const panel = box(0.41, 0.34, 0.045, silver, 0.012); panel.position.set(0, 0.3, 0); g.add(panel);
    const bez = box(0.37, 0.28, 0.005, mat('#222')); bez.position.set(0, 0.31, 0.023); g.add(bez);
    screen = new THREE.Mesh(new THREE.PlaneGeometry(0.355, 0.266), scrMat);
    screen.position.set(0, 0.31, 0.0265);
    const led = box(0.01, 0.006, 0.004, glow('#39f', 2)); led.position.set(0.17, 0.145, 0.023); g.add(led);
    tower = buildTower('silver', fx);
  } else if (tier === 2) {
    const black = mat('#16171b', { roughness: 0.3, metalness: 0.2 });
    const base = cyl(0.12, 0.13, 0.015, black); base.scale.z = 0.6; base.position.set(0, 0.008, 0); g.add(base);
    const neck = box(0.05, 0.13, 0.025, black); neck.position.set(0, 0.075, -0.03); g.add(neck);
    const panel = box(0.58, 0.35, 0.04, black, 0.01); panel.position.set(0, 0.3, 0); g.add(panel);
    screen = new THREE.Mesh(new THREE.PlaneGeometry(0.55, 0.31), scrMat);
    screen.position.set(0, 0.305, 0.0205);
    const led = box(0.01, 0.005, 0.004, glow('#fff', 1.5)); led.position.set(0.26, 0.135, 0.021); g.add(led);
    tower = buildTower('black', fx);
  } else if (tier === 3) {
    const dark = mat('#2a2c31', { roughness: 0.35, metalness: 0.5 });
    const legL = box(0.02, 0.012, 0.18, dark); legL.position.set(-0.12, 0.006, 0.0); legL.rotation.y = 0.5; g.add(legL);
    const legR = legL.clone(); legR.position.x = 0.12; legR.rotation.y = -0.5; g.add(legR);
    const neck = box(0.045, 0.17, 0.02, dark); neck.position.set(0, 0.09, -0.04); g.add(neck);
    const panel = box(0.68, 0.39, 0.025, dark, 0.008); panel.position.set(0, 0.32, -0.005); g.add(panel);
    screen = new THREE.Mesh(new THREE.PlaneGeometry(0.665, 0.375), scrMat);
    screen.position.set(0, 0.322, 0.0085);
    const strip = box(0.6, 0.006, 0.006, glow('#f0f', 2)); strip.position.set(0, 0.13, -0.02); g.add(strip);
    fx.rgb.push(strip.material);
    const back = new THREE.PointLight('#f0f', 0.6, 1.4); back.position.set(0, 0.32, -0.15); g.add(back);
    fx.rgbLight = back;
    tower = buildTower('rgb', fx);
  } else {
    const black = mat('#0c0d12', { roughness: 0.2, metalness: 0.7 });
    const disc = cyl(0.15, 0.16, 0.025, black, 32); disc.position.set(0, 0.0125, -0.02); g.add(disc);
    const ring = tor(0.13, 0.006, glow('#3ff', 3)); ring.rotation.x = Math.PI / 2; ring.position.set(0, 0.027, -0.02); g.add(ring);
    fx.holo.push(ring);
    const beamGeo = new THREE.CylinderGeometry(0.33, 0.12, 0.16, 32, 1, true);
    const beam = new THREE.Mesh(beamGeo, new THREE.MeshBasicMaterial({ color: '#3ff', transparent: true, opacity: 0.07, side: THREE.DoubleSide, depthWrite: false, blending: THREE.AdditiveBlending }));
    beam.position.set(0, 0.11, -0.02); g.add(beam);
    scrMat.transparent = true; scrMat.opacity = 0.92; scrMat.side = THREE.DoubleSide;
    screen = new THREE.Mesh(new THREE.PlaneGeometry(0.7, 0.4), scrMat);
    screen.position.set(0, 0.4, 0);
    const edges = new THREE.LineSegments(new THREE.EdgesGeometry(new THREE.PlaneGeometry(0.71, 0.41)), new THREE.LineBasicMaterial({ color: '#7ff' }));
    edges.position.copy(screen.position); g.add(edges);
    fx.holo.push(edges);
    tower = new THREE.Group();
    const cube = box(0.16, 0.16, 0.16, new THREE.MeshStandardMaterial({ color: '#111', metalness: 0.9, roughness: 0.15 }), 0.02);
    const cubeEdges = new THREE.LineSegments(new THREE.EdgesGeometry(new THREE.BoxGeometry(0.17, 0.17, 0.17)), new THREE.LineBasicMaterial({ color: '#3ff' }));
    const core = sph(0.05, glow('#7ff', 3));
    const cg = grp(cube, cubeEdges, core); cg.position.y = 0.45; tower.add(cg);
    const pad = cyl(0.12, 0.13, 0.02, black, 24); pad.position.y = 0.01; tower.add(pad);
    const pl = new THREE.PointLight('#3ff', 0.8, 1.5); pl.position.y = 0.45; tower.add(pl);
    fx.spin.push(cg);
  }
  screen.userData.isScreen = true;
  g.add(screen);
  return { group: g, screen, tower, fx };
}

function buildTower(style, fx) {
  const t = new THREE.Group();
  const col = { silver: '#b4b8be', black: '#141519', rgb: '#0f1013' }[style];
  const body = box(0.2, style === 'rgb' ? 0.48 : 0.42, 0.45, mat(col, { roughness: 0.4, metalness: 0.3 }), 0.01);
  const h = style === 'rgb' ? 0.48 : 0.42;
  body.position.y = h / 2; t.add(body);
  if (style === 'silver') {
    for (let i = 0; i < 3; i++) { const b = box(0.15, 0.035, 0.004, mat('#a9adb3')); b.position.set(0, 0.36 - i * 0.045, 0.226); t.add(b); }
    const led = box(0.01, 0.01, 0.004, glow('#39f', 2)); led.position.set(0.06, 0.2, 0.226); t.add(led);
  } else if (style === 'black') {
    const strip = box(0.006, 0.3, 0.004, glow('#2af', 2)); strip.position.set(0.07, 0.24, 0.226); t.add(strip);
  } else {
    // стеклянная боковая панель с RGB-вентиляторами (смотрит на игрока, к центру стола)
    const glass = new THREE.Mesh(new THREE.PlaneGeometry(0.42, 0.44), new THREE.MeshStandardMaterial({ color: '#88a', transparent: true, opacity: 0.25, roughness: 0.05, metalness: 0.5 }));
    glass.position.set(-0.101, h / 2, 0); glass.rotation.y = -Math.PI / 2; t.add(glass);
    for (let i = 0; i < 3; i++) {
      const fan = new THREE.Group();
      const ring = tor(0.055, 0.008, glow('#f0f', 2.5)); fan.add(ring);
      const hub = cyl(0.015, 0.015, 0.01, mat('#222')); hub.rotation.x = Math.PI / 2; fan.add(hub);
      for (let b = 0; b < 5; b++) { const bl = box(0.05, 0.004, 0.018, mat('#333')); bl.position.x = 0.028; const p = new THREE.Group(); p.add(bl); p.rotation.z = (b / 5) * Math.PI * 2; fan.add(p); }
      fan.position.set(-0.09, 0.1 + i * 0.13, 0.1 - i * 0.05);
      fan.rotation.y = -Math.PI / 2;
      t.add(fan);
      fx.rgb.push(ring.material);
      fx.spin.push(fan);
    }
    const gpu = box(0.02, 0.06, 0.3, glow('#0ff', 1.2)); gpu.position.set(-0.08, 0.22, -0.03); t.add(gpu);
    fx.rgb.push(gpu.material);
  }
  return t;
}

// ---------- рисование экрана монитора ----------
export function drawScreen(tex, os, info) {
  const c = tex.userData.ctx, W = tex.userData.canvas.width, H = tex.userData.canvas.height;
  c.save();
  c.clearRect(0, 0, W, H);
  if (info.off) { c.fillStyle = '#050505'; c.fillRect(0, 0, W, H); c.restore(); tex.needsUpdate = true; return; }
  if (info.bsod) {
    c.fillStyle = '#0827a8'; c.fillRect(0, 0, W, H);
    c.fillStyle = '#fff'; c.font = 'bold 22px monospace'; c.fillText(':(  ПЕРЕГРЕВ', 30, 60);
    c.font = '14px monospace'; c.fillText('Включите вентилятор…', 30, 100);
    c.restore(); tex.needsUpdate = true; return;
  }
  const tb = 26;
  if (os === '95') {
    c.fillStyle = '#008080'; c.fillRect(0, 0, W, H);
  } else if (os === 'xp') {
    const g = c.createLinearGradient(0, 0, 0, H); g.addColorStop(0, '#3a7bd5'); g.addColorStop(0.6, '#9cc8f5'); c.fillStyle = g; c.fillRect(0, 0, W, H);
    c.fillStyle = '#fff8'; for (let i = 0; i < 4; i++) { c.beginPath(); c.ellipse(80 + i * 120, 60 + (i % 2) * 25, 50, 14, 0, 0, Math.PI * 2); c.fill(); }
    c.fillStyle = '#4caf2a'; c.beginPath(); c.ellipse(W * 0.55, H * 1.05, W * 0.9, H * 0.45, 0, 0, Math.PI * 2); c.fill();
    c.fillStyle = '#6cc63c'; c.beginPath(); c.ellipse(W * 0.3, H * 1.1, W * 0.6, H * 0.35, 0, 0, Math.PI * 2); c.fill();
  } else if (os === '7') {
    const g = c.createLinearGradient(0, 0, W, H); g.addColorStop(0, '#0b3c7a'); g.addColorStop(1, '#1a77c9'); c.fillStyle = g; c.fillRect(0, 0, W, H);
    for (let i = 0; i < 5; i++) { c.fillStyle = `rgba(120,220,255,${0.08 + i * 0.03})`; c.beginPath(); c.ellipse(W * 0.6, H * 0.5, 200 - i * 35, 60 - i * 9, -0.4, 0, Math.PI * 2); c.fill(); }
  } else if (os === '11') {
    c.fillStyle = '#0a1a3a'; c.fillRect(0, 0, W, H);
    const cols = ['#1e5bff', '#4aa3ff', '#7cc4ff', '#2563eb'];
    cols.forEach((col, i) => { const gr = c.createRadialGradient(W / 2, H * 0.55, 10, W / 2, H * 0.55, 160 - i * 25); gr.addColorStop(0, col); gr.addColorStop(1, 'transparent'); c.fillStyle = gr; c.beginPath(); c.ellipse(W / 2 + (i - 1.5) * 18, H * 0.55, 150 - i * 25, 90 - i * 12, i * 0.7, 0, Math.PI * 2); c.fill(); });
  } else {
    c.fillStyle = '#02040a'; c.fillRect(0, 0, W, H);
    c.strokeStyle = 'rgba(0,255,255,0.35)'; c.lineWidth = 1;
    for (let i = -10; i <= 10; i++) { c.beginPath(); c.moveTo(W / 2, H * 0.45); c.lineTo(W / 2 + i * 60, H); c.stroke(); }
    for (let i = 0; i < 8; i++) { const y = H * 0.45 + Math.pow(i / 8, 2) * H * 0.55; c.beginPath(); c.moveTo(0, y); c.lineTo(W, y); c.stroke(); }
    c.fillStyle = '#3ff'; c.font = 'bold 30px monospace'; c.textAlign = 'center'; c.fillText('КВАНТ·ОС', W / 2, H * 0.3); c.textAlign = 'left';
  }
  // иконки
  const icons = ['💬', '🖥', '📧', '🛒', '👥'];
  c.font = '20px sans-serif';
  icons.forEach((ic, i) => {
    const y = 18 + i * 44;
    if (os === '95') { c.fillStyle = '#c0c0c0'; c.fillRect(14, y, 28, 28); }
    c.fillText(ic, 15, y + 22);
    c.fillStyle = os === 'q' ? '#3ff' : '#fff'; c.font = '9px sans-serif'; c.fillText(['Чат', 'Удалёнка', 'Почта', 'Маркет', 'Команда'][i], 10, y + 38); c.font = '20px sans-serif';
  });
  // панель задач
  const tbCol = { '95': '#c0c0c0', xp: '#245edb', '7': 'rgba(10,30,60,0.75)', '11': 'rgba(20,25,40,0.85)', q: 'rgba(0,40,50,0.8)' }[os];
  c.fillStyle = tbCol; c.fillRect(0, H - tb, W, tb);
  if (os === '95') { c.fillStyle = '#fff'; c.fillRect(0, H - tb, W, 2); c.fillStyle = '#c0c0c0'; c.fillRect(3, H - tb + 4, 60, tb - 8); c.strokeStyle = '#000'; c.strokeRect(3, H - tb + 4, 60, tb - 8); c.fillStyle = '#000'; c.font = 'bold 12px sans-serif'; c.fillText('Пуск', 18, H - 8); }
  if (os === 'xp') { c.fillStyle = '#3c9a3c'; c.fillRect(0, H - tb, 80, tb); c.fillStyle = '#fff'; c.font = 'italic bold 14px sans-serif'; c.fillText('пуск', 22, H - 8); }
  if (os === '7') { c.fillStyle = '#4ab3ff'; c.beginPath(); c.arc(18, H - tb / 2, 10, 0, Math.PI * 2); c.fill(); }
  if (os === '11' || os === 'q') { c.fillStyle = os === 'q' ? '#3ff' : '#4aa3ff'; for (let i = 0; i < 5; i++) c.fillRect(W / 2 - 60 + i * 26, H - tb + 6, 16, 14); }
  c.fillStyle = os === '95' ? '#000' : '#fff'; c.font = '12px sans-serif'; c.textAlign = 'right'; c.fillText(info.clock || '', W - 8, H - 8); c.textAlign = 'left';
  // уведомление
  if (info.waiting > 0) {
    const bx = W - 190, by = H - tb - 62;
    c.fillStyle = os === '95' ? '#ffffe1' : os === 'q' ? 'rgba(0,60,70,0.95)' : 'rgba(255,255,255,0.95)';
    c.fillRect(bx, by, 180, 52);
    c.strokeStyle = os === 'q' ? '#3ff' : '#555'; c.strokeRect(bx, by, 180, 52);
    c.fillStyle = os === 'q' ? '#3ff' : '#111'; c.font = 'bold 14px sans-serif';
    c.fillText(`💬 Клиентов ждут: ${info.waiting}`, bx + 10, by + 22);
    c.font = '11px sans-serif'; c.fillText('Нажмите, чтобы сесть за ПК', bx + 10, by + 40);
  }
  // курсор мыши на экране
  const cx = info.cx || W * 0.58, cy = info.cy || H * 0.42, k = W / 300;
  c.save(); c.translate(cx, cy); c.scale(k, k);
  c.beginPath(); c.moveTo(0, 0); c.lineTo(0, 15); c.lineTo(3.5, 11.5); c.lineTo(6, 17.3); c.lineTo(8.3, 16.3); c.lineTo(5.8, 10.6); c.lineTo(10.5, 10.6); c.closePath();
  c.fillStyle = os === 'q' ? 'rgba(0,255,255,0.3)' : '#fff'; c.strokeStyle = os === 'q' ? '#0ff' : '#000'; c.lineWidth = 1.1; c.fill(); c.stroke();
  c.restore();
  if (os === '95') {
    c.fillStyle = 'rgba(0,0,0,0.12)'; for (let y = 0; y < H; y += 3) c.fillRect(0, y, W, 1);
    const v = c.createRadialGradient(W / 2, H / 2, H * 0.3, W / 2, H / 2, W * 0.65); v.addColorStop(0, 'transparent'); v.addColorStop(1, 'rgba(0,0,0,0.45)'); c.fillStyle = v; c.fillRect(0, 0, W, H);
  }
  c.restore();
  tex.needsUpdate = true;
}

// ---------- вентиляторы ----------
export function buildFan(tier) {
  const g = new THREE.Group();
  const big = tier >= 1;
  const bodyM = mat(big ? '#25272c' : '#ece6d6', { roughness: 0.5 });
  const bladeM = mat(big ? '#5a5f68' : '#7fb3e0', { roughness: 0.4, transparent: !big, opacity: big ? 1 : 0.85 });
  const R = big ? 0.13 : 0.1;
  const base = cyl(0.08, 0.095, 0.025, bodyM); base.position.y = 0.0125; g.add(base);
  const btns = box(0.05, 0.01, 0.03, mat(big ? '#555' : '#c33')); btns.position.set(0, 0.03, 0.05); g.add(btns);
  const poleH = big ? 0.25 : 0.18;
  const pole = cyl(0.012, 0.012, poleH, bodyM); pole.position.y = 0.025 + poleH / 2; g.add(pole);
  const head = new THREE.Group(); head.position.y = 0.025 + poleH + R * 0.4; g.add(head);
  const motor = sph(0.045, bodyM); motor.scale.set(1, 1, 1.4); motor.position.z = -0.05; head.add(motor);
  const blades = new THREE.Group(); blades.position.z = 0.0; head.add(blades);
  const hub = cyl(0.022, 0.022, 0.02, bodyM); hub.rotation.x = Math.PI / 2; blades.add(hub);
  const n = big ? 5 : 4;
  for (let i = 0; i < n; i++) {
    const p = new THREE.Group();
    const b = sph(1, bladeM, 12, 8); b.scale.set(R * 0.42, R * 0.22, 0.006); b.position.x = R * 0.5; b.rotation.x = 0.35;
    p.add(b); p.rotation.z = (i / n) * Math.PI * 2; blades.add(p);
  }
  const cageM = mat(big ? '#3a3d44' : '#d8d2c0', { metalness: 0.4, roughness: 0.4 });
  const rf = tor(R, 0.004, cageM); rf.position.z = 0.025; head.add(rf);
  const rb = tor(R, 0.004, cageM); rb.position.z = -0.025; head.add(rb);
  for (let i = 0; i < 12; i++) {
    const a = (i / 12) * Math.PI * 2;
    const s = box(0.003, 0.003, 0.05, cageM); s.position.set(Math.cos(a) * R, Math.sin(a) * R, 0); head.add(s);
    const sp = box(0.002, R, 0.002, cageM); sp.position.set(Math.cos(a) * R / 2, Math.sin(a) * R / 2, 0.026); sp.rotation.z = a - Math.PI / 2; head.add(sp);
  }
  const badge = cyl(0.02, 0.02, 0.004, mat(big ? '#e33' : '#36c')); badge.rotation.x = Math.PI / 2; badge.position.z = 0.028; head.add(badge);
  return { group: g, head, blades };
}

export function buildAC() {
  const g = new THREE.Group();
  const body = box(0.9, 0.28, 0.22, mat('#f4f6f8', { roughness: 0.4 }), 0.04); g.add(body);
  const flapPivot = new THREE.Group(); flapPivot.position.set(0, -0.1, 0.1); g.add(flapPivot);
  const flap = box(0.8, 0.012, 0.06, mat('#e1e5ea')); flap.position.z = 0.02; flapPivot.add(flap);
  const led = box(0.02, 0.01, 0.005, glow('#3af', 2)); led.position.set(0.35, 0.05, 0.111); g.add(led);
  const logo = box(0.12, 0.02, 0.004, mat('#9aa')); logo.position.set(-0.3, 0.06, 0.111); g.add(logo);
  return { group: g, flap: flapPivot, led };
}

// ---------- роутеры / модемы ----------
export function buildRouter(tier) {
  const g = new THREE.Group();
  const leds = [];
  const ledRow = (n, y, z, w) => {
    for (let i = 0; i < n; i++) {
      const m = glow(i === 0 ? '#3f3' : '#3f3', 2);
      const l = box(0.008, 0.006, 0.004, m); l.position.set(-w / 2 + 0.015 + i * ((w - 0.03) / (n - 1)), y, z); g.add(l); leds.push(m);
    }
  };
  if (tier === 0) {
    const b = box(0.16, 0.035, 0.12, mat('#d4cbb0'), 0.008); b.position.y = 0.0175; g.add(b);
    const lbl = box(0.06, 0.002, 0.03, mat('#555')); lbl.position.set(0.03, 0.036, 0); g.add(lbl);
    ledRow(6, 0.022, 0.061, 0.14);
  } else if (tier <= 3) {
    const col = ['#fff', '#f2f2f2', '#1b1c20', '#141414'][tier];
    const w = [0, 0.16, 0.2, 0.24][tier];
    const b = box(w, 0.035, 0.14, mat(col, { roughness: 0.35 }), 0.012); b.position.y = 0.0175; g.add(b);
    if (tier === 3) { const acc = box(w * 0.8, 0.004, 0.004, glow('#f22', 2)); acc.position.set(0, 0.03, 0.071); g.add(acc); leds.push(acc.material); }
    ledRow(tier + 3, 0.02, 0.071, w);
    const ant = [0, 1, 2, 4][tier];
    for (let i = 0; i < ant; i++) {
      const a = cyl(0.007, 0.009, 0.16, mat(tier === 3 ? '#111' : col)); const x = ant === 1 ? w / 2 - 0.02 : -w / 2 + 0.02 + i * ((w - 0.04) / (ant - 1));
      a.position.set(x, 0.035 + 0.08, -0.06); a.rotation.z = (i - (ant - 1) / 2) * 0.18; g.add(a);
    }
  } else {
    const base = cyl(0.05, 0.06, 0.03, mat('#e8e8ee', { metalness: 0.3, roughness: 0.3 })); base.position.y = 0.015; g.add(base);
    const arm = cyl(0.008, 0.008, 0.1, mat('#bbb', { metalness: 0.6 })); arm.position.y = 0.08; g.add(arm);
    const dishGeo = new THREE.SphereGeometry(0.09, 24, 12, 0, Math.PI * 2, 0, Math.PI / 3.2);
    const dish = new THREE.Mesh(dishGeo, new THREE.MeshStandardMaterial({ color: '#f4f4f8', metalness: 0.4, roughness: 0.3, side: THREE.DoubleSide }));
    dish.castShadow = true; dish.rotation.x = -Math.PI / 2 - 0.6; dish.position.set(0, 0.16, 0.04); g.add(dish);
    const feed = sph(0.012, glow('#3ff', 3)); feed.position.set(0, 0.19, 0.1); g.add(feed); leds.push(feed.material);
    const ring = tor(0.055, 0.004, glow('#3ff', 2)); ring.rotation.x = Math.PI / 2; ring.position.y = 0.031; g.add(ring); leds.push(ring.material);
  }
  return { group: g, leds };
}

// ---------- мелочи на столе ----------
export function buildPhone() {
  const g = new THREE.Group();
  const dark = mat('#2b2d33', { roughness: 0.5 });
  const base = box(0.19, 0.06, 0.16, dark, 0.02); base.position.y = 0.03; g.add(base);
  const keys = canvasTex(64, 64, (c) => { c.fillStyle = '#2b2d33'; c.fillRect(0, 0, 64, 64); c.fillStyle = '#ddd'; for (let r = 0; r < 4; r++) for (let k = 0; k < 3; k++) c.fillRect(8 + k * 18, 6 + r * 15, 12, 10); });
  const kp = new THREE.Mesh(new THREE.PlaneGeometry(0.07, 0.07), new THREE.MeshStandardMaterial({ map: keys }));
  kp.rotation.x = -Math.PI / 2 + 0.25; kp.position.set(0.045, 0.062, 0.035); g.add(kp);
  const handset = new THREE.Group(); handset.position.set(-0.02, 0.075, -0.01); g.add(handset);
  const hb = box(0.2, 0.03, 0.045, dark, 0.014); handset.add(hb);
  const e1 = cyl(0.028, 0.03, 0.03, dark); e1.position.set(-0.085, -0.01, 0); handset.add(e1);
  const e2 = e1.clone(); e2.position.x = 0.085; handset.add(e2);
  const light = box(0.015, 0.006, 0.004, glow('#f33', 0.2)); light.position.set(0.075, 0.05, 0.081); g.add(light);
  // витой провод
  const pts = [];
  for (let i = 0; i <= 80; i++) {
    const t = i / 80;
    const x = -0.11 - t * 0.02, y = 0.05 - Math.sin(t * Math.PI) * 0.04, z = -0.01 + t * 0.08;
    pts.push(new THREE.Vector3(x + Math.cos(t * 50) * 0.008, y + Math.sin(t * 50) * 0.008, z));
  }
  const cord = new THREE.Mesh(new THREE.TubeGeometry(new THREE.CatmullRomCurve3(pts), 160, 0.0025, 5), dark);
  g.add(cord);
  return { group: g, handset, light: light.material };
}

export function buildMug() {
  const g = new THREE.Group();
  const prof = [[0, 0], [0.038, 0], [0.041, 0.004], [0.042, 0.1], [0.037, 0.1], [0.035, 0.01], [0, 0.01]].map(([x, y]) => new THREE.Vector2(x, y));
  const m = mat('#6d3fb3', { roughness: 0.35 });
  const body = new THREE.Mesh(new THREE.LatheGeometry(prof, 28), m); body.castShadow = true; g.add(body);
  const handle = tor(0.026, 0.007, m, Math.PI); handle.position.set(0.042, 0.05, 0); handle.rotation.z = -Math.PI / 2; g.add(handle);
  const logo = new THREE.Mesh(new THREE.PlaneGeometry(0.03, 0.03), new THREE.MeshStandardMaterial({ map: canvasTex(64, 64, (c) => { c.fillStyle = '#fff'; c.font = 'bold 44px sans-serif'; c.textAlign = 'center'; c.fillText('₽', 32, 48); }), transparent: true }));
  logo.position.set(0, 0.055, 0.0425); g.add(logo);
  const coffee = new THREE.Mesh(new THREE.CircleGeometry(0.035, 24), mat('#4a2a12', { roughness: 0.2 }));
  coffee.rotation.x = -Math.PI / 2; coffee.position.y = 0.088; coffee.visible = false; g.add(coffee);
  const steamTex = canvasTex(64, 64, (c) => { const gr = c.createRadialGradient(32, 32, 2, 32, 32, 30); gr.addColorStop(0, 'rgba(255,255,255,0.7)'); gr.addColorStop(1, 'rgba(255,255,255,0)'); c.fillStyle = gr; c.fillRect(0, 0, 64, 64); });
  const steam = [];
  for (let i = 0; i < 4; i++) {
    const s = new THREE.Sprite(new THREE.SpriteMaterial({ map: steamTex, transparent: true, depthWrite: false, opacity: 0 }));
    s.scale.set(0.05, 0.05, 1); s.position.y = 0.1; s.userData.ph = i / 4; g.add(s); steam.push(s);
  }
  return { group: g, coffee, steam };
}

export function buildBell() {
  const g = new THREE.Group();
  const base = cyl(0.05, 0.055, 0.012, mat('#3a2412', { roughness: 0.6 })); base.position.y = 0.006; g.add(base);
  const dome = new THREE.Mesh(new THREE.SphereGeometry(0.04, 24, 10, 0, Math.PI * 2, 0, Math.PI / 2), mat('#e8b84a', { metalness: 0.9, roughness: 0.25 }));
  dome.castShadow = true; dome.position.y = 0.012; g.add(dome);
  const stem = cyl(0.004, 0.004, 0.02, mat('#c99a30', { metalness: 0.9, roughness: 0.3 })); stem.position.y = 0.06; g.add(stem);
  const btn = cyl(0.01, 0.01, 0.006, mat('#e8b84a', { metalness: 0.9, roughness: 0.25 })); btn.position.y = 0.07; g.add(btn);
  return { group: g, btn };
}

export function buildPlant() {
  const g = new THREE.Group();
  const pot = cyl(0.07, 0.055, 0.11, mat('#c1653b', { roughness: 0.8 })); pot.position.y = 0.055; g.add(pot);
  const rim = cyl(0.075, 0.075, 0.018, mat('#b55a32')); rim.position.y = 0.105; g.add(rim);
  const soil = cyl(0.066, 0.066, 0.01, mat('#3b2a1c')); soil.position.y = 0.106; g.add(soil);
  const stem = cyl(0.006, 0.008, 0.22, mat('#5b4a2e')); stem.position.y = 0.21; g.add(stem);
  const leaves = new THREE.Group(); leaves.position.y = 0.1; g.add(leaves);
  const greens = ['#2f7d32', '#388e3c', '#2e6b2f', '#43a047'];
  for (let i = 0; i < 18; i++) {
    const a = i * 2.4, h = 0.06 + (i / 18) * 0.24, r = 0.02 + Math.sin(i) * 0.01;
    const p = new THREE.Group(); p.position.set(Math.cos(a) * r, h, Math.sin(a) * r); p.rotation.y = -a;
    const l = sph(1, mat(greens[i % 4], { roughness: 0.6 }), 10, 6); l.scale.set(0.05, 0.007, 0.028); l.position.x = 0.045; l.rotation.z = 0.35;
    p.add(l); leaves.add(p);
  }
  return { group: g, leaves };
}

export function buildLamp() {
  const g = new THREE.Group();
  const m = mat('#1f2a44', { roughness: 0.4, metalness: 0.4 });
  const base = cyl(0.07, 0.075, 0.02, m); base.position.y = 0.01; g.add(base);
  const a1 = new THREE.Group(); a1.position.y = 0.02; a1.rotation.z = -0.25; g.add(a1);
  const r1 = cyl(0.008, 0.008, 0.3, m); r1.position.y = 0.15; a1.add(r1);
  const j = sph(0.015, m); j.position.y = 0.3; a1.add(j);
  const a2 = new THREE.Group(); a2.position.y = 0.3; a2.rotation.z = 1.9; a1.add(a2);
  const r2 = cyl(0.007, 0.007, 0.24, m); r2.position.y = 0.12; a2.add(r2);
  const head = new THREE.Group(); head.position.y = 0.24; head.rotation.z = 0.9; a2.add(head);
  const shadeM = new THREE.Mesh(new THREE.CylinderGeometry(0.02, 0.065, 0.09, 20, 1, true), new THREE.MeshStandardMaterial({ color: '#1f2a44', side: THREE.DoubleSide, metalness: 0.4, roughness: 0.4 }));
  shadeM.position.y = -0.04; head.add(shadeM);
  const bulb = sph(0.022, glow('#ffe7a8', 2)); bulb.position.y = -0.06; head.add(bulb);
  const light = new THREE.PointLight('#ffd99a', 0.8, 1.6, 1.5); light.position.y = -0.1; head.add(light);
  return { group: g, bulb, light };
}

export function buildCat() {
  const g = new THREE.Group();
  const w = mat('#fbfaf5', { roughness: 0.4 }), red = mat('#d32f2f'), gold = mat('#f2c230', { metalness: 0.8, roughness: 0.3 }), blk = mat('#111');
  const body = sph(0.045, w); body.scale.set(1, 1.05, 0.85); body.position.y = 0.045; g.add(body);
  const head = sph(0.042, w); head.scale.set(1.1, 0.95, 0.9); head.position.y = 0.115; g.add(head);
  [-1, 1].forEach((s) => {
    const ear = new THREE.Mesh(new THREE.ConeGeometry(0.015, 0.028, 8), w); ear.position.set(s * 0.028, 0.155, 0); ear.rotation.z = -s * 0.3; g.add(ear);
    const inner = new THREE.Mesh(new THREE.ConeGeometry(0.008, 0.016, 8), mat('#f6a')); inner.position.set(s * 0.028, 0.152, 0.007); inner.rotation.z = -s * 0.3; g.add(inner);
    const eye = box(0.014, 0.004, 0.003, blk); eye.position.set(s * 0.017, 0.12, 0.038); eye.rotation.z = s * 0.2; g.add(eye);
  });
  const nose = sph(0.005, mat('#f6a')); nose.position.set(0, 0.108, 0.04); g.add(nose);
  const collar = tor(0.035, 0.006, red); collar.rotation.x = Math.PI / 2; collar.position.y = 0.083; g.add(collar);
  const bell = sph(0.008, gold); bell.position.set(0, 0.075, 0.036); g.add(bell);
  const coin = cyl(0.025, 0.025, 0.006, gold); coin.rotation.x = Math.PI / 2; coin.position.set(-0.02, 0.05, 0.04); g.add(coin);
  const pawPivot = new THREE.Group(); pawPivot.position.set(0.04, 0.09, 0.01); g.add(pawPivot);
  const paw = cap(0.012, 0.04, w); paw.position.y = 0.03; pawPivot.add(paw);
  return { group: g, paw: pawPivot };
}

export function buildTree() {
  const g = new THREE.Group();
  const pot = cyl(0.12, 0.1, 0.16, mat('#b71c1c')); pot.position.y = 0.08; g.add(pot);
  const greens = mat('#1b5e20', { roughness: 0.8 });
  [[0.42, 0.4, 0.38], [0.34, 0.36, 0.62], [0.24, 0.3, 0.84], [0.14, 0.24, 1.02]].forEach(([r, h, y]) => {
    const c = new THREE.Mesh(new THREE.ConeGeometry(r, h, 9), greens); c.castShadow = true; c.position.y = y; g.add(c);
  });
  const star = new THREE.Mesh(new THREE.OctahedronGeometry(0.05), glow('#ffd54a', 2.5)); star.position.y = 1.17; g.add(star);
  const balls = [];
  const cols = ['#f44', '#4af', '#fd4', '#4f8', '#f4f'];
  for (let i = 0; i < 22; i++) {
    const t = i / 22, y = 0.25 + t * 0.85, r = 0.4 * (1 - t * 0.85) * 0.88, a = i * 2.3;
    const m = glow(cols[i % cols.length], 1.5);
    const b = sph(0.022, m, 8, 6); b.position.set(Math.cos(a) * r, y, Math.sin(a) * r); g.add(b); balls.push(m);
  }
  return { group: g, balls, star };
}

export function buildSecondMonitor(tier) {
  const g = new THREE.Group();
  const tex = canvasTex(256, 160, (c, W, H) => {
    c.fillStyle = '#fff'; c.fillRect(0, 0, W, H);
    c.fillStyle = '#1e7a3c'; c.fillRect(0, 0, W, 14);
    c.fillStyle = '#fff'; c.font = '10px sans-serif'; c.fillText('Таблица.xls — Отчёт за квартал', 6, 11);
    c.strokeStyle = '#ccc';
    for (let x = 0; x < W; x += 32) { c.beginPath(); c.moveTo(x, 14); c.lineTo(x, H); c.stroke(); }
    for (let y = 14; y < H; y += 12) { c.beginPath(); c.moveTo(0, y); c.lineTo(W, y); c.stroke(); }
    c.fillStyle = '#333'; c.font = '8px sans-serif';
    for (let r = 0; r < 6; r++) for (let k = 0; k < 4; k++) c.fillText(String(Math.floor(Math.random() * 90000) + 1000), 4 + k * 32, 24 + r * 12);
    const bars = [40, 65, 30, 80, 55];
    bars.forEach((b, i) => { c.fillStyle = ['#4a7', '#3a8fd8', '#e94', '#c4c', '#4cc'][i]; c.fillRect(150 + i * 20, H - 8 - b, 14, b); });
  });
  const dark = mat(tier === 0 ? '#d8cfb2' : '#1a1b1f', { roughness: 0.4 });
  const base = cyl(0.08, 0.09, 0.012, dark); base.scale.z = 0.7; base.position.y = 0.006; g.add(base);
  const neck = box(0.035, 0.12, 0.02, dark); neck.position.set(0, 0.07, -0.02); g.add(neck);
  const panel = box(0.42, 0.27, 0.03, dark, 0.008); panel.position.y = 0.24; g.add(panel);
  const scr = new THREE.Mesh(new THREE.PlaneGeometry(0.4, 0.25), new THREE.MeshBasicMaterial({ map: tex, toneMapped: false }));
  scr.position.set(0, 0.24, 0.0155); g.add(scr);
  return g;
}

// ---------- люди ----------
export function buildPerson(o) {
  const root = new THREE.Group();
  const skin = mat(o.skin || '#f1c7a4', { roughness: 0.6 });
  const shirt = mat(o.shirt, { roughness: 0.8 });
  const sleeve = mat(o.sleeve || o.shirt, { roughness: 0.8 });
  const pants = mat(o.pants, { roughness: 0.8 });
  const hairM = mat(o.hair || '#3a2a1c', { roughness: 0.9 });
  const blk = mat('#151515');
  const hips = new THREE.Group(); hips.position.y = 0.92; root.add(hips);
  hips.add(at(box(0.34, 0.14, 0.22, pants, 0.05), 0, 0, 0));
  const spine = new THREE.Group(); spine.position.y = 0.04; hips.add(spine);
  spine.add(at(box(0.38, 0.5, 0.23, shirt, 0.08), 0, 0.27, 0));
  if (o.vest) spine.add(at(box(0.39, 0.38, 0.235, mat(o.vest, { roughness: 0.7 }), 0.07), 0, 0.22, 0.002));
  if (o.hood) spine.add(at(box(0.26, 0.1, 0.1, shirt, 0.04), 0, 0.5, -0.1));
  spine.add(at(cyl(0.05, 0.055, 0.08, skin), 0, 0.55, 0));
  if (o.bowtie) {
    const bm = mat('#111');
    [-1, 1].forEach((s) => { const c = new THREE.Mesh(new THREE.ConeGeometry(0.025, 0.04, 6), bm); c.rotation.z = s * Math.PI / 2; c.position.set(s * 0.02, 0.5, 0.12); spine.add(c); });
  }
  if (o.necklace) for (let i = 0; i < 9; i++) { const a = -0.9 + i * 0.225; spine.add(at(sph(0.011, mat('#f5f0e0', { roughness: 0.2 }), 8, 6), Math.sin(a) * 0.09, 0.47 - Math.cos(a) * 0.04 + 0.04, 0.11)); }
  const head = new THREE.Group(); head.position.y = 0.58; spine.add(head);
  const skull = sph(0.13, skin, 20, 16); skull.scale.set(1, 1.08, 1); skull.position.y = 0.12; head.add(skull);
  [-1, 1].forEach((s) => {
    head.add(at(sph(0.017, blk, 8, 6), s * 0.045, 0.135, 0.115));
    head.add(at(box(0.045, 0.009, 0.01, hairM), s * 0.047, 0.175, 0.118, 0, 0, -s * 0.1));
    head.add(at(sph(0.025, skin, 8, 6), s * 0.13, 0.12, 0));
  });
  head.add(at(sph(0.022, skin, 8, 6), 0, 0.105, 0.13));
  const mouth = box(0.05, 0.009, 0.01, mat('#9c3b3b')); mouth.position.set(0, 0.06, 0.118); head.add(mouth);
  // волосы
  if (o.hairType === 'messy') {
    const cap1 = sph(0.138, hairM, 16, 10); cap1.scale.set(1.02, 0.7, 1.05); cap1.position.set(0, 0.18, -0.01); head.add(cap1);
    for (let i = 0; i < 7; i++) head.add(at(sph(0.04, hairM, 8, 6), Math.cos(i) * 0.08, 0.26 + Math.sin(i * 3) * 0.015, Math.sin(i) * 0.07 - 0.01));
    head.add(at(box(0.2, 0.04, 0.06, hairM, 0.02), 0, 0.22, 0.09, 0.4));
  } else if (o.hairType === 'bun') {
    const cap1 = sph(0.138, hairM, 16, 10); cap1.scale.set(1.04, 0.78, 1.06); cap1.position.set(0, 0.17, -0.015); head.add(cap1);
    head.add(at(sph(0.065, hairM, 12, 8), 0, 0.27, -0.09));
    [-1, 1].forEach((s) => head.add(at(box(0.04, 0.16, 0.1, hairM, 0.02), s * 0.12, 0.1, -0.03)));
  } else if (o.hairType === 'slick') {
    const cap1 = sph(0.136, hairM, 16, 10); cap1.scale.set(1.02, 0.62, 1.04); cap1.position.set(0, 0.19, -0.015); head.add(cap1);
    head.add(at(box(0.07, 0.014, 0.012, hairM, 0.005), 0, 0.083, 0.128));
  } else if (o.hairType === 'bald') {
    head.add(at(box(0.2, 0.05, 0.12, hairM, 0.02), 0, 0.1, -0.08));
  }
  if (o.glasses) {
    const gm = mat('#222', { metalness: 0.5 });
    [-1, 1].forEach((s) => head.add(at(tor(0.028, 0.005, gm), s * 0.046, 0.135, 0.125)));
    head.add(at(box(0.03, 0.005, 0.005, gm), 0, 0.14, 0.127));
  }
  if (o.headphones) {
    const hm = mat('#c62828', { roughness: 0.4 });
    const band = tor(0.145, 0.012, mat('#222'), Math.PI); band.position.y = 0.13; head.add(band);
    [-1, 1].forEach((s) => { const cup = cyl(0.045, 0.045, 0.035, hm); cup.rotation.z = Math.PI / 2; cup.position.set(s * 0.145, 0.12, 0); head.add(cup); });
  }
  // руки
  const shoulders = [], elbows = [];
  [-1, 1].forEach((s) => {
    const sh = new THREE.Group(); sh.position.set(s * 0.245, 0.47, 0); spine.add(sh);
    sh.add(at(cap(0.055, 0.2, sleeve), 0, -0.15, 0));
    const el = new THREE.Group(); el.position.y = -0.3; sh.add(el);
    el.add(at(cap(0.047, 0.17, o.shortSleeve ? skin : sleeve), 0, -0.12, 0));
    el.add(at(sph(0.045, skin, 10, 8), 0, -0.26, 0));
    shoulders.push(sh); elbows.push(el);
  });
  // ноги
  const hipsJ = [], knees = [];
  [-1, 1].forEach((s) => {
    const hp = new THREE.Group(); hp.position.set(s * 0.1, -0.02, 0); hips.add(hp);
    hp.add(at(cap(0.072, 0.3, pants), 0, -0.225, 0));
    const kn = new THREE.Group(); kn.position.y = -0.45; hp.add(kn);
    kn.add(at(cap(0.062, 0.3, pants), 0, -0.22, 0));
    kn.add(at(box(0.1, 0.07, 0.2, mat(o.shoes || '#222'), 0.03), 0, -0.43, 0.04));
    hipsJ.push(hp); knees.push(kn);
  });
  root.userData.rig = { hips, spine, head, shoulders, elbows, legs: hipsJ, knees };
  return root;
}

export function sitPose(person) {
  const r = person.userData.rig;
  r.hips.position.y = 0.5;
  r.legs.forEach((l) => { l.rotation.x = -Math.PI / 2; });
  r.knees.forEach((k) => { k.rotation.x = Math.PI / 2; });
  r.shoulders.forEach((s) => { s.rotation.x = -0.45; });
  r.elbows.forEach((e) => { e.rotation.x = -1.1; });
}

export function buildChair(color = '#2d3240') {
  const g = new THREE.Group();
  const m = mat(color, { roughness: 0.7 }), metal = mat('#555', { metalness: 0.6, roughness: 0.4 });
  g.add(at(box(0.46, 0.07, 0.46, m, 0.03), 0, 0.44, -0.02));
  g.add(at(box(0.44, 0.55, 0.07, m, 0.03), 0, 0.78, -0.25, -0.12));
  g.add(at(cyl(0.025, 0.025, 0.36, metal), 0, 0.22, -0.02));
  for (let i = 0; i < 5; i++) { const a = (i / 5) * Math.PI * 2; const l = box(0.04, 0.03, 0.28, metal); l.position.set(Math.sin(a) * 0.14, 0.04, Math.cos(a) * 0.14 - 0.02); l.rotation.y = a; g.add(l); }
  return g;
}

export function buildDesk(w = 1.2, d = 0.7, top = '#a77b52') {
  const g = new THREE.Group();
  const tm = mat(top, { roughness: 0.55 }), leg = mat('#3b3f47', { metalness: 0.5, roughness: 0.4 });
  g.add(at(box(w, 0.04, d, tm, 0.012), 0, 0.73, 0));
  [-1, 1].forEach((s) => g.add(at(box(0.04, 0.71, d - 0.08, leg), s * (w / 2 - 0.05), 0.355, 0)));
  g.add(at(box(w - 0.12, 0.3, 0.02, leg), 0, 0.5, -d / 2 + 0.05));
  return g;
}

export function buildLaptop(screenColor = '#e9f2ff') {
  const g = new THREE.Group();
  const m = mat('#9aa0a8', { metalness: 0.6, roughness: 0.35 });
  g.add(at(box(0.32, 0.014, 0.22, m, 0.005), 0, 0.007, 0));
  const lid = new THREE.Group(); lid.position.set(0, 0.014, -0.105); lid.rotation.x = -0.28; g.add(lid);
  lid.add(at(box(0.32, 0.21, 0.01, m, 0.005), 0, 0.105, -0.005));
  const tex = canvasTex(128, 80, (c, W, H) => { c.fillStyle = screenColor; c.fillRect(0, 0, W, H); c.fillStyle = '#1e7a3c'; c.fillRect(0, 0, W, 8); c.strokeStyle = '#bbb'; for (let y = 8; y < H; y += 8) { c.beginPath(); c.moveTo(0, y); c.lineTo(W, y); c.stroke(); } for (let x = 0; x < W; x += 24) { c.beginPath(); c.moveTo(x, 8); c.lineTo(x, H); c.stroke(); } });
  const scr = new THREE.Mesh(new THREE.PlaneGeometry(0.29, 0.18), new THREE.MeshBasicMaterial({ map: tex, toneMapped: false }));
  scr.position.set(0, 0.105, 0.0005); lid.add(scr);
  return g;
}
