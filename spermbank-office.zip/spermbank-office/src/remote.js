// ===== «ДальнийСтол»: удалённое управление компьютером клиента =====
import { S, rand, randi, pick, shuffle, net, remotePing, online, rankIdx, esc } from './state.js';
import { NETS } from './data.js';
import { sfx } from './audio.js';
import { G } from './game.js';
import { h, ARROW } from './ui.js';

const THEMES = ['95', '95', 'xp', 'xp', 'xp', '7', '7', '11'];

export function runRemote(host, client) {
  return new Promise((resolve) => {
    const root = h(`<div class="rd"><div class="rd-connect">
      <div class="rd-logo">🛰 ДальнийСтол</div>
      <div style="font-size:13px">Удалённое подключение к клиенту<br><b>${esc(client.sc.av)} ${esc(client.sc.who)}</b></div>
      <div style="font-size:12px;opacity:.7">ID партнёра</div>
      <div class="rd-id">${client.remoteId}</div>
      <button class="ob pri rd-go" style="font-size:16px;padding:10px 24px">Подключиться</button>
      <div class="rd-status"></div><div class="rd-prog"><i></i></div>
      <div style="font-size:11px;opacity:.6">Ваш интернет: ${NETS[S.net].name} · пинг ~${Math.round(remotePing())} мс</div>
    </div></div>`);
    host.innerHTML = ''; host.appendChild(root);
    const status = root.querySelector('.rd-status'), prog = root.querySelector('.rd-prog i'), go = root.querySelector('.rd-go');
    let finished = false;
    const end = (res) => { if (finished) return; finished = true; G.remoteActive = false; resolve(res); };
    host._abort = () => end({ ok: false, mistakes: 0, aborted: true });

    go.onclick = () => {
      sfx.click();
      if (online.outage > 0) { status.textContent = '❌ Нет подключения к интернету. Подождите…'; sfx.error(); return; }
      go.disabled = true;
      const dur = NETS[S.net].connect;
      if (S.net === 0) sfx.modem(dur / 1000);
      const msgs = S.net === 0 ? ['☎ Набор номера…', '📠 Пиииу-кшшшш…', '🤝 Рукопожатие модемов…', '🔐 Проверка пароля…'] : ['🔎 Поиск партнёра…', '🔐 Шифрование канала…', '🖥 Получение картинки…'];
      const t0 = performance.now();
      const iv = setInterval(() => {
        if (finished) { clearInterval(iv); return; }
        const k = Math.min(1, (performance.now() - t0) / dur);
        prog.style.width = k * 100 + '%';
        status.textContent = msgs[Math.min(msgs.length - 1, Math.floor(k * msgs.length))];
        if (k >= 1) { clearInterval(iv); startSession(); }
      }, 80);
    };

    function startSession() {
      G.remoteActive = true;
      const theme = pick(THEMES);
      const ping = remotePing();
      const timeTotal = 55 + Math.min(25, ping / 1000 * 22);
      root.innerHTML = `<div class="rd-bar"><span>🖥 ${esc(client.sc.who)}</span><span class="rd-ping">📶 ${Math.round(ping)} мс</span><span class="rd-pend"></span><span class="sp"></span><span class="rd-time">⏱ ${Math.ceil(timeTotal)}</span><button class="ob rd-off">Отключиться</button></div>
        <div class="rd-task"></div><div class="rd-screen t-${theme} ${ping > 300 ? 'rd-lag' : ''}"></div>`;
      const scr = root.querySelector('.rd-screen');
      // курсор на компьютере клиента: догоняет касание с задержкой пинга
      const rc = h(`<div class="rd-cursor ${ping > 700 ? 'jerky' : ''}">${ARROW()}<small>вы</small></div>`);
      scr.appendChild(rc);
      let lastDelay = 0, lastAt = 0;
      const lagDelay = () => ping * (0.9 + Math.random() * 0.35) + (S.net === 0 && Math.random() < 0.15 ? 900 : 0);
      scr.addEventListener('pointerdown', (e) => {
        if (dropped) return;
        const r = scr.getBoundingClientRect();
        const x = e.clientX - r.left, y = e.clientY - r.top;
        lastDelay = lagDelay(); lastAt = performance.now();
        setTimeout(() => { rc.style.left = x + 'px'; rc.style.top = y + 'px'; }, Math.max(0, lastDelay - 160));
      }, true);
      const taskEl = root.querySelector('.rd-task'), timeEl = root.querySelector('.rd-time'), pendEl = root.querySelector('.rd-pend');
      let tLeft = timeTotal, mistakes = 0, pending = 0, dropped = false, over = false;
      const valera = S.workers[0].lvl >= 3;
      // возможный обрыв связи
      const dropAt = Math.random() < NETS[S.net].drop ? rand(0.3, 0.7) * timeTotal : -1;
      let didDrop = false;

      const tick = setInterval(() => {
        if (over || finished) { clearInterval(tick); return; }
        if (!dropped) tLeft -= 0.25;
        timeEl.textContent = '⏱ ' + Math.max(0, Math.ceil(tLeft));
        if (!didDrop && dropAt > 0 && timeTotal - tLeft >= dropAt) {
          didDrop = true; dropped = true;
          const d = h('<div class="rd-drop"><div>📵 Соединение потеряно!<br><small>Переподключение…</small></div></div>');
          scr.appendChild(d); sfx.error();
          if (S.net === 0) sfx.modem(2.5);
          setTimeout(() => { d.remove(); dropped = false; }, Math.max(2500, NETS[S.net].connect * 0.6));
        }
        if (tLeft <= 0) fail('⏰ Время вышло');
      }, 250);

      const api = {
        scr, valera,
        task(t) { taskEl.textContent = '🎯 ' + t; },
        // действие с задержкой пинга
        act(fn) {
          return (e) => {
            if (over || dropped) return;
            if (e && e.stopPropagation) e.stopPropagation();
            const r = scr.getBoundingClientRect();
            const x = (e && e.clientX ? e.clientX : r.left + r.width / 2) - r.left, y = (e && e.clientY ? e.clientY : r.top + r.height / 2) - r.top;
            const rp = h('<div class="rd-ripple"></div>'); rp.style.left = x + 'px'; rp.style.top = y + 'px'; scr.appendChild(rp); setTimeout(() => rp.remove(), 600);
            sfx.key();
            pending++; pendEl.textContent = '⏳';
            const delay = performance.now() - lastAt < 800 ? lastDelay : lagDelay();
            setTimeout(() => {
              pending--; if (!pending) pendEl.textContent = '';
              if (over || finished) return;
              fn(e);
            }, delay);
          };
        },
        mistake(msg) { mistakes++; sfx.error(); if (msg) api.flash(msg); },
        flash(msg) { const f = h(`<div style="position:absolute;left:50%;top:10px;transform:translateX(-50%);background:#c62828;color:#fff;padding:5px 10px;border-radius:6px;z-index:46;font-size:12px">${esc(msg)}</div>`); scr.appendChild(f); setTimeout(() => f.remove(), 1400); },
        done() { win(); },
      };

      function win() {
        if (over) return; over = true; clearInterval(tick);
        sfx.success();
        scr.appendChild(h(`<div class="rd-done">✅ Задача выполнена!${mistakes ? `<br><small style="font-size:13px">Ошибок: ${mistakes}</small>` : ''}</div>`));
        setTimeout(() => end({ ok: true, mistakes }), 1300);
      }
      function fail(msg) {
        if (over) return; over = true; clearInterval(tick);
        sfx.fail();
        scr.appendChild(h(`<div class="rd-done fail">❌ ${esc(msg)}</div>`));
        setTimeout(() => end({ ok: false, mistakes }), 1300);
      }
      root.querySelector('.rd-off').onclick = () => fail('Сессия прервана');
      (TASKS[client.sc.remote] || TASKS.popups)(api);
    }
  });
}

// ---------- задачи ----------
function desktopIcons(scr, list) {
  const box = h('<div class="rd-icons"></div>');
  list.forEach((it) => { const b = h(`<button class="rd-ico"><span class="ic">${it[0]}</span><span>${esc(it[1])}</span></button>`); box.appendChild(b); it.el = b; });
  scr.appendChild(box);
  return box;
}

const TASKS = {
  popups(api) {
    desktopIcons(api.scr, [['🗂', 'Мой компьютер'], ['🗑', 'Корзина'], ['🏦', 'Банк-клиент'], ['🧾', 'Касса']]);
    const ads = [
      ['ВЫ ВЫИГРАЛИ!', 'СПЕРМофон 15 Про за 1 рубль!', 'ЗАБРАТЬ ПРИЗ'],
      ['ВНИМАНИЕ!!!', 'Ваш ПК заражён 47 вирусами!', 'ВЫЛЕЧИТЬ'],
      ['Казино «Три топора»', 'Бонус 100 000 ₽ за регистрацию', 'ИГРАТЬ'],
      ['Похудей за 1 день', 'Врачи в шоке от этого метода', 'УЗНАТЬ'],
      ['Ускоритель ПК', 'Ускорьте компьютер в 1000 раз!', 'СКАЧАТЬ'],
      ['Одинокие бухгалтеры', 'В вашем районе. Ждут сверки', 'НАПИСАТЬ'],
      ['Кредит за 5 минут', 'Без паспорта и без совести', 'ОФОРМИТЬ'],
      ['Курс «Миллион за неделю»', 'Инфоцыган Аркадий научит', 'ХОЧУ'],
    ];
    let left = 0, total = 0;
    const W = api.scr.clientWidth || 600, H = api.scr.clientHeight || 300;
    const upd = () => api.task(`Закройте рекламу крестиком ✕ (осталось: ${left}). Зелёные кнопки — ловушки!`);
    const spawn = () => {
      const a = pick(ads);
      const p = h(`<div class="rd-pop"><div class="pt"><span>${esc(a[0])}</span><button class="px ${api.valera ? 'hint' : ''}">✕</button></div><div class="pb"><b>${esc(a[0])}</b>${esc(a[1])}<br><button class="trap">${esc(a[2])}</button></div></div>`);
      p.style.left = randi(0, Math.max(10, W - 200)) + 'px';
      p.style.top = randi(0, Math.max(10, H - 130)) + 'px';
      p.style.zIndex = 10 + total;
      left++; total++;
      p.querySelector('.px').onclick = api.act(() => { if (!p.isConnected) return; p.remove(); left--; sfx.click(); upd(); if (left <= 0) api.done(); });
      p.querySelector('.trap').onclick = api.act(() => { api.mistake('Ловушка! Открылась ещё реклама'); if (total < 14) { spawn(); spawn(); } upd(); });
      api.scr.appendChild(p);
    };
    const n = 5 + Math.min(3, rankIdx());
    for (let i = 0; i < n; i++) spawn();
    upd();
  },

  virus(api) {
    const normal = shuffle([['🏦', 'Банк-клиент'], ['📊', 'Отчёт.xlsx'], ['🐱', 'Котик.jpg'], ['🧮', 'Калькулятор'], ['📄', 'Договор.docx'], ['🗂', 'Мой компьютер'], ['🎵', 'Шансон.mp3'], ['📁', 'Документы']]).slice(0, 7);
    const viruses = shuffle([['👾', 'Гонки_бесплатно.exe'], ['💀', 'ускоритель_пк.exe'], ['🎁', 'ПОДАРОК.scr'], ['🪙', 'майнер_тихий.exe'], ['🔓', 'взлом_банка.bat']]).slice(0, 3);
    const all = shuffle([...normal.map((x) => [...x, false]), ...viruses.map((x) => [...x, true])]);
    all.push(['🗑', 'Корзина', 'bin']);
    desktopIcons(api.scr, all);
    let sel = null, killed = 0;
    const upd = () => api.task(`Выделите подозрительную программу, затем нажмите «Корзину» (${killed}/3)`);
    all.forEach((it) => {
      if (it[2] === 'bin') {
        it.el.onclick = api.act(() => {
          if (!sel) { api.flash('Сначала выделите файл'); return; }
          if (sel[2] === true) { sel.el.remove(); killed++; sfx.whoosh(); upd(); if (killed >= 3) api.done(); }
          else { api.mistake('Это нужный файл клиента!'); sel.el.classList.add('shake'); sel.el.classList.remove('sel'); }
          sel = null;
        });
      } else {
        if (it[2] && api.valera) it.el.classList.add('hint');
        it.el.onclick = api.act(() => { all.forEach((x) => x.el.classList.remove('sel', 'shake')); sel = it; it.el.classList.add('sel'); });
      }
    });
    upd();
  },

  findfile(api) {
    const target = 'Отчёт_Q3_2026.xlsx';
    const paths = [['Документы', 'Бухгалтерия', '2026'], ['Документы', 'Отчёты', 'Квартальные'], ['Рабочий стол', 'Новая папка (2)', 'Важное']];
    const tp = pick(paths);
    const junk = ['Котики.jpg', 'Пароли.txt', 'Резюме_НЕ_ОТКРЫВАТЬ.docx', 'Отчёт_Q2_2026.xlsx', 'Отчёт_Q3_2025.xlsx', 'Отчёт_Q3_2026_старый.xlsx', 'Отчёт_Q3_2026 (копия).xlsx', 'шаблон.xlsx'];
    const mk = () => ({});
    const tree = { 'Документы': { 'Бухгалтерия': { '2025': mk(), '2026': mk() }, 'Отчёты': { 'Квартальные': mk(), 'Годовые': mk() }, 'Личное': mk() }, 'Загрузки': mk(), 'Рабочий стол': { 'Новая папка': mk(), 'Новая папка (2)': { 'Важное': mk(), 'Не важное': mk() } }, 'Музыка': mk() };
    const fill = (node, depth) => {
      Object.keys(node).forEach((k) => { if (typeof node[k] === 'object' && node[k] !== null) fill(node[k], depth + 1); });
      shuffle(junk).slice(0, 3).forEach((f) => { node[f] = 'file'; });
    };
    fill(tree, 0);
    let t = tree; tp.forEach((p) => { t = t[p]; }); t[target] = 'file';
    const decoy = pick(paths.filter((p) => p !== tp)); let dn = tree; decoy.forEach((p) => { dn = dn[p]; }); dn['Отчёт_Q3_2026_старый.xlsx'] = 'file';
    let cwd = [], sel = null;
    const win = h('<div class="rd-win"><div class="wt2">📁 Проводник</div><div class="wc"></div><div class="wf"><button class="ob send">📤 Отправить в банк</button></div></div>');
    api.scr.appendChild(win);
    const wc = win.querySelector('.wc');
    const render = () => {
      let node = tree; cwd.forEach((p) => { node = node[p]; });
      wc.innerHTML = '';
      const path = h(`<div class="fe-path"><button class="ob up">⬆ Назад</button><span>🖥 Этот компьютер${cwd.length ? ' › ' + cwd.map(esc).join(' › ') : ''}</span></div>`);
      path.querySelector('.up').onclick = api.act(() => { if (cwd.length) { cwd.pop(); sel = null; render(); } });
      wc.appendChild(path);
      Object.keys(node).sort((a, b) => (node[a] === 'file') - (node[b] === 'file') || a.localeCompare(b)).forEach((k) => {
        const isDir = node[k] !== 'file';
        const onPath = api.valera && isDir && tp[cwd.length] === k && cwd.every((p, i) => tp[i] === p);
        const r = h(`<button class="fe-row ${sel === k ? 'sel' : ''} ${onPath ? 'hint' : ''}">${isDir ? '📁' : k.endsWith('.xlsx') ? '📊' : '📄'} ${esc(k)}</button>`);
        r.onclick = api.act(() => { if (isDir) { cwd.push(k); sel = null; } else sel = k; render(); });
        wc.appendChild(r);
      });
    };
    win.querySelector('.send').onclick = api.act(() => {
      if (!sel) { api.flash('Выберите файл'); return; }
      const ok = sel === target && cwd.join('/') === tp.join('/');
      if (ok) api.done(); else api.mistake('Не тот файл! Клиент ругается');
    });
    api.task(`Найдите файл «${target}» и отправьте его в банк`);
    render();
  },

  installer(api) {
    const junkAll = ['Браузер «Друг»', 'Панель «Сто новостей»', 'Антивирус «Дырявый щит»', 'Игра «Косынка Онлайн»', 'Сделать «Друг» домашней страницей', 'Помощник «Скрепыш»'];
    const junk = shuffle(junkAll).slice(0, 4);
    let step = 0, accept = false;
    const checks = junk.map((n) => ({ n, on: true }));
    const win = h('<div class="rd-win"><div class="wt2">💿 Установка СПЕРМ.Банк-Клиент 5.0</div><div class="wc"></div><div class="wf"></div></div>');
    api.scr.appendChild(win);
    const wc = win.querySelector('.wc'), wf = win.querySelector('.wf');
    const btn = (txt, fn, pri) => { const b = h(`<button class="ob ${pri ? 'pri' : ''}">${txt}</button>`); b.onclick = api.act(fn); wf.appendChild(b); return b; };
    const render = () => {
      wc.innerHTML = ''; wf.innerHTML = '';
      if (step === 0) {
        wc.innerHTML = '<p><b>Добро пожаловать в мастер установки!</b></p><p>Программа установит банк-клиент СПЕРМбанка на этот компьютер.</p>';
        btn('Далее ›', () => { step = 1; render(); }, true);
      } else if (step === 1) {
        wc.innerHTML = '<p><b>Лицензионное соглашение</b></p><p style="font-size:11px;opacity:.75">Используя программу, вы соглашаетесь, что бухгалтер всегда прав, а дедлайн — вчера…</p>';
        const c = h(`<button class="chk"><span class="bx">${accept ? '✔' : ''}</span>Я принимаю условия соглашения</button>`);
        c.onclick = api.act(() => { accept = !accept; render(); });
        wc.appendChild(c);
        btn('Далее ›', () => { if (!accept) { api.mistake('Нужно принять соглашение'); return; } step = 2; render(); }, true);
      } else if (step === 2) {
        wc.innerHTML = '<p><b>Выберите компоненты:</b></p>';
        wc.appendChild(h('<div class="chk dis"><span class="bx">✔</span>СПЕРМ.Банк-Клиент (обязательно)</div>'));
        checks.forEach((ch) => {
          const c = h(`<button class="chk ${api.valera && ch.on ? 'hint' : ''}"><span class="bx">${ch.on ? '✔' : ''}</span>${esc(ch.n)}</button>`);
          c.onclick = api.act(() => { ch.on = !ch.on; render(); });
          wc.appendChild(c);
        });
        btn('Установить', () => {
          const bad = checks.filter((c) => c.on).length;
          for (let i = 0; i < bad; i++) api.mistake();
          if (bad) api.flash(`Установлено мусорных программ: ${bad}`);
          step = 3; render();
        }, true);
      } else if (step === 3) {
        wc.innerHTML = '<p>Установка…</p><div class="rd-prog"><i style="width:0"></i></div>';
        const bar = wc.querySelector('i'); let k = 0;
        const iv = setInterval(() => { k += 7; bar.style.width = Math.min(100, k) + '%'; if (k >= 100) { clearInterval(iv); step = 4; render(); } }, 120);
      } else {
        wc.innerHTML = '<p><b>✅ Установка завершена!</b></p><p>Банк-клиент готов к работе.</p>';
        btn('Готово', () => api.done(), true);
      }
    };
    api.task('Установите банк-клиент. Снимите галочки с лишних программ!');
    render();
  },

  printer(api) {
    const printers = shuffle([
      { n: 'Печатник-3000', st: '⛔ Отключён', ok: false },
      { n: 'Факс-200', st: '💤 Не используется', ok: false },
      { n: 'Печатник-3000 (копия 2)', st: '✅ В сети', ok: true },
      { n: 'Виртуальный PDF-принтер', st: '📄 Только в файл', ok: false },
    ]);
    let queue = 47, sel = null, def = null;
    const win = h('<div class="rd-win"><div class="wt2">🖨 Принтеры и сканеры</div><div class="wc"></div><div class="wf"></div></div>');
    api.scr.appendChild(win);
    const wc = win.querySelector('.wc'), wf = win.querySelector('.wf');
    const upd = () => api.task(queue ? 'Очистите очередь печати, выберите принтер «В сети», сделайте основным и напечатайте пробную страницу' : !def || !def.ok ? 'Выберите принтер «В сети» и нажмите «Сделать основным»' : 'Напечатайте пробную страницу');
    const render = () => {
      wc.innerHTML = `<div style="margin-bottom:6px">🗂 Очередь печати: <b>${queue ? queue + ' зависших документов' : 'пусто'}</b></div>`;
      printers.forEach((p) => {
        const r = h(`<button class="prn ${sel === p ? 'sel' : ''} ${api.valera && p.ok ? 'hint' : ''}">🖨 <span style="flex:1">${esc(p.n)}${def === p ? ' <b>(основной)</b>' : ''}</span><span>${p.st}</span></button>`);
        r.onclick = api.act(() => { sel = p; render(); });
        wc.appendChild(r);
      });
      wf.innerHTML = '';
      const mk = (t, fn) => { const b = h(`<button class="ob">${t}</button>`); b.onclick = api.act(fn); wf.appendChild(b); };
      mk('🧹 Очистить очередь', () => { queue = 0; sfx.whoosh(); render(); upd(); });
      mk('⭐ Сделать основным', () => { if (!sel) { api.flash('Выберите принтер'); return; } if (!sel.ok) { api.mistake('Этот принтер не работает!'); return; } def = sel; render(); upd(); });
      mk('🖨 Пробная печать', () => {
        if (queue) { api.mistake('Очередь забита! Сначала очистите её'); return; }
        if (!def || !def.ok) { api.mistake('Нет рабочего основного принтера'); return; }
        api.scr.appendChild(h('<div class="paper">ПРОБНАЯ<br>СТРАНИЦА<br>✓ OK</div>'));
        setTimeout(() => api.done(), 1100);
      });
    };
    upd(); render();
  },
};
