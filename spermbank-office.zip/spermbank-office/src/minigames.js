// ===== Бухгалтерские мини-игры на скорость =====
import { randi, pick, shuffle, fmtNum, has, rankIdx } from './state.js';
import { sfx } from './audio.js';
import { h } from './ui.js';

const INCOME = ['Клиент оплатил счёт', 'Возврат от поставщика', 'Получен кредит', 'Проценты по вкладу', 'Оплата от покупателя',
  'Внесение наличных в кассу', 'Субсидия от государства', 'Продажа старого принтера', 'Возврат налога', 'Аванс от заказчика'];
const EXPENSE = ['Оплата аренды', 'Зарплата сотрудникам', 'Покупка кофе в офис', 'Налог УСН', 'Оплата интернета', 'Комиссия банка',
  'Бумага для принтера', 'Штраф за парковку', 'Ремонт кондиционера', 'Корм для офисного кота'];

const TITLES = { sum: '🧮 Сумма счетов', error: '🔍 Найди ошибку в сверке', inout: '⇅ Приход или расход?' };

export function runMinigame(host, type) {
  return new Promise((resolve) => {
    const overlay = h('<div class="mg-overlay"></div>');
    const el = h(`<div class="mg"><div class="mg-head"><span>${TITLES[type]}</span><span class="mg-round"></span></div><div class="mg-timer"><i></i></div><div class="mg-body"></div></div>`);
    overlay.appendChild(el); host.appendChild(overlay);
    const body = el.querySelector('.mg-body'), bar = el.querySelector('.mg-timer i'), roundEl = el.querySelector('.mg-round');
    const tMul = has('keyboard') ? 1.3 : 1;
    let timer = null, tLeft = 0, tMax = 1, onTimeout = null, ended = false;

    const startTimer = (sec, cb) => {
      clearInterval(timer); tLeft = tMax = sec * tMul; onTimeout = cb;
      timer = setInterval(() => {
        tLeft -= 0.1; bar.style.width = Math.max(0, tLeft / tMax * 100) + '%';
        if (tLeft <= 0) { clearInterval(timer); onTimeout(); }
      }, 100);
    };
    const finish = (score, total, need) => {
      if (ended) return;
      ended = true;
      clearInterval(timer);
      const ok = score >= need;
      ok ? sfx.success() : sfx.fail();
      body.innerHTML = `<div class="mg-res"><div class="big">${ok ? (score === total ? '🏆' : '✅') : '❌'}</div>${ok ? 'Готово!' : 'Не получилось…'}<br><small>Правильно: ${score} из ${total}</small><br><br><button class="ob pri done">Вернуться к клиенту</button></div>`;
      body.querySelector('.done').onclick = () => { overlay.remove(); resolve({ ok, mistakes: total - score }); };
    };

    if (type === 'sum') {
      let round = 0, score = 0; const R = 3;
      const next = () => {
        if (ended) return;
        if (round >= R) return finish(score, R, 2);
        round++; roundEl.textContent = `${round}/${R}`;
        const n = 3 + Math.min(2, Math.floor(rankIdx() / 2)) + (round === 3 ? 1 : 0);
        const vals = Array.from({ length: n }, () => randi(12, 480) * 10 + (rankIdx() >= 3 ? randi(0, 9) : 0));
        const sum = vals.reduce((a, b) => a + b, 0);
        const set = new Set([sum]);
        while (set.size < 4) { const d = pick([10, 20, 50, 100, 100, 200, 1000]) * pick([-1, 1]); if (sum + d > 0) set.add(sum + d); }
        body.innerHTML = `<div class="mg-q">Сложи счета и выбери итог:</div><div class="mg-list">${vals.map((v, i) => `<div><span>Счёт №${i + 1}</span><b>${fmtNum(v)} ₽</b></div>`).join('')}</div><div class="mg-opts"></div>`;
        const opts = body.querySelector('.mg-opts');
        shuffle([...set]).forEach((v) => {
          const b = h(`<button class="ob">${fmtNum(v)} ₽</button>`);
          b.onclick = () => { const ok = v === sum; if (ok) { score++; sfx.coin(); } else sfx.error(); b.classList.add(ok ? 'flash-ok' : 'flash-bad'); clearInterval(timer); setTimeout(next, 350); };
          opts.appendChild(b);
        });
        startTimer(14, () => { sfx.error(); next(); });
      };
      next();
    } else if (type === 'error') {
      let round = 0, score = 0; const R = 2;
      const next = () => {
        if (ended) return;
        if (round >= R) return finish(score, R, 1);
        round++; roundEl.textContent = `${round}/${R}`;
        const rows = Array.from({ length: 5 }, (_, i) => {
          const s = randi(10, 400) * 50, inc = randi(1, 80) * 50, out = randi(1, 60) * 50;
          return { d: `${String(10 + i).padStart(2, '0')}.11`, s, inc, out, e: s + inc - out };
        });
        const bad = randi(0, 4);
        rows[bad].e += pick([-1, 1]) * pick([50, 100, 500, 1000]);
        body.innerHTML = `<div class="mg-q">Остаток = начало + приход − расход. Нажми на строку с ошибкой:</div>
          <table class="mg-table"><tr><th>Дата</th><th>Начало</th><th>Приход</th><th>Расход</th><th>Конец</th></tr>
          ${rows.map((r, i) => `<tr class="rowbtn" data-i="${i}"><td>${r.d}</td><td>${fmtNum(r.s)}</td><td>+${fmtNum(r.inc)}</td><td>−${fmtNum(r.out)}</td><td>${fmtNum(r.e)}</td></tr>`).join('')}</table>`;
        body.querySelectorAll('.rowbtn').forEach((tr) => {
          tr.onclick = () => {
            clearInterval(timer);
            const ok = +tr.dataset.i === bad;
            if (ok) { score++; sfx.coin(); } else sfx.error();
            tr.classList.add(ok ? 'good' : 'bad');
            body.querySelector(`[data-i="${bad}"]`).classList.add('good');
            setTimeout(next, 700);
          };
        });
        startTimer(20, () => { sfx.error(); body.querySelector(`[data-i="${bad}"]`).classList.add('good'); setTimeout(next, 600); });
      };
      next();
    } else {
      const N = 8; let i = 0, score = 0;
      const ops = shuffle([...shuffle(INCOME).slice(0, 4).map((t) => ({ t, in: true })), ...shuffle(EXPENSE).slice(0, 4).map((t) => ({ t, in: false }))]);
      roundEl.textContent = `0/${N}`;
      const show = () => {
        if (ended) return;
        if (i >= N) return finish(score, N, 6);
        const op = ops[i];
        body.innerHTML = `<div class="mg-q">Это приход или расход денег на счёте?</div><div class="mg-op">${op.t}<b>${fmtNum(randi(5, 900) * 100)} ₽</b></div><div class="mg-io"><button class="in">⬆ Приход</button><button class="out">⬇ Расход</button></div>`;
        const ans = (v) => {
          const ok = v === op.in;
          if (ok) { score++; sfx.coin(); } else sfx.error();
          const card = body.querySelector('.mg-op'); card.classList.add(ok ? 'flash-ok' : 'flash-bad');
          i++; roundEl.textContent = `${i}/${N}`;
          setTimeout(show, 260);
        };
        body.querySelector('.in').onclick = () => ans(true);
        body.querySelector('.out').onclick = () => ans(false);
      };
      show();
      startTimer(24, () => finish(score, N, 6));
    }
  });
}
