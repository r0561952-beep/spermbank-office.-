// ===== Состояние игры, сохранение, шина событий =====
import { RANKS, PCS, NETS, FANS } from './data.js';

const KEY = 'spermbank_office_save_v1';

export const bus = {
  l: {},
  on(e, f) { (this.l[e] || (this.l[e] = [])).push(f); },
  emit(e, ...a) { (this.l[e] || []).forEach((f) => { try { f(...a); } catch (err) { console.error(err); } }); },
};

function defaultState() {
  return {
    v: 1,
    money: 300,
    rep: 0,
    day: 1,
    minute: 0, // минут с 9:00 (рабочий день до 18:00 = 540)
    energy: 100,
    heat: 38,
    fanOn: false,
    fanStalled: false,
    lampOn: true,
    pc: 0, net: 0, fan: 0,
    items: {},
    workers: [{ lvl: 1, mood: 85 }, { lvl: 1, mood: 85 }],
    plantDay: 0,
    stats: { clients: 0, failed: 0, earned: 0, remotes: 0, tasks: 0, coffee: 0, calls: 0, bsod: 0 },
    dayStats: { clients: 0, remotes: 0, tasks: 0, earned: 0, coffee: 0, calls: 0 },
    goals: [],
    emails: [],
    ach: {},
    tutorial: 0,
    settings: { sound: true, quality: 'auto' },
  };
}

function load() {
  try {
    const raw = localStorage.getItem(KEY);
    if (raw) {
      const d = JSON.parse(raw);
      if (d && d.v === 1) {
        const def = defaultState();
        const s = Object.assign(def, d);
        s.stats = Object.assign(defaultState().stats, d.stats || {});
        s.dayStats = Object.assign(defaultState().dayStats, d.dayStats || {});
        s.settings = Object.assign(defaultState().settings, d.settings || {});
        return s;
      }
    }
  } catch (e) { /* повреждённое сохранение — начинаем заново */ }
  return defaultState();
}

export const S = load();
export const isNewGame = S.tutorial === 0;

export function save() {
  try { localStorage.setItem(KEY, JSON.stringify(S)); } catch (e) { /* хранилище недоступно */ }
}

export function resetSave() {
  try { localStorage.removeItem(KEY); } catch (e) { /* ignore */ }
}

// ---------- Утилиты ----------
export const fmtNum = (n) => String(Math.floor(Math.abs(n))).replace(/\B(?=(\d{3})+(?!\d))/g, ' ');
export const fmt = (n) => (n < 0 ? '−' : '') + fmtNum(n) + ' ₽';
export const rand = (a, b) => a + Math.random() * (b - a);
export const randi = (a, b) => Math.floor(rand(a, b + 1));
export const pick = (arr) => arr[Math.floor(Math.random() * arr.length)];
export const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
export const shuffle = (arr) => {
  const a = arr.slice();
  for (let i = a.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [a[i], a[j]] = [a[j], a[i]]; }
  return a;
};
export const esc = (s) => String(s).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));

export function clockStr(min = S.minute) {
  const t = 9 * 60 + Math.floor(min);
  const h = Math.floor(t / 60), m = t % 60;
  return String(h).padStart(2, '0') + ':' + String(m).padStart(2, '0');
}

// ---------- Производные параметры ----------
export const pc = () => PCS[S.pc];
export const net = () => NETS[S.net];
export const fan = () => FANS[S.fan];
export const has = (id) => !!S.items[id];

export function rankIdx() {
  let r = 0;
  for (let i = 0; i < RANKS.length; i++) if (S.rep >= RANKS[i].rep) r = i;
  return r;
}
export const rank = () => RANKS[rankIdx()];
export function maxChats() { return pc().chats + (has('monitor2') ? 1 : 0); }

// пинг с учётом перка Валеры
export function remotePing() {
  let p = net().ping;
  if (S.workers[0].lvl >= 6) p *= 0.6;
  return p;
}

export const online = { outage: 0 }; // секунд до восстановления интернета

// ---------- Деньги и репутация ----------
export function addMoney(n, src) {
  S.money += n;
  if (n > 0 && src !== 'refund') { S.stats.earned += n; S.dayStats.earned += n; }
  bus.emit('money', n, src);
}
export function spend(n) {
  if (S.money < n) return false;
  S.money -= n;
  bus.emit('money', -n, 'spend');
  return true;
}
export function addRep(n) {
  const before = rankIdx();
  S.rep = Math.max(0, S.rep + n);
  bus.emit('rep', n);
  const after = rankIdx();
  if (after > before) bus.emit('rankup', after);
}
