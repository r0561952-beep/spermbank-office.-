// ===== Интерфейс: HUD, метки, тосты, модальные окна, кофе, коллеги, звонки =====
import { S, bus, fmt, rank, rankIdx, net, clockStr, esc, online, has, clamp, save, resetSave } from './state.js';
import { RANKS, COFFEE, TREAT_PRICE, WORKERS, workerCost, MAX_WORKER_LVL, ACH, PCS, NETS, FANS } from './data.js';
import { G, MIN_PER_SEC } from './game.js';
import { CM } from './clients.js';
import { Scene } from './scene.js';
import { sfx, setSoundOn } from './audio.js';

const $ = (s, r = document) => r.querySelector(s);
export const h = (html) => { const t = document.createElement('template'); t.innerHTML = html.trim(); return t.content.firstElementChild; };

export const ARROW = (fill = '#fff', stroke = '#000') => `<svg width="16" height="25" viewBox="0 0 12 19"><path d="M0.6 0.6V15.4L4.1 12L6.6 17.9L8.9 16.9L6.4 11.2H11Z" fill="${fill}" stroke="${stroke}" stroke-width="1.1" stroke-linejoin="round"/></svg>`;

export const UI = { stack: [], labels: {} };

// ---------- тосты ----------
UI.toast = function (text, type = 'info', ms = 3200) {
  const box = $('#toasts');
  const el = h(`<div class="toast ${type}">${esc(text)}</div>`);
  box.appendChild(el);
  while (box.children.length > 3) box.firstChild.remove();
  setTimeout(() => { el.classList.add('out'); setTimeout(() => el.remove(), 300); }, ms);
};

UI.float = function (x, y, text, color) {
  const el = h(`<div class="float">${esc(text)}</div>`);
  el.style.left = x + 'px'; el.style.top = y + 'px';
  if (color) el.style.color = color;
  document.body.appendChild(el);
  setTimeout(() => el.remove(), 1700);
};

UI.confetti = function () {
  const cols = ['#ffd54f', '#7c4dff', '#00bfa5', '#ef5350', '#42a5f5'];
  for (let i = 0; i < 60; i++) {
    const c = h('<div class="confetti"></div>');
    c.style.left = Math.random() * 100 + 'vw';
    c.style.background = cols[i % cols.length];
    c.style.animationDuration = 1.8 + Math.random() * 1.8 + 's';
    c.style.animationDelay = Math.random() * 0.5 + 's';
    document.body.appendChild(c);
    setTimeout(() => c.remove(), 4500);
  }
};

// ---------- модальные окна ----------
UI.modal = function ({ title, body, buttons = [], onClose, closable = true, width }) {
  const bg = h(`<div class="modal-bg"><div class="modal"><div class="modal-head"><span>${title}</span>${closable ? '<button class="x">✕</button>' : ''}</div><div class="modal-body"></div>${buttons.length ? '<div class="modal-foot"></div>' : ''}</div></div>`);
  if (width) $('.modal', bg).style.width = width;
  const bodyEl = $('.modal-body', bg);
  if (typeof body === 'string') bodyEl.innerHTML = body; else if (body) bodyEl.appendChild(body);
  const m = { el: bg, body: bodyEl, closed: false };
  m.close = () => {
    if (m.closed) return; m.closed = true;
    bg.remove(); UI.stack = UI.stack.filter((x) => x !== m);
    Scene.inputEnabled = UI.stack.length === 0;
    if (onClose) onClose();
  };
  m.closable = closable;
  if (closable) {
    $('.x', bg).onclick = () => { sfx.tap(); m.close(); };
    bg.addEventListener('pointerdown', (e) => { if (e.target === bg) m.close(); });
  }
  const foot = $('.modal-foot', bg);
  buttons.forEach((b) => {
    const btn = h(`<button class="btn ${b.cls || ''}">${b.text}</button>`);
    btn.onclick = () => { sfx.tap(); if (b.onClick) b.onClick(m); if (b.close !== false) m.close(); };
    foot.appendChild(btn);
  });
  $('#modal-root').appendChild(bg);
  UI.stack.push(m);
  Scene.inputEnabled = false;
  return m;
};
UI.closeTop = function () {
  const m = UI.stack[UI.stack.length - 1];
  if (m && m.closable) { m.close(); return true; }
  return !!m;
};
UI.confirm = function (title, text, yes, onYes) {
  UI.modal({ title, body: `<p>${text}</p>`, buttons: [{ text: 'Отмена' }, { text: yes, cls: 'danger', onClick: onYes }] });
};

// ---------- HUD ----------
UI.updateHUD = function () {
  $('#h-money').textContent = fmt(S.money);
  const r = rankIdx(), nx = RANKS[r + 1];
  $('#h-rank').textContent = RANKS[r].name;
  $('#h-rep').style.width = nx ? ((S.rep - RANKS[r].rep) / (nx.rep - RANKS[r].rep) * 100) + '%' : '100%';
  $('#h-day').textContent = 'День ' + S.day;
  $('#h-clock').textContent = clockStr();
  $('#h-energy').style.width = S.energy + '%';
  const he = $('#h-heat');
  he.style.width = ((S.heat - 30) / 70 * 100) + '%';
  he.style.background = S.heat > 85 ? '#e53935' : S.heat > 65 ? '#ffa726' : '#42a5f5';
  const out = online.outage > 0;
  $('#h-net').textContent = out ? 'нет сети' : NETS[S.net].short;
  $('#h-net-chip').classList.toggle('bad', out);
};

// ---------- метки над 3D-объектами ----------
function label(id, cls = '') {
  if (!UI.labels[id]) { const el = h(`<div class="lbl ${cls}"></div>`); $('#labels').appendChild(el); UI.labels[id] = el; }
  return UI.labels[id];
}
UI.updateLabels = function () {
  const show = !G.inOS && Scene.camMode === 'free';
  $('#labels').style.display = show ? '' : 'none';
  if (!show) return;
  const set = (id, anchor, text, cls = '') => {
    const el = label(id);
    if (!text) { el.style.display = 'none'; return; }
    const v = Scene.anchor(anchor);
    if (!v) { el.style.display = 'none'; return; }
    const p = Scene.project(v);
    if (!p.vis) { el.style.display = 'none'; return; }
    el.style.display = '';
    el.className = 'lbl ' + cls;
    if (el._t !== text) { el.textContent = text; el._t = text; }
    el.style.left = p.x + 'px'; el.style.top = p.y + 'px';
  };
  const waiting = CM.waitingCount();
  set('pc', 'pc', waiting ? `💬 Клиенты ждут: ${waiting}` : (S.tutorial < 2 ? '👆 Нажми на монитор' : ''), waiting ? 'big' : 'tip');
  set('phone', 'phone', G.phone && !G.phone.answered ? '📞 Звонок!' : '', 'big');
  set('mug', 'mug', G.mug ? '☕ Выпить' : '', 'good');
  set('bell', 'bell', !G.mug && S.energy < 35 && !G.waiterBusy ? '🔔 Кофе?' : '', 'tip');
  set('fan', 'fan', S.fanStalled ? '⚠️ Заглох! Стукни' : (!S.fanOn && S.heat > 70 ? '🌀 Включи!' : ''), 'big');
  set('plant', 'plant', has('plant') && S.plantDay !== S.day ? '💧 Полей меня' : '', 'tip');
  [0, 1].forEach((i) => {
    const w = S.workers[i], mode = Scene.workerMode(i);
    const mood = mode === 'sleep' ? '💤 спит' : mode === 'phone' ? '📱 болтает' : w.mood > 70 ? '😊' : w.mood > 40 ? '😐' : '😩';
    set('w' + i, 'w' + i, `${WORKERS[i].name.split(' ')[0]} · ур.${w.lvl} ${mood}`, mode === 'work' ? '' : 'big');
  });
};

UI.floatAt = function (anchor, text, color) {
  const v = Scene.anchor(anchor);
  if (!v || G.inOS) { UI.float(window.innerWidth / 2, 60, text, color); return; }
  const p = Scene.project(v);
  if (p.vis) UI.float(p.x, p.y, text, color);
};

// ---------- кофе ----------
UI.coffeeMenu = function () {
  const body = h('<div><p style="margin:0 0 8px;opacity:.8">🤵 Официант Жорик принесёт заказ прямо к столу.</p><div class="grid2"></div></div>');
  const grid = $('.grid2', body);
  let m;
  COFFEE.forEach((c) => {
    const card = h(`<button class="card clickable" style="text-align:left;color:#fff"><div class="big-emoji">${c.icon}</div><div class="t">${c.name}</div><div class="d">${c.desc} · +${c.energy} ⚡</div><div class="p">${fmt(c.price)}</div></button>`);
    card.onclick = () => { if (G.orderCoffee(c.id)) m.close(); };
    grid.appendChild(card);
  });
  const treat = h(`<button class="card clickable" style="text-align:left;color:#fff;border-color:#ffd54f"><div class="big-emoji">🤝</div><div class="t">Угостить коллег</div><div class="d">Кофе Валере и Светлане Петровне: настроение +45</div><div class="p">${fmt(TREAT_PRICE)}</div></button>`);
  treat.onclick = () => { if (G.orderCoffee('cap', true)) m.close(); };
  grid.appendChild(treat);
  m = UI.modal({ title: '☕ Кофе-доставка «У Жорика»', body });
};

// ---------- коллеги ----------
UI.renderWorkers = function (box, rerender) {
  box.innerHTML = '';
  S.workers.forEach((w, i) => {
    const d = WORKERS[i];
    const inc = d.base * w.lvl * (0.4 + 0.6 * w.mood / 100) * MIN_PER_SEC * 60 / MIN_PER_SEC;
    const max = w.lvl >= MAX_WORKER_LVL;
    const cost = workerCost(w.lvl);
    const el = h(`<div class="worker"><div class="av">${d.av}</div><div class="info">
      <div class="nm">${d.name} <span style="opacity:.7;font-weight:400">· ${d.role}</span></div>
      <div>Уровень <b>${w.lvl}</b>/${MAX_WORKER_LVL} · приносит ~<b>${fmt(inc)}</b> в игровой час</div>
      <div>Настроение: <div class="mbar" style="display:inline-block;width:120px;vertical-align:middle"><i style="width:${w.mood}%"></i></div> ${Math.round(w.mood)}%</div>
      <div class="perks">${d.perks.map((p) => `<span class="${w.lvl >= p.lvl ? '' : 'off'}">${w.lvl >= p.lvl ? '✅' : '🔒'} Ур.${p.lvl}: ${p.text}</span>`).join('')}</div>
      <div class="row"><button class="btn primary up" ${max ? 'disabled' : ''}>${max ? 'Максимум' : `🎓 Повысить · ${fmt(cost)}`}</button></div>
    </div></div>`);
    $('.up', el).onclick = () => { G.upgradeWorker(i); if (rerender) rerender(); else UI.renderWorkers(box); };
    box.appendChild(el);
  });
  const t = h(`<button class="btn gold" style="width:100%">🤝 Угостить обоих кофе · ${fmt(TREAT_PRICE)}</button>`);
  t.onclick = () => { G.orderCoffee('cap', true); };
  box.appendChild(t);
};
UI.workersPanel = function () {
  const box = h('<div></div>');
  UI.renderWorkers(box);
  UI.modal({ title: '👥 Моя команда', body: box });
};

// ---------- телефон ----------
UI.showCall = function (ringing) {
  const el = $('#call');
  if (!ringing || !G.phone) { el.classList.add('hidden'); return; }
  const c = G.phone.call;
  el.innerHTML = `<div style="font-size:28px">${c.av}</div><div class="who"><b>📞 Входящий звонок</b>${esc(c.who)}</div><button class="btn ans">Ответить</button><button class="btn dec">✕</button>`;
  el.classList.remove('hidden');
  $('.ans', el).onclick = () => UI.answerCall();
  $('.dec', el).onclick = () => { sfx.tap(); G.phone = null; G.phoneT = 80; el.classList.add('hidden'); bus.emit('phone', false); };
};
UI.answerCall = function () {
  const call = G.answerPhone();
  $('#call').classList.add('hidden');
  if (!call) return;
  const body = h(`<div><div class="callbox"><div class="av">${call.av}</div><div><b>${esc(call.who)}</b><p style="margin:4px 0 0">«${esc(call.text)}»</p></div></div><div class="opts"></div></div>`);
  const opts = $('.opts', body);
  let m;
  call.o.forEach((o) => {
    const b = h(`<button class="btn">${esc(o.t)}</button>`);
    b.onclick = () => {
      sfx.tap();
      G.phoneChoice(o);
      opts.innerHTML = `<p style="margin:6px 0">${esc(o.r)}</p>`;
      const ok = h('<button class="btn primary">Положить трубку</button>');
      ok.onclick = () => m.close();
      opts.appendChild(ok);
    };
    opts.appendChild(b);
  });
  m = UI.modal({ title: '📞 Разговор по телефону', body, closable: false });
};

// ---------- меню ----------
UI.menu = function () {
  const q = S.settings.quality;
  const body = h(`<div style="display:flex;flex-direction:column;gap:8px">
    <button class="btn primary" data-a="cont">▶ Продолжить</button>
    <button class="btn" data-a="help">❓ Как играть</button>
    <button class="btn" data-a="ach">🏆 Достижения (${Object.keys(S.ach).length}/${ACH.length})</button>
    <button class="btn" data-a="snd">${S.settings.sound ? '🔊 Звук: вкл' : '🔇 Звук: выкл'}</button>
    <button class="btn" data-a="gfx">🎨 Графика: ${{ auto: 'авто', low: 'низкая', medium: 'средняя', high: 'высокая' }[q]}</button>
    <button class="btn danger" data-a="reset">🗑 Начать заново</button>
    ${window.AndroidApp ? '<button class="btn" data-a="exit">🚪 Выйти из игры</button>' : ''}
  </div>`);
  const m = UI.modal({ title: '⚙️ Меню', body });
  body.addEventListener('click', (e) => {
    const a = e.target.closest('[data-a]'); if (!a) return;
    sfx.tap();
    const act = a.dataset.a;
    if (act === 'cont') m.close();
    if (act === 'help') { m.close(); UI.help(); }
    if (act === 'ach') { m.close(); UI.achievements(); }
    if (act === 'snd') { setSoundOn(!S.settings.sound); save(); m.close(); UI.menu(); }
    if (act === 'gfx') {
      const order = ['auto', 'low', 'medium', 'high'];
      S.settings.quality = order[(order.indexOf(q) + 1) % order.length]; save();
      UI.confirm('Графика', 'Чтобы применить настройку графики, игра перезапустится. Прогресс сохранён.', 'Перезапустить', () => location.reload());
      m.close();
    }
    if (act === 'reset') UI.confirm('Начать заново?', 'Весь прогресс будет удалён: деньги, апгрейды, коллеги. Точно?', 'Удалить всё', () => { G.paused = true; resetSave(); location.reload(); });
    if (act === 'exit') { save(); window.AndroidApp.exit(); }
  });
};

UI.help = function () {
  UI.modal({
    title: '❓ Как играть', width: 'min(92vw, 720px)',
    body: `<b>Цель:</b> обслуживать клиентов СПЕРМбанка, зарабатывать и расти от стажёра до вице-президента.<br><br>
    🖥 <b>Монитор</b> — нажми, чтобы сесть за компьютер. Там:<br>
    &nbsp;• 💬 <b>СПЕРМ.Чат</b> — выбирай вежливые и толковые ответы, потом жми «Выставить счёт». Чем довольнее клиент — тем больше заплатит.<br>
    &nbsp;• 🛰 <b>ДальнийСтол</b> — подключение к компьютеру клиента: закрыть рекламу, удалить вирусы, найти файл, настроить принтер. Чем хуже интернет — тем сильнее тормозит!<br>
    &nbsp;• 🧮 Бухгалтерские задачки на скорость: сумма счетов, поиск ошибки, приход/расход.<br>
    &nbsp;• 🛒 <b>СПЕРМ.Маркет</b> — новый ПК (меняется вся система: Окна 95 → ИксПи → 7 → 11 → КвантОС), интернет, охлаждение и вещи на стол.<br>
    &nbsp;• 📧 <b>Почта</b> — цели дня от начальника и премии.<br><br>
    🌀 <b>Вентилятор</b> — нажми, чтобы включить. Без него ПК перегреется и словит синий экран. Старый вентилятор иногда глохнет — стукни по нему.<br>
    🔔 <b>Колокольчик</b> — позвать официанта Жорика с кофе. Потом нажми на кружку, чтобы выпить. Без бодрости ты уснёшь!<br>
    📞 <b>Телефон</b> — отвечай на звонки. Осторожно, звонят и мошенники.<br>
    👥 <b>Коллеги</b> — Валера и Светлана Петровна приносят деньги сами. Повышай им уровень и угощай кофе, иначе они уснут или уйдут в болтовню.<br>
    🪴 Фикус надо поливать, а свайп по экрану поворачивает голову.`,
    buttons: [{ text: 'Понятно!', cls: 'primary' }],
  });
};

UI.achievements = function () {
  const body = `<div class="ach-grid">${ACH.map((a) => `<div class="ach ${S.ach[a.id] ? '' : 'locked'}"><div class="i">${a.icon}</div><div><b>${a.name}</b><br>${a.desc}</div></div>`).join('')}</div>`;
  UI.modal({ title: '🏆 Достижения', body, width: 'min(92vw, 720px)' });
};

UI.daySummary = function () {
  const ds = S.dayStats;
  const goals = (S.goals || []).map((g) => `<div>${g.done ? '✅' : '❌'} ${esc(g.text)}${g.done && !g.claimed ? ' <b style="color:#ffd54f">(премия не забрана!)</b>' : ''}</div>`).join('');
  UI.modal({
    title: `🌙 День ${S.day} завершён`, closable: false,
    body: `<div class="stats">
      <div><span>Заработано за день</span><b>${fmt(ds.earned)}</b></div>
      <div><span>Клиентов обслужено</span><b>${ds.clients}</b></div>
      <div><span>Удалённых сессий</span><b>${ds.remotes}</b></div>
      <div><span>Задач решено</span><b>${ds.tasks}</b></div>
      <div><span>Кофе выпито</span><b>${ds.coffee}</b></div>
      <div><span>Звонков</span><b>${ds.calls}</b></div>
    </div><p style="margin:10px 0 4px"><b>Цели дня:</b></p>${goals}
    <p style="margin-top:10px;opacity:.75">Вы идёте домой, высыпаетесь и завтра приходите бодрым. Незабранные премии сгорают!</p>`,
    buttons: [{ text: '☀️ Следующий день', cls: 'primary', onClick: () => G.newDay() }],
  });
};

UI.rankUp = function (r) {
  UI.confetti();
  sfx.levelup();
  UI.modal({
    title: '🎉 Повышение!',
    body: `<div style="text-align:center"><div style="font-size:54px">🏅</div><h2 style="margin:6px 0">${RANKS[r].name}</h2>
      <p>Теперь клиенты платят <b>×${RANKS[r].mult}</b> от базового тарифа.${r === 1 ? '<br>Начнут приходить клиенты посерьёзнее.' : ''}${r === 3 ? '<br>Тебе доверяют VIP-клиентов!' : ''}</p></div>`,
    buttons: [{ text: 'Ура!', cls: 'gold' }],
  });
};

UI.intro = function (onDone) {
  UI.modal({
    title: '🏦 Добро пожаловать в СПЕРМбанк!', closable: false,
    body: `<div style="display:flex;gap:12px;align-items:flex-start"><div style="font-size:50px">👨‍💼</div><div>
      <p style="margin-top:0"><b>Аркадий Борисович, начальник отдела:</b></p>
      <p>«Ну что, новенький, добро пожаловать в отдел быстрой бухгалтерии! Работа простая: клиенты пишут в чат — ты отвечаешь, решаешь проблему и выставляешь счёт за обслуживание.</p>
      <p>Компьютер у тебя пока из девяностых, интернет — модем. Заработаешь — купишь получше. Справа Светлана Петровна, слева Валера — они помогут, если не забудешь угостить их кофе.</p>
      <p>И включи вентилятор, а то эта бежевая коробка опять задымится.»</p></div></div>`,
    buttons: [{ text: 'Понял, за работу!', cls: 'primary', onClick: onDone }],
  });
};

UI.setHint = function (text) {
  const el = $('#hint');
  if (!text) el.classList.add('hidden'); else { el.textContent = text; el.classList.remove('hidden'); }
};
