// ===== 3D-офис: сцена, камера, касания, анимации =====
import * as THREE from 'three';
import { S, bus, has, online, clockStr } from './state.js';
import { PCS } from './data.js';
import * as M from './models.js';
import { G, DAY_LEN } from './game.js';
import { CM } from './clients.js';

const DY = 0.75; // высота столешницы
const HOME = new THREE.Vector3(0, 1.28, 1.0);
const H = {}; // ссылки на объекты
const interactive = [];
let renderer, scene, camera, sun, hemi, monGlow;
const PITCH0 = -0.37;
let yaw = 0, pitch = PITCH0, tYaw = 0, tPitch = PITCH0;
let camMode = 'free', tween = null;
let time = 0;
let bounce = [];
let lastScreenKey = '', lastSkyKey = -1;

export const Scene = {
  renderEnabled: true,
  inputEnabled: true,
  onTap: null,
  onFrame: null,
  get camMode() { return camMode; },
};

// ---------- инициализация ----------
Scene.init = function (container) {
  const q = S.settings.quality === 'auto' ? 'medium' : S.settings.quality;
  renderer = new THREE.WebGLRenderer({ antialias: q !== 'low', powerPreference: 'high-performance' });
  renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, q === 'high' ? 2 : q === 'medium' ? 1.5 : 1));
  renderer.setSize(window.innerWidth, window.innerHeight);
  renderer.toneMapping = THREE.ACESFilmicToneMapping;
  renderer.toneMappingExposure = 1.05;
  renderer.shadowMap.enabled = q !== 'low';
  renderer.shadowMap.type = THREE.PCFSoftShadowMap;
  container.appendChild(renderer.domElement);

  scene = new THREE.Scene();
  scene.background = new THREE.Color('#1a2030');
  camera = new THREE.PerspectiveCamera(52, window.innerWidth / window.innerHeight, 0.03, 80);

  hemi = new THREE.HemisphereLight('#eef3ff', '#7a6a5a', 0.85);
  scene.add(hemi);
  scene.add(new THREE.AmbientLight('#ffffff', 0.25));
  sun = new THREE.DirectionalLight('#fff4e0', 1.5);
  sun.position.set(2.2, 4.5, -5.5);
  sun.target.position.set(0, DY, 0);
  sun.castShadow = renderer.shadowMap.enabled;
  sun.shadow.mapSize.set(q === 'high' ? 2048 : 1024, q === 'high' ? 2048 : 1024);
  const sc = sun.shadow.camera; sc.left = -3.4; sc.right = 3.4; sc.top = 3; sc.bottom = -3; sc.near = 1; sc.far = 14;
  sun.shadow.bias = -0.0004; sun.shadow.normalBias = 0.02;
  scene.add(sun, sun.target);
  const ceil = new THREE.PointLight('#fff8ec', 0.9, 7, 1.2); ceil.position.set(0, 2.85, 0.4); scene.add(ceil);
  monGlow = new THREE.PointLight('#4aa', 0.35, 1.3, 1.5); monGlow.position.set(0, 1.08, 0.0); scene.add(monGlow);

  buildRoom();
  buildDesk();
  buildCoworkers();
  buildWaiter();
  Scene.rebuildPC();
  Scene.rebuildNet();
  Scene.rebuildFan();
  Scene.rebuildItems();

  setupInput(renderer.domElement);
  window.addEventListener('resize', onResize);
  bus.on('pc', () => Scene.rebuildPC());
  bus.on('net', () => Scene.rebuildNet());
  bus.on('fan', () => Scene.rebuildFan(true));
  bus.on('items', () => Scene.rebuildItems());
  bus.on('waiter', (o) => startWaiter(o.target, o.item));
  bus.on('workerLevel', (i) => { H.workers[i].celebrate = 2.2; updateWorkerProps(); });
  updateWorkerProps();
  updateCamera(0);
};

function onResize() {
  camera.aspect = window.innerWidth / window.innerHeight;
  camera.updateProjectionMatrix();
  renderer.setSize(window.innerWidth, window.innerHeight);
}

function tag(obj, action) { obj.userData.action = action; interactive.push(obj); return obj; }
function untag(obj) { const i = interactive.indexOf(obj); if (i >= 0) interactive.splice(i, 1); scene.remove(obj); }

// ---------- комната ----------
function buildRoom() {
  const wallM = M.mat('#e8e2d8', { roughness: 0.95 });
  const carpet = M.canvasTex(256, 256, (c, w, h) => {
    c.fillStyle = '#56606f'; c.fillRect(0, 0, w, h);
    for (let i = 0; i < 4000; i++) { c.fillStyle = `rgba(${Math.random() < 0.5 ? '255,255,255' : '0,0,0'},0.05)`; c.fillRect(Math.random() * w, Math.random() * h, 2, 2); }
    c.strokeStyle = 'rgba(0,0,0,0.18)'; c.lineWidth = 2; c.strokeRect(0, 0, w, h);
  });
  carpet.wrapS = carpet.wrapT = THREE.RepeatWrapping; carpet.repeat.set(7, 5);
  const floor = new THREE.Mesh(new THREE.PlaneGeometry(6.6, 4.9), new THREE.MeshStandardMaterial({ map: carpet, roughness: 1 }));
  floor.rotation.x = -Math.PI / 2; floor.position.set(0, 0, 0.15); floor.receiveShadow = true; scene.add(floor);
  const ceilM = M.mat('#f1f0ec', { roughness: 1 });
  const ceiling = new THREE.Mesh(new THREE.PlaneGeometry(6.6, 4.9), ceilM); ceiling.rotation.x = Math.PI / 2; ceiling.position.set(0, 3, 0.15); scene.add(ceiling);
  for (let x = -2; x <= 2; x += 2) for (let z = -1.2; z <= 1.6; z += 1.4) {
    const p = new THREE.Mesh(new THREE.BoxGeometry(1.1, 0.02, 0.55), M.basic('#fffdf4')); p.position.set(x, 2.99, z); scene.add(p);
  }
  // передняя стена с окном (окно x[-1.6..1.6], y[0.95..2.45])
  const fz = -2.3, t = 0.12;
  const piece = (w, h, x, y) => { const b = M.box(w, h, t, wallM); b.position.set(x, y, fz); b.castShadow = false; scene.add(b); return b; };
  piece(6.6, 0.95, 0, 0.475); piece(6.6, 0.55, 0, 2.725); piece(1.7, 1.5, -2.45, 1.7); piece(1.7, 1.5, 2.45, 1.7);
  const frameM = M.mat('#f7f7f5', { roughness: 0.5 });
  const fr = (w, h, x, y, d = 0.16) => { const b = M.box(w, h, d, frameM); b.position.set(x, y, fz); b.castShadow = false; scene.add(b); };
  fr(3.3, 0.07, 0, 2.43); fr(3.3, 0.07, 0, 0.97); fr(0.07, 1.5, -1.62, 1.7); fr(0.07, 1.5, 1.62, 1.7);
  fr(0.05, 1.45, -0.54, 1.7, 0.1); fr(0.05, 1.45, 0.54, 1.7, 0.1);
  const sill = M.box(3.4, 0.04, 0.32, frameM); sill.position.set(0, 0.93, fz + 0.14); scene.add(sill);
  const rad = new THREE.Group();
  for (let i = 0; i < 22; i++) { const f = M.box(0.06, 0.5, 0.08, M.mat('#f2f2f0', { roughness: 0.4 })); f.position.set(-1.0 + i * 0.095, 0.5, fz + 0.12); rad.add(f); }
  scene.add(rad);
  // вид за окном
  H.sky = M.canvasTex(1024, 512, () => {});
  H.sky.userData.seed = Array.from({ length: 900 }, () => Math.random());
  const bd = new THREE.Mesh(new THREE.PlaneGeometry(34, 17), new THREE.MeshBasicMaterial({ map: H.sky, toneMapped: false }));
  bd.position.set(0, 3.2, -14); scene.add(bd); tag(bd, 'window');
  // снег
  const N = 500, pos = new Float32Array(N * 3);
  for (let i = 0; i < N; i++) { pos[i * 3] = (Math.random() - 0.5) * 12; pos[i * 3 + 1] = Math.random() * 9 - 3; pos[i * 3 + 2] = -2.6 - Math.random() * 9; }
  const sg = new THREE.BufferGeometry(); sg.setAttribute('position', new THREE.BufferAttribute(pos, 3));
  H.snow = new THREE.Points(sg, new THREE.PointsMaterial({ color: '#fff', size: 0.05, transparent: true, opacity: 0.9, depthWrite: false }));
  scene.add(H.snow);
  // левая стена с дверью (дверь z[-1.9..-1.05])
  const lx = -3.3;
  const lw = (d, h, z, y) => { const b = M.box(t, h, d, wallM); b.position.set(lx, y, z); b.castShadow = false; scene.add(b); };
  lw(0.4, 3, -2.1, 1.5); lw(3.65, 3, 0.775, 1.5); lw(0.85, 0.9, -1.475, 2.55);
  const corridor = new THREE.Mesh(new THREE.PlaneGeometry(2, 3), M.mat('#7d8696')); corridor.rotation.y = Math.PI / 2; corridor.position.set(-4.6, 1.5, -1.475); scene.add(corridor);
  const cfloor = new THREE.Mesh(new THREE.PlaneGeometry(1.4, 1.2), M.mat('#3e4450')); cfloor.rotation.x = -Math.PI / 2; cfloor.position.set(-3.95, 0.001, -1.475); scene.add(cfloor);
  const dfM = M.mat('#5a4030', { roughness: 0.6 });
  [[0.06, 2.1, -1.9, 1.05], [0.06, 2.1, -1.05, 1.05]].forEach(([d, h, z, y]) => { const b = M.box(0.16, h, d, dfM); b.position.set(lx, y, z); scene.add(b); });
  const top = M.box(0.16, 0.06, 0.91, dfM); top.position.set(lx, 2.1, -1.475); scene.add(top);
  H.door = new THREE.Group(); H.door.position.set(lx + 0.02, 0, -1.9); scene.add(H.door);
  const panel = M.box(0.04, 2.05, 0.82, M.mat('#8a6446', { roughness: 0.55 })); panel.position.set(0, 1.03, 0.42); H.door.add(panel);
  const knob = M.sph(0.03, M.mat('#d4b25a', { metalness: 0.9, roughness: 0.3 })); knob.position.set(0.05, 1.0, 0.75); H.door.add(knob);
  const sign = new THREE.Mesh(new THREE.PlaneGeometry(0.3, 0.1), new THREE.MeshBasicMaterial({ map: M.canvasTex(128, 42, (c) => { c.fillStyle = '#2e7d32'; c.fillRect(0, 0, 128, 42); c.fillStyle = '#fff'; c.font = 'bold 18px sans-serif'; c.textAlign = 'center'; c.fillText('ВЫХОД', 64, 28); }) }));
  sign.rotation.y = Math.PI / 2; sign.position.set(lx + 0.07, 2.35, -1.475); scene.add(sign);
  // правая и задняя стены
  const rw = new THREE.Mesh(new THREE.PlaneGeometry(4.9, 3), wallM); rw.rotation.y = -Math.PI / 2; rw.position.set(3.3, 1.5, 0.15); rw.receiveShadow = true; scene.add(rw);
  const bw = new THREE.Mesh(new THREE.PlaneGeometry(6.6, 3), wallM); bw.rotation.y = Math.PI; bw.position.set(0, 1.5, 2.6); scene.add(bw);
  const lwPlane = new THREE.Mesh(new THREE.PlaneGeometry(4.9, 3), wallM); lwPlane.visible = false; scene.add(lwPlane);
  const base = M.mat('#4a4a50');
  [[6.6, 0, -2.23, 0], [4.9, 3.24, 0.15, -Math.PI / 2], [3.6, -3.23, 0.8, Math.PI / 2]].forEach(([w, x, z, ry]) => { const b = M.box(w, 0.08, 0.02, base); b.position.set(x, 0.04, z); b.rotation.y = ry; scene.add(b); });
  // часы на стене
  H.clock = new THREE.Group(); H.clock.position.set(2.35, 2.05, -2.23); scene.add(H.clock); tag(H.clock, 'clock');
  const face = M.cyl(0.2, 0.2, 0.03, M.mat('#fafafa'), 32); face.rotation.x = Math.PI / 2; H.clock.add(face);
  const rim = M.tor(0.2, 0.02, M.mat('#222')); rim.position.z = 0.01; H.clock.add(rim);
  for (let i = 0; i < 12; i++) { const a = (i / 12) * Math.PI * 2; const m = M.box(0.012, i % 3 ? 0.03 : 0.05, 0.005, M.mat('#222')); m.position.set(Math.sin(a) * 0.16, Math.cos(a) * 0.16, 0.017); m.rotation.z = -a; H.clock.add(m); }
  const hand = (len, w) => { const p = new THREE.Group(); p.position.z = 0.022; const b = M.box(w, len, 0.006, M.mat('#111')); b.position.y = len / 2 - 0.02; p.add(b); H.clock.add(p); return p; };
  H.hourHand = hand(0.11, 0.016); H.minHand = hand(0.16, 0.01);
  // постер банка
  const poster = new THREE.Mesh(new THREE.PlaneGeometry(0.9, 1.2), new THREE.MeshStandardMaterial({ map: M.canvasTex(300, 400, (c, w, h) => {
    const g = c.createLinearGradient(0, 0, 0, h); g.addColorStop(0, '#4a148c'); g.addColorStop(1, '#00897b'); c.fillStyle = g; c.fillRect(0, 0, w, h);
    c.fillStyle = '#ffca28'; c.beginPath(); c.arc(150, 130, 70, 0, Math.PI * 2); c.fill();
    c.fillStyle = '#6d4c00'; c.font = 'bold 90px sans-serif'; c.textAlign = 'center'; c.fillText('₽', 150, 162);
    c.fillStyle = '#fff'; c.font = 'bold 38px sans-serif'; c.fillText('СПЕРМбанк', 150, 260);
    c.font = '20px sans-serif'; c.fillText('Всегда рядом.', 150, 310); c.fillText('Даже слишком.', 150, 338);
  }), roughness: 0.6 }));
  poster.position.set(-2.35, 1.75, -2.235); scene.add(poster);
  // доска с планом
  const board = new THREE.Mesh(new THREE.PlaneGeometry(1.6, 0.95), new THREE.MeshStandardMaterial({ map: M.canvasTex(512, 304, (c, w, h) => {
    c.fillStyle = '#fbfbf8'; c.fillRect(0, 0, w, h);
    c.fillStyle = '#c62828'; c.font = 'bold 30px sans-serif'; c.fillText('ПЛАН НА КВАРТАЛ', 24, 44);
    c.strokeStyle = '#1565c0'; c.lineWidth = 4; c.beginPath(); c.moveTo(40, 260); c.lineTo(40, 80); c.moveTo(40, 260); c.lineTo(300, 260); c.stroke();
    c.strokeStyle = '#2e7d32'; c.beginPath(); c.moveTo(50, 240); c.lineTo(110, 210); c.lineTo(170, 220); c.lineTo(230, 150); c.lineTo(290, 90); c.stroke();
    c.fillStyle = '#1565c0'; c.font = 'bold 22px sans-serif'; c.fillText('Дедлайн: ВЧЕРА', 320, 120);
    c.fillStyle = '#333'; c.font = '20px sans-serif'; c.fillText('• Клиенты ×2', 320, 160); c.fillText('• Кофе ×3', 320, 190); c.fillText('• Не спать!!!', 320, 220);
  }), roughness: 0.4 }));
  board.rotation.y = -Math.PI / 2; board.position.set(3.27, 1.55, -0.4); scene.add(board); tag(board, 'board');
  const bframe = M.box(0.03, 1.0, 1.66, M.mat('#9aa')); bframe.position.set(3.29, 1.55, -0.4); scene.add(bframe);
  // кулер
  const cooler = new THREE.Group(); cooler.position.set(2.9, 0, 1.4); scene.add(cooler); tag(cooler, 'cooler');
  const cb = M.box(0.34, 0.95, 0.34, M.mat('#f2f2f2', { roughness: 0.4 }), 0.03); cb.position.y = 0.475; cooler.add(cb);
  const bottle = new THREE.Mesh(new THREE.CylinderGeometry(0.13, 0.13, 0.38, 20), new THREE.MeshStandardMaterial({ color: '#6ab7ff', transparent: true, opacity: 0.55, roughness: 0.1 }));
  bottle.position.y = 1.15; cooler.add(bottle);
  const tap1 = M.box(0.03, 0.04, 0.04, M.mat('#2196f3')); tap1.position.set(-0.05, 0.75, 0.18); cooler.add(tap1);
  const tap2 = M.box(0.03, 0.04, 0.04, M.mat('#e53935')); tap2.position.set(0.05, 0.75, 0.18); cooler.add(tap2);
  // большой фикус в углу и шкаф
  const bigPlant = new THREE.Group(); bigPlant.position.set(2.85, 0, -1.85); scene.add(bigPlant);
  const bp = M.cyl(0.22, 0.17, 0.4, M.mat('#eceff1')); bp.position.y = 0.2; bigPlant.add(bp);
  for (let i = 0; i < 14; i++) { const l = M.sph(1, M.mat(i % 2 ? '#2e7d32' : '#388e3c'), 10, 6); const a = i * 2.2; l.scale.set(0.22, 0.03, 0.12); l.position.set(Math.cos(a) * 0.2, 0.6 + (i / 14) * 1.0, Math.sin(a) * 0.2); l.rotation.set(0.4, -a, 0.3); bigPlant.add(l); }
  const cab = M.box(0.5, 1.25, 0.6, M.mat('#8d9299', { metalness: 0.4, roughness: 0.5 }), 0.01); cab.position.set(-2.95, 0.625, 1.55); scene.add(cab);
  for (let i = 0; i < 3; i++) { const d = M.box(0.02, 0.02, 0.18, M.mat('#ccc', { metalness: 0.8 })); d.position.set(-2.69, 1.05 - i * 0.38, 1.55); scene.add(d); }
}

// ---------- мой стол ----------
function buildDesk() {
  const desk = M.buildDesk(1.76, 0.86, '#c49a6c');
  scene.add(desk);
  const mat2 = M.box(0.62, 0.004, 0.3, M.mat('#2b2f38', { roughness: 0.9 })); mat2.position.set(0.05, DY + 0.002, 0.17); scene.add(mat2);
  // бумаги и стакан с ручками
  const papers = new THREE.Group(); papers.position.set(-0.36, DY, 0.24); scene.add(papers);
  for (let i = 0; i < 6; i++) { const p = M.box(0.21, 0.006, 0.29, M.mat(i % 2 ? '#fafafa' : '#f1f1ea')); p.position.y = 0.003 + i * 0.007; p.rotation.y = (Math.random() - 0.5) * 0.25; papers.add(p); }
  const cup = M.cyl(0.03, 0.028, 0.1, M.mat('#37474f')); cup.position.set(-0.5, DY + 0.05, 0.05); scene.add(cup);
  ['#e53935', '#1e88e5', '#212121'].forEach((c, i) => { const p = M.cyl(0.004, 0.004, 0.15, M.mat(c)); p.position.set(-0.5 + (i - 1) * 0.012, DY + 0.12, 0.05); p.rotation.z = (i - 1) * 0.15; scene.add(p); });
  // телефон
  const ph = M.buildPhone(); H.phone = ph; ph.group.position.set(0.66, DY, -0.04); ph.group.rotation.y = -0.45; scene.add(ph.group); tag(ph.group, 'phone');
  // кружка
  const mug = M.buildMug(); H.mug = mug; mug.group.position.set(0.5, DY, 0.27); mug.group.rotation.y = -2.2; scene.add(mug.group); tag(mug.group, 'mug');
  // колокольчик официанта
  const bell = M.buildBell(); H.bell = bell; bell.group.position.set(0.76, DY, 0.24); scene.add(bell.group); tag(bell.group, 'bell');
  // стикеры
  ['#fff176', '#f48fb1', '#80deea'].forEach((c, i) => { const s = M.box(0.06, 0.06, 0.002, M.mat(c)); s.position.set(-0.12 + i * 0.07, DY + 0.002, 0.33); s.rotation.set(-Math.PI / 2, 0, (i - 1) * 0.3); scene.add(s); });
}

// ---------- ПК / сеть / охлаждение / предметы ----------
Scene.rebuildPC = function () {
  if (H.pc) { untag(H.pc.group); if (H.pc.tower) untag(H.pc.tower); }
  if (H.kb) untag(H.kb);
  if (H.mouse) scene.remove(H.mouse);
  const tier = S.pc;
  const wide = tier >= 2;
  H.screenTex = M.canvasTex(512, wide ? 288 : 384, () => {});
  H.pc = M.buildPC(tier, H.screenTex);
  H.pc.group.position.set(0, DY, -0.2);
  scene.add(H.pc.group); tag(H.pc.group, 'pc');
  if (H.pc.tower) { H.pc.tower.position.set(1.1, 0, -0.12); scene.add(H.pc.tower); tag(H.pc.tower, 'pc'); }
  const style = has('keyboard') ? 'rgb' : ['beige', 'silver', 'black', 'black', 'holo'][tier];
  H.kb = M.buildKeyboard(style); H.kb.position.set(0, DY, 0.16); H.kb.userData.rgb = has('keyboard'); scene.add(H.kb); tag(H.kb, 'pc');
  H.mouse = M.buildMouse(['beige', 'silver', 'black', 'rgb', 'holo'][tier]); H.mouse.position.set(0.38, DY, 0.19); H.mouse.rotation.y = -0.1; scene.add(H.mouse);
  monGlow.color.set({ '95': '#3fa0a0', xp: '#6a9be0', '7': '#3a7ad0', '11': '#4a6ad0', q: '#30e0e0' }[PCS[tier].os]);
  monGlow.position.set(0, DY + 0.33, 0.05);
  lastScreenKey = '';
};

Scene.rebuildNet = function () {
  if (H.router && H.router.tier !== S.net) { untag(H.router.group); H.router = null; }
  if (!H.router) {
    H.router = M.buildRouter(S.net); H.router.tier = S.net;
    H.router.group.position.set(0.74, DY, -0.33); H.router.group.rotation.y = -0.35;
    scene.add(H.router.group); tag(H.router.group, 'router');
  }
};

Scene.rebuildFan = function () {
  const tier = Math.min(S.fan, 1);
  if (H.fan && H.fan.tier !== tier) { untag(H.fan.group); H.fan = null; }
  if (!H.fan) {
    H.fan = M.buildFan(tier); H.fan.tier = tier; H.fan.speed = 0;
    H.fan.group.position.set(-0.7, DY, -0.02);
    H.fan.baseYaw = Math.atan2(HOME.x + 0.7, HOME.z + 0.02) - 0.25;
    H.fan.group.rotation.y = H.fan.baseYaw;
    scene.add(H.fan.group); tag(H.fan.group, 'fan');
  }
  if (S.fan >= 2 && !H.ac) {
    H.ac = M.buildAC(); H.ac.group.position.set(-3.12, 2.35, -0.3); H.ac.group.rotation.y = Math.PI / 2;
    scene.add(H.ac.group); tag(H.ac.group, 'fan');
  }
};

const ITEM_POS = {
  plant: [-0.79, DY, 0.3, 0], lamp: [-0.84, DY, -0.37, 0.35], cat: [0.33, DY, -0.37, -0.25],
  monitor2: [-0.5, DY, -0.24, 0.45], tree: [-1.2, 0, 0.15, 0],
};
Scene.rebuildItems = function () {
  H.items = H.items || {};
  for (const id of Object.keys(ITEM_POS)) {
    if (has(id) && !H.items[id]) {
      const b = { plant: M.buildPlant, lamp: M.buildLamp, cat: M.buildCat, tree: M.buildTree, monitor2: () => ({ group: M.buildSecondMonitor(S.pc) }) }[id]();
      const [x, y, z, ry] = ITEM_POS[id];
      b.group.position.set(x, y, z); b.group.rotation.y = ry;
      scene.add(b.group);
      tag(b.group, id === 'monitor2' ? 'pc' : id);
      H.items[id] = b;
    }
  }
  if (has('keyboard') && H.kb && !H.kb.userData.rgb) Scene.rebuildPC();
};

// ---------- коллеги ----------
function buildCoworkers() {
  H.workers = [];
  const cfg = [
    { pos: [-2.15, -0.5], ry: Math.PI / 2, person: { shirt: '#5b7a5a', hood: true, pants: '#2f3b52', hair: '#4a3020', hairType: 'messy', headphones: true, skin: '#f0c49c' }, chair: '#38404e' },
    { pos: [2.15, -0.5], ry: -Math.PI / 2, person: { shirt: '#8e2449', pants: '#2b2b33', hair: '#7a2e1a', hairType: 'bun', glasses: true, necklace: true, skin: '#f3cdb0' }, chair: '#4e3838' },
  ];
  cfg.forEach((c, i) => {
    const g = new THREE.Group(); g.position.set(c.pos[0], 0, c.pos[1]); g.rotation.y = c.ry; scene.add(g);
    const desk = M.buildDesk(1.3, 0.7, i ? '#bf9a72' : '#b48a60'); desk.position.z = 0.62; g.add(desk);
    const chair = M.buildChair(c.chair); chair.position.z = -0.05; g.add(chair);
    const p = M.buildPerson(c.person); M.sitPose(p); g.add(p);
    const lap = M.buildLaptop(i ? '#fff8e6' : '#e9f2ff'); lap.position.set(0, 0.75, 0.5); lap.rotation.y = Math.PI; g.add(lap);
    // личные вещи
    if (i === 0) {
      [0, 1, 2].forEach((k) => { const can = M.cyl(0.03, 0.03, 0.12, M.mat(k === 1 ? '#111' : '#2ecc40', { metalness: 0.6, roughness: 0.3 })); can.position.set(0.42 + k * 0.07, 0.81, 0.7 - k * 0.04); g.add(can); });
      const duck = new THREE.Group(); duck.position.set(-0.45, 0.75, 0.72); g.add(duck);
      const db = M.sph(0.05, M.mat('#ffd600')); db.scale.set(1, 0.8, 1.2); db.position.y = 0.04; duck.add(db);
      const dh = M.sph(0.032, M.mat('#ffd600')); dh.position.set(0, 0.1, -0.035); duck.add(dh);
      const beak = M.box(0.03, 0.012, 0.03, M.mat('#ff8f00')); beak.position.set(0, 0.095, -0.07); duck.add(beak);
    } else {
      const pot = M.cyl(0.04, 0.035, 0.06, M.mat('#c1653b')); pot.position.set(-0.45, 0.78, 0.72); g.add(pot);
      const cac = M.cap(0.025, 0.08, M.mat('#43a047')); cac.position.set(-0.45, 0.87, 0.72); g.add(cac);
      for (let k = 0; k < 5; k++) { const pp = M.box(0.21, 0.006, 0.29, M.mat('#fafafa')); pp.position.set(0.42, 0.753 + k * 0.007, 0.65); pp.rotation.y = k * 0.1; g.add(pp); }
      const frame = M.box(0.12, 0.15, 0.01, M.mat('#6d4c41')); frame.position.set(-0.25, 0.83, 0.85); frame.rotation.x = -0.2; g.add(frame);
    }
    // награды по уровню
    const trophy = new THREE.Group(); trophy.position.set(0.25, 0.75, 0.82); g.add(trophy);
    const tb = M.box(0.06, 0.02, 0.06, M.mat('#333')); tb.position.y = 0.01; trophy.add(tb);
    const tc = M.cyl(0.035, 0.012, 0.07, M.mat('#f2c230', { metalness: 0.9, roughness: 0.25 })); tc.position.y = 0.06; trophy.add(tc);
    const crown = new THREE.Group(); p.userData.rig.head.add(crown); crown.position.y = 0.27;
    const cr = M.cyl(0.09, 0.08, 0.06, M.mat('#f2c230', { metalness: 0.9, roughness: 0.25 }), 12); crown.add(cr);
    for (let k = 0; k < 6; k++) { const sp = new THREE.Mesh(new THREE.ConeGeometry(0.018, 0.05, 6), cr.material); const a = (k / 6) * Math.PI * 2; sp.position.set(Math.cos(a) * 0.08, 0.05, Math.sin(a) * 0.08); crown.add(sp); }
    const monitorX = M.buildSecondMonitor(1); monitorX.scale.setScalar(0.8); monitorX.position.set(0.42, 0.75, 0.82); monitorX.rotation.y = Math.PI - 0.4; g.add(monitorX);
    tag(g, 'w' + i);
    H.workers.push({ g, person: p, rig: p.userData.rig, trophy, crown, monitorX, celebrate: 0, phase: Math.random() * 10 });
  });
}

function updateWorkerProps() {
  H.workers.forEach((w, i) => {
    const lvl = S.workers[i].lvl;
    w.monitorX.visible = lvl >= 4;
    w.trophy.visible = lvl >= 7;
    w.crown.visible = lvl >= 10;
  });
}

function animateWorkers(dt) {
  H.workers.forEach((w, i) => {
    const r = w.rig, mood = S.workers[i].mood, t = time + w.phase;
    let mode = mood < 25 ? (i === 0 ? 'sleep' : 'phone') : 'work';
    if (w.celebrate > 0) { w.celebrate -= dt; mode = 'cheer'; }
    w.mode = mode;
    const L = (o, k, v) => { o[k] += (v - o[k]) * Math.min(1, dt * 8); };
    if (mode === 'work') {
      L(r.spine.rotation, 'x', 0.05); L(r.head.rotation, 'x', 0.12);
      r.head.rotation.y = Math.sin(t * 0.4) * 0.15 + (Math.sin(t * 0.13) > 0.93 ? 0.8 : 0);
      r.shoulders.forEach((s, k) => { L(s.rotation, 'x', -0.45); L(s.rotation, 'z', 0); });
      r.elbows.forEach((e, k) => { e.rotation.x = -1.1 + Math.sin(t * 13 + k * Math.PI) * 0.07; L(e.rotation, 'z', 0); });
    } else if (mode === 'sleep') {
      L(r.spine.rotation, 'x', 0.45); L(r.head.rotation, 'x', 0.5); L(r.head.rotation, 'y', 0.3);
      r.shoulders.forEach((s) => { L(s.rotation, 'x', -1.1); L(s.rotation, 'z', 0); });
      r.elbows.forEach((e, k) => { L(e.rotation, 'x', -1.2); L(e.rotation, 'z', k ? 0.9 : -0.9); });
      r.spine.position.y = 0.04 + Math.sin(t * 1.5) * 0.004;
    } else if (mode === 'phone') {
      L(r.spine.rotation, 'x', -0.08); L(r.head.rotation, 'x', 0); r.head.rotation.z = 0.15 + Math.sin(t * 2) * 0.05;
      L(r.shoulders[1].rotation, 'z', 2.5); L(r.shoulders[1].rotation, 'x', 0); L(r.elbows[1].rotation, 'z', 2.2); L(r.elbows[1].rotation, 'x', 0);
      L(r.shoulders[0].rotation, 'x', -0.45); r.elbows[0].rotation.x = -1.1 + Math.sin(t * 3) * 0.2;
    } else {
      L(r.spine.rotation, 'x', -0.1); L(r.head.rotation, 'x', -0.2);
      r.shoulders.forEach((s, k) => { L(s.rotation, 'z', k ? 2.7 : -2.7); L(s.rotation, 'x', 0); });
      r.elbows.forEach((e) => { e.rotation.x = Math.sin(time * 14) * 0.4; L(e.rotation, 'z', 0); });
    }
    if (mode !== 'phone') r.head.rotation.z *= 0.9;
  });
}

// ---------- официант ----------
function buildWaiter() {
  const p = M.buildPerson({ shirt: '#ffffff', vest: '#1b1b1f', pants: '#1b1b1f', hair: '#1a1a1a', hairType: 'slick', bowtie: true, skin: '#e8b892' });
  p.position.set(-4.2, 0, -1.475);
  scene.add(p); tag(p, 'waiter');
  const tray = new THREE.Group(); tray.position.set(0.24, 1.08, 0.3); p.add(tray);
  const tm = M.cyl(0.17, 0.17, 0.012, M.mat('#c0c4c8', { metalness: 0.9, roughness: 0.25 }), 28); tray.add(tm);
  const cup = new THREE.Group(); tray.add(cup);
  const cc = M.cyl(0.035, 0.03, 0.07, M.mat('#fff', { roughness: 0.3 })); cc.position.y = 0.04; cup.add(cc);
  const sauce = M.cyl(0.06, 0.06, 0.006, M.mat('#fff')); sauce.position.y = 0.008; cup.add(sauce);
  const r = p.userData.rig;
  r.shoulders[1].rotation.x = -0.35; r.elbows[1].rotation.x = -1.35;
  H.waiter = { p, rig: r, tray, cup, path: [], state: 'idle', wait: 0, phase: 0, target: null };
}

function startWaiter(target, item) {
  const w = H.waiter;
  const D0 = [-4.2, -1.475], D1 = [-2.75, -1.475], A = [-1.0, -1.38];
  let stops;
  if (target === 'me') stops = [[...D0], [...D1], [...A], { at: [0.72, -0.98], face: 0, serve: 'me' }, [...A], [...D1], [...D0]];
  else stops = [[...D0], [...D1], [...A], { at: [-0.98, -0.5], face: -Math.PI / 2, serve: 'w0' }, [0, -1.15], [1.0, -1.15], { at: [1.0, -0.6], face: Math.PI / 2, serve: 'w1' }, [1.0, -1.15], [...A], [...D1], [...D0]];
  w.path = stops.map((s) => (Array.isArray(s) ? { at: s } : s));
  w.path.shift();
  w.p.position.set(D0[0], 0, D0[1]);
  w.state = 'walk'; w.target = target; w.item = item; w.cup.visible = true; w.served = 0;
}

function animateWaiter(dt) {
  const w = H.waiter, r = w.rig, p = w.p;
  if (w.state === 'idle') { p.visible = false; return; }
  p.visible = true;
  if (w.state === 'serve') {
    w.wait -= dt;
    const k = Math.sin(Math.min(1, 1 - w.wait / 1.6) * Math.PI);
    r.shoulders[0].rotation.x = -k * 1.3; r.elbows[0].rotation.x = -k * 0.3;
    r.legs.forEach((l) => { l.rotation.x *= 0.8; }); r.knees.forEach((kn) => { kn.rotation.x *= 0.8; });
    if (w.wait <= 0.8 && !w.didServe) {
      w.didServe = true;
      if (w.cur.serve === 'me') { w.cup.visible = false; G.waiterArrived('me', w.item); }
      else if (++w.served === 2) { w.cup.visible = false; G.waiterArrived('workers'); }
    }
    if (w.wait <= 0) { w.state = 'walk'; r.shoulders[0].rotation.x = 0; if (w.looked) { w.looked = false; if (camMode === 'free') { tYaw = 0; tPitch = PITCH0; } } }
    return;
  }
  const next = w.path[0];
  if (!next) { w.state = 'idle'; G.waiterDone(); return; }
  const dx = next.at[0] - p.position.x, dz = next.at[1] - p.position.z;
  const d = Math.hypot(dx, dz), sp = 1.35 * dt;
  const ang = Math.atan2(dx, dz);
  let da = ang - p.rotation.y; while (da > Math.PI) da -= Math.PI * 2; while (da < -Math.PI) da += Math.PI * 2;
  p.rotation.y += da * Math.min(1, dt * 10);
  if (d <= sp) {
    p.position.x = next.at[0]; p.position.z = next.at[1];
    w.path.shift();
    if (next.serve) {
      w.state = 'serve'; w.wait = 1.6; w.didServe = false; w.cur = next; p.rotation.y = next.face;
      if (next.serve === 'me' && camMode === 'free' && !G.inOS) { w.looked = true; tYaw = -Math.atan2(next.at[0] - HOME.x, HOME.z - next.at[1]); tPitch = -0.08; }
    }
  } else {
    p.position.x += (dx / d) * sp; p.position.z += (dz / d) * sp;
  }
  w.phase += dt * 8.5;
  r.legs.forEach((l, k) => { l.rotation.x = Math.sin(w.phase + k * Math.PI) * 0.45; });
  r.knees.forEach((kn, k) => { kn.rotation.x = Math.max(0, -Math.sin(w.phase + k * Math.PI)) * 0.7; });
  r.shoulders[0].rotation.x = Math.sin(w.phase) * 0.35;
  r.hips.position.y = 0.92 + Math.abs(Math.sin(w.phase)) * 0.02;
}

// ---------- камера и касания ----------
function lookDir(y, p) { return new THREE.Vector3(-Math.sin(y) * Math.cos(p), Math.sin(p), -Math.cos(y) * Math.cos(p)); }

function updateCamera(dt) {
  if (camMode === 'free') {
    yaw += (tYaw - yaw) * Math.min(1, dt * 10 || 1);
    pitch += (tPitch - pitch) * Math.min(1, dt * 10 || 1);
    camera.position.copy(HOME);
    camera.lookAt(HOME.clone().add(lookDir(yaw, pitch)));
  } else if (camMode === 'tween' && tween) {
    tween.t += dt / tween.dur;
    const k = tween.t >= 1 ? 1 : 0.5 - Math.cos(tween.t * Math.PI) / 2;
    camera.position.lerpVectors(tween.from, tween.to, k);
    camera.lookAt(new THREE.Vector3().lerpVectors(tween.fromLook, tween.toLook, k));
    if (tween.t >= 1) { const cb = tween.cb; camMode = tween.end; tween = null; if (cb) cb(); }
  }
}

function setupInput(el) {
  let down = null;
  el.addEventListener('pointerdown', (e) => {
    if (!Scene.inputEnabled || camMode !== 'free') return;
    if (down) { down.multi = true; return; }
    down = { id: e.pointerId, x: e.clientX, y: e.clientY, t: performance.now(), yaw: tYaw, pitch: tPitch, moved: 0 };
  });
  el.addEventListener('pointermove', (e) => {
    if (!down || e.pointerId !== down.id) return;
    const dx = e.clientX - down.x, dy = e.clientY - down.y;
    down.moved = Math.max(down.moved, Math.hypot(dx, dy));
    if (down.moved > 8) {
      const k = 2.6 / window.innerWidth;
      tYaw = THREE.MathUtils.clamp(down.yaw + dx * k, -1.35, 1.35);
      tPitch = THREE.MathUtils.clamp(down.pitch + dy * k * 0.9, -0.95, 0.35);
    }
  });
  const end = (e) => {
    if (!down || e.pointerId !== down.id) return;
    const tap = down.moved < 12 && performance.now() - down.t < 500 && !down.multi;
    down = null;
    if (tap) doTap(e.clientX, e.clientY);
  };
  el.addEventListener('pointerup', end);
  el.addEventListener('pointercancel', () => { down = null; });
}

const ray = new THREE.Raycaster();
function doTap(x, y) {
  ray.setFromCamera(new THREE.Vector2((x / window.innerWidth) * 2 - 1, -(y / window.innerHeight) * 2 + 1), camera);
  const hits = ray.intersectObjects(interactive, true);
  for (const h of hits) {
    let o = h.object;
    while (o && !o.userData.action) o = o.parent;
    if (o && o.visible !== false) {
      bounce.push({ o, t: 0, s: o.scale.x });
      if (Scene.onTap) Scene.onTap(o.userData.action);
      return;
    }
  }
}

Scene.zoomToPC = function (cb) {
  if (camMode !== 'free') return;
  const s = H.pc.screen;
  const p = new THREE.Vector3(); s.getWorldPosition(p);
  const n = new THREE.Vector3(0, 0, 1).applyQuaternion(s.getWorldQuaternion(new THREE.Quaternion()));
  const hgt = s.geometry.parameters.height, wid = s.geometry.parameters.width;
  const vf = THREE.MathUtils.degToRad(camera.fov / 2);
  const dist = Math.max((hgt / 2) / Math.tan(vf), (wid / 2) / (Math.tan(vf) * camera.aspect)) * 0.98;
  tween = { from: camera.position.clone(), to: p.clone().add(n.multiplyScalar(dist)), fromLook: HOME.clone().add(lookDir(yaw, pitch)), toLook: p, t: 0, dur: 0.55, cb, end: 'pc' };
  camMode = 'tween';
};
Scene.zoomOut = function (cb) {
  if (camMode !== 'pc') { if (cb) cb(); return; }
  const s = H.pc.screen; const p = new THREE.Vector3(); s.getWorldPosition(p);
  tYaw = yaw = 0; tPitch = pitch = PITCH0;
  tween = { from: camera.position.clone(), to: HOME.clone(), fromLook: p, toLook: HOME.clone().add(lookDir(0, PITCH0)), t: 0, dur: 0.5, cb, end: 'free' };
  camMode = 'tween';
  Scene.renderEnabled = true;
};
Scene.lookAt = function (y, p) { tYaw = y; tPitch = p; };

// ---------- проекция якорей для HTML-меток ----------
const _v = new THREE.Vector3();
Scene.anchor = function (name) {
  let o, off = 0;
  if (name === 'pc') { H.pc.screen.getWorldPosition(_v); _v.y += 0.03; return _v; }
  if (name === 'w0' || name === 'w1') { H.workers[+name[1]].rig.head.getWorldPosition(_v); _v.y += 0.42; return _v; }
  if (name === 'phone') { o = H.phone.group; off = 0.16; }
  else if (name === 'mug') { o = H.mug.group; off = 0.17; }
  else if (name === 'bell') { o = H.bell.group; off = 0.12; }
  else if (name === 'fan') { o = H.fan.group; off = 0.45; }
  else if (name === 'plant') { o = H.items && H.items.plant && H.items.plant.group; off = 0.45; }
  else if (name === 'waiter') { o = H.waiter.p; off = 1.95; }
  if (!o) return null;
  o.getWorldPosition(_v); _v.y += off;
  return _v;
};
Scene.project = function (v) {
  const p = v.clone().project(camera);
  const vis = p.z < 1 && p.x > -1.05 && p.x < 1.05 && p.y > -1.05 && p.y < 1.05;
  return { x: (p.x + 1) / 2 * window.innerWidth, y: (1 - p.y) / 2 * window.innerHeight, vis };
};
Scene.waiterVisible = () => H.waiter && H.waiter.state !== 'idle';
Scene.workerMode = (i) => H.workers[i].mode;

// ---------- день/ночь ----------
const KEYS = [
  [0.0, '#7fb2e5', '#dbe9f5', '#fff4e0', 1.5, 0.85, 0.06],
  [0.45, '#5f9ee6', '#cfe5f8', '#fffaf0', 1.7, 0.9, 0.04],
  [0.7, '#6b7fbf', '#f2b880', '#ffc890', 1.2, 0.75, 0.25],
  [0.84, '#2d3570', '#d27a5a', '#ff9a6a', 0.55, 0.6, 0.6],
  [1.0, '#0d1430', '#2a2a55', '#7080b0', 0.25, 0.5, 0.92],
];
const _c1 = new THREE.Color(), _c2 = new THREE.Color();
function dayParams(t) {
  let i = 0; while (i < KEYS.length - 2 && t > KEYS[i + 1][0]) i++;
  const a = KEYS[i], b = KEYS[i + 1], k = THREE.MathUtils.clamp((t - a[0]) / (b[0] - a[0]), 0, 1);
  const col = (j) => '#' + _c1.set(a[j]).lerp(_c2.set(b[j]), k).getHexString();
  return { top: col(1), bottom: col(2), sun: col(3), sunI: a[4] + (b[4] - a[4]) * k, hemiI: a[5] + (b[5] - a[5]) * k, lit: a[6] + (b[6] - a[6]) * k };
}
function drawSky(t) {
  const d = dayParams(t), tex = H.sky, c = tex.userData.ctx, W = 1024, Hh = 512, seed = tex.userData.seed;
  const g = c.createLinearGradient(0, 0, 0, Hh * 0.7); g.addColorStop(0, d.top); g.addColorStop(1, d.bottom);
  c.fillStyle = g; c.fillRect(0, 0, W, Hh);
  // солнце / луна
  const sx = 150 + t * 700, sy = 90 + Math.pow(t, 2) * 230;
  if (t < 0.9) { const sg = c.createRadialGradient(sx, sy, 5, sx, sy, 70); sg.addColorStop(0, 'rgba(255,250,220,0.95)'); sg.addColorStop(0.3, 'rgba(255,230,170,0.5)'); sg.addColorStop(1, 'rgba(255,220,150,0)'); c.fillStyle = sg; c.fillRect(sx - 70, sy - 70, 140, 140); }
  else { c.fillStyle = '#f4f1dc'; c.beginPath(); c.arc(820, 90, 22, 0, Math.PI * 2); c.fill(); for (let i = 0; i < 40; i++) { c.fillStyle = `rgba(255,255,255,${seed[i] * 0.8})`; c.fillRect(seed[i + 100] * W, seed[i + 200] * 200, 2, 2); } }
  // дальний план
  let s = 0;
  const far = _c1.set(d.bottom).lerp(_c2.set('#2a3550'), 0.55).getStyle();
  c.fillStyle = far;
  for (let x = 0; x < W; ) { const w = 30 + seed[s++ % 900] * 50, h = 60 + seed[s++ % 900] * 120; c.fillRect(x, 330 - h, w, h + 200); x += w + 2; }
  // ближний план
  const near = _c1.set('#1f2635').lerp(_c2.set(d.bottom), 0.15).getStyle();
  let x = -20, bi = 0;
  while (x < W) {
    const w = 60 + seed[s++ % 900] * 90, h = 120 + seed[s++ % 900] * 200, y = 512 - h;
    const hq = bi === 6;
    const hh = hq ? 330 : h, yy = 512 - hh;
    c.fillStyle = near; c.fillRect(x, yy, w, hh);
    c.fillStyle = 'rgba(255,255,255,0.85)'; c.fillRect(x, yy - 3, w, 4);
    for (let wy = yy + 12; wy < 505; wy += 16) for (let wx = x + 7; wx < x + w - 10; wx += 13) {
      const r = seed[(wx * 7 + wy * 13) % 900];
      c.fillStyle = r < d.lit ? (r < d.lit * 0.3 ? '#ffe9b0' : '#ffd27a') : `rgba(140,170,210,${0.15 + (1 - d.lit) * 0.15})`;
      c.fillRect(wx, wy, 7, 9);
    }
    if (hq) {
      c.fillStyle = d.lit > 0.3 ? '#b388ff' : '#7e57c2'; c.font = 'bold 26px sans-serif'; c.textAlign = 'center';
      'СПЕРМ'.split('').forEach((ch, k) => c.fillText(ch, x + w / 2, yy + 40 + k * 30)); c.textAlign = 'left';
    }
    x += w + 6; bi++;
  }
  tex.needsUpdate = true;
  return d;
}

function updateDaylight() {
  const t = S.minute / DAY_LEN;
  const key = Math.floor(S.minute / 8);
  const d = dayParams(t);
  sun.color.set(d.sun); sun.intensity = d.sunI; hemi.intensity = d.hemiI;
  if (key !== lastSkyKey) { lastSkyKey = key; drawSky(t); }
}

// ---------- кадр ----------
Scene.updateScreen = function (force) {
  const os = PCS[S.pc].os;
  const slot = Math.floor(S.minute / 5);
  const W = H.screenTex.userData.canvas.width, Hh = H.screenTex.userData.canvas.height;
  const info = { waiting: G.inOS ? 0 : CM.waitingCount(), clock: clockStr(slot * 5), bsod: G.bsodShow, off: G.pcOff,
    cx: W * (0.35 + ((slot * 37) % 40) / 100), cy: Hh * (0.25 + ((slot * 53) % 40) / 100) };
  const key = `${os}|${info.waiting}|${info.clock}|${info.bsod}|${info.off}`;
  if (force || key !== lastScreenKey) { lastScreenKey = key; M.drawScreen(H.screenTex, os, info); }
};

let screenT = 0;
Scene.frame = function (dt) {
  time += dt;
  updateCamera(dt);
  // вентилятор
  if (H.fan) {
    const on = S.fanOn && !S.fanStalled;
    const target = on ? (H.fan.tier ? 30 : 20) : 0;
    H.fan.speed += (target - H.fan.speed) * Math.min(1, dt * (on ? 1.5 : 0.8));
    H.fan.blades.rotation.z += H.fan.speed * dt;
    if (on) H.fan.group.rotation.y = H.fan.baseYaw + Math.sin(time * 0.7) * 0.45;
    if (S.fanStalled) H.fan.head.rotation.z = Math.sin(time * 30) * 0.01;
  }
  if (H.ac) { const tgt = S.fanOn ? 0.7 : 0; H.ac.flap.rotation.x += (tgt - H.ac.flap.rotation.x) * dt * 2; H.ac.led.material.emissiveIntensity = S.fanOn ? 2 : 0.2; }
  // телефон
  if (H.phone) {
    const ringing = G.phone && !G.phone.answered;
    const burst = ringing && (time % 2.2) < 1.2;
    H.phone.handset.position.y = 0.075 + (burst ? Math.abs(Math.sin(time * 45)) * 0.012 : 0);
    H.phone.group.rotation.z = burst ? Math.sin(time * 60) * 0.02 : 0;
    H.phone.light.emissiveIntensity = ringing ? (Math.sin(time * 12) > 0 ? 3 : 0.2) : 0.2;
  }
  // кружка
  if (H.mug) {
    const full = !!G.mug;
    H.mug.coffee.visible = full;
    H.mug.steam.forEach((s) => {
      const ph = (time * 0.5 + s.userData.ph) % 1;
      s.position.set(Math.sin((ph + s.userData.ph) * 6) * 0.01, 0.1 + ph * 0.12, 0);
      s.material.opacity = full ? Math.sin(ph * Math.PI) * 0.6 : 0;
      s.scale.setScalar(0.04 + ph * 0.05);
    });
  }
  // роутер
  if (H.router) {
    const out = online.outage > 0;
    H.router.leds.forEach((m, i) => {
      if (out) { m.emissive.set('#f22'); m.emissiveIntensity = Math.sin(time * 6) > 0 ? 2.5 : 0.3; }
      else { m.emissive.set(H.router.tier === 4 ? '#3ff' : '#3f3'); m.emissiveIntensity = (i === 0 || Math.sin(time * (8 + i * 3 + S.net * 4) + i) > 0) ? 2 : 0.25; }
    });
  }
  // эффекты ПК
  if (H.pc) {
    H.pc.fx.spin.forEach((o) => { o.rotation.z += dt * 9; o.rotation.y += o.children.length > 3 ? 0 : dt * 0.8; });
    const hue = (time * 0.12) % 1;
    H.pc.fx.rgb.forEach((m, i) => m.emissive.setHSL((hue + i * 0.12) % 1, 1, 0.5));
    if (H.pc.fx.rgbLight) H.pc.fx.rgbLight.color.setHSL(hue, 1, 0.5);
    H.pc.fx.holo.forEach((o) => { if (o.material) o.material.opacity = 0.7 + Math.sin(time * 3) * 0.2; });
    if (H.pc.fx.led) H.pc.fx.led.material.emissiveIntensity = G.inOS && Math.random() < 0.4 ? 3 : 0.1;
  }
  if (H.kb && H.kb.userData.top && has('keyboard')) H.kb.userData.top.emissive.setHSL((time * 0.1) % 1, 0.6, 0.6);
  // предметы
  const it = H.items || {};
  if (it.cat) it.cat.paw.rotation.x = -0.6 + Math.sin(time * 4) * 0.5;
  if (it.lamp) {
    const evening = S.minute / DAY_LEN;
    const on = S.lampOn;
    it.lamp.bulb.material.emissiveIntensity = on ? 2.2 : 0;
    it.lamp.light.intensity = on ? 0.5 + evening * 1.2 : 0;
  }
  if (it.tree) { it.tree.balls.forEach((m, i) => { m.emissiveIntensity = 0.4 + Math.abs(Math.sin(time * 1.8 + i * 1.3)) * 1.8; }); it.tree.star.rotation.y += dt; }
  if (it.plant) {
    const dry = S.plantDay !== S.day;
    const tgt = dry ? 0.82 : 1;
    it.plant.leaves.scale.y += (tgt - it.plant.leaves.scale.y) * dt * 2;
    it.plant.leaves.rotation.z = dry ? 0.05 : Math.sin(time * 0.8) * 0.02;
  }
  // снег
  const pa = H.snow.geometry.attributes.position;
  for (let i = 0; i < pa.count; i++) {
    let y = pa.getY(i) - (0.35 + (i % 7) * 0.06) * dt;
    if (y < -3) y = 6;
    pa.setY(i, y); pa.setX(i, pa.getX(i) + Math.sin(time + i) * 0.08 * dt);
  }
  pa.needsUpdate = true;
  // часы
  const m = 9 * 60 + S.minute;
  H.minHand.rotation.z = -((m % 60) / 60) * Math.PI * 2;
  H.hourHand.rotation.z = -(((m / 60) % 12) / 12) * Math.PI * 2;
  // дверь
  const wd = H.waiter.p.visible ? Math.hypot(H.waiter.p.position.x + 3.3, H.waiter.p.position.z + 1.475) : 9;
  const dtg = wd < 1.3 ? 1.45 : 0;
  H.door.rotation.y += (dtg - H.door.rotation.y) * Math.min(1, dt * 5);
  // анимации
  animateWorkers(dt);
  animateWaiter(dt);
  bounce = bounce.filter((b) => {
    b.t += dt;
    const k = b.t < 0.25 ? 1 + Math.sin((b.t / 0.25) * Math.PI) * 0.08 : 1;
    b.o.scale.setScalar(b.s * k);
    return b.t < 0.25;
  });
  updateDaylight();
  screenT += dt;
  if (screenT > 0.5) { screenT = 0; Scene.updateScreen(); }
  if (Scene.renderEnabled) renderer.render(scene, camera);
};

Scene.start = function (loop) { renderer.setAnimationLoop(loop); };
