// ===== Симуляция: время, бодрость, температура ПК, коллеги, звонки, события, цели =====
import { S, bus, save, rand, pick, clamp, has, net, rankIdx, rank, addMoney, addRep, spend, online, clockStr, fmt } from './state.js';
import { PCS, NETS, FANS, ITEMS, WORKERS, COFFEE, CALLS, GOALS, ACH, RANKS, TREAT_PRICE, workerCost, MAX_WORKER_LVL } from './data.js';
import { CM } from './clients.js';
import { sfx, vibrate, setFanHum } from './audio.js';

export const MIN_PER_SEC = 1.15; // игровых минут в реальную секунду (рабочий день ≈ 8 минут)
export const DAY_LEN = 540;

function toast(t, type) { bus.emit('toast', t, type); }

export const G = {
  inOS: false,
  osBusy: false,
  remoteActive: false,
  paused: false,
  dayEnding: false,
  asleep: 0,
  phone: null,
  phoneT: 55,
  outageT: 50,
  stallT: rand(80, 140),
  workerAcc: [0, 0],
  workerPopT: 0,
  saveT: 0,
  tickT: 0,
  achT: 0,
  heatWarned: false,
  energyWarned: false,
  waiterBusy: false,
  mug: null, // id напитка в кружке

  start() {
    if (!S.goals || !S.goals.length) this.newGoals();
    if (!S.emails.length) this.welcomeEmail();
    setFanHum(S.fanOn && !S.fanStalled ? (S.fan + 1) * 0.6 : 0);
  },

  update(dt) {
    if (this.paused || this.dayEnding) return;
    if (this.asleep > 0) {
      this.asleep -= dt;
      if (this.asleep <= 0) bus.emit('wake');
      return;
    }
    // ---- время ----
    S.minute += dt * MIN_PER_SEC;
    if (S.minute >= DAY_LEN) { S.minute = DAY_LEN; this.endDay(); return; }

    // ---- бодрость ----
    const drain = (this.inOS ? 0.1 : 0.04) * (has('lamp') ? 0.8 : 1);
    S.energy = clamp(S.energy - drain * dt, 0, 100);
    if (S.energy < 20 && !this.energyWarned) { this.energyWarned = true; toast('😴 Бодрость на исходе! Закажи кофе у официанта (колокольчик на столе)', 'warn'); }
    if (S.energy > 30) this.energyWarned = false;
    if (S.energy <= 0) this.fallAsleep();

    // ---- температура ПК ----
    let h = -0.15;
    if (this.inOS && !this.osBusy) h += PCS[S.pc].heat * (this.remoteActive ? 1.5 : 1);
    else h -= 0.6;
    const fanWorks = S.fanOn && !S.fanStalled;
    if (fanWorks) h -= FANS[S.fan].cool;
    S.heat = clamp(S.heat + h * dt, 30, 100);
    if (S.heat > 85 && !this.heatWarned) { this.heatWarned = true; toast('🌡 Компьютер перегревается! Включи вентилятор', 'warn'); sfx.error(); }
    if (S.heat < 75) this.heatWarned = false;
    if (S.heat >= 100 && this.inOS && !this.osBusy) {
      S.heat = 72; S.stats.bsod++;
      bus.emit('bsod');
    }

    // ---- капризный вентилятор ----
    if (S.fanOn && !S.fanStalled && FANS[S.fan].flaky) {
      this.stallT -= dt;
      if (this.stallT <= 0) {
        S.fanStalled = true; this.stallT = rand(80, 150);
        setFanHum(0);
        toast('🌀 «Ветерок» заглох! Постучи по нему (нажми на вентилятор)', 'warn');
        bus.emit('fan');
      }
    }

    // ---- коллеги ----
    this.workerPopT += dt;
    S.workers.forEach((w, i) => {
      w.mood = clamp(w.mood - 0.055 * (has('tree') ? 0.5 : 1) * dt, 0, 100);
      const inc = WORKERS[i].base * w.lvl * (0.4 + 0.6 * w.mood / 100) * MIN_PER_SEC;
      this.workerAcc[i] += inc * dt;
    });
    if (this.workerPopT >= 9) {
      this.workerPopT = 0;
      this.workerAcc.forEach((a, i) => {
        const n = Math.floor(a);
        if (n > 0) { addMoney(n, 'worker'); this.workerAcc[i] -= n; bus.emit('workerIncome', i, n); }
      });
    }

    // ---- телефон ----
    if (!this.phone) {
      this.phoneT -= dt;
      if (this.phoneT <= 0 && S.minute < 515) this.ring();
    } else if (!this.phone.answered) {
      this.phone.t -= dt;
      this.phone.ringT -= dt;
      if (this.phone.ringT <= 0) { this.phone.ringT = 2.2; sfx.ring(); vibrate(200); }
      if (this.phone.t <= 0) {
        this.phone = null; this.phoneT = rand(70, 130);
        toast('📵 Пропущенный звонок', 'info');
        bus.emit('phone', false);
      }
    }

    // ---- обрывы интернета ----
    if (online.outage > 0) {
      online.outage -= dt;
      if (online.outage <= 0) { online.outage = 0; toast('📶 Интернет вернулся!', 'good'); bus.emit('net'); }
    } else {
      this.outageT -= dt;
      if (this.outageT <= 0) {
        this.outageT = 60;
        if (Math.random() < NETS[S.net].outage * 0.3) {
          online.outage = rand(12, 25);
          toast('❌ Интернет пропал! Провайдер «ДыркаНет» приносит извинения', 'bad');
          sfx.error(); bus.emit('net');
        }
      }
    }

    // ---- клиенты ----
    CM.update(dt, false);

    // ---- цели, достижения, сохранение ----
    this.achT += dt;
    if (this.achT > 1) { this.achT = 0; this.checkGoals(); this.checkAch(); }
    this.saveT += dt;
    if (this.saveT > 6) { this.saveT = 0; save(); }
    this.tickT += dt;
    if (this.tickT > 0.25) { this.tickT = 0; bus.emit('tick'); }
  },

  fallAsleep() {
    this.asleep = 4;
    S.minute = Math.min(DAY_LEN - 5, S.minute + 45);
    S.energy = 35;
    bus.emit('asleep');
  },

  // ---------- вентилятор / лампа / фикус ----------
  toggleFan() {
    if (S.fanStalled) {
      S.fanStalled = false; S.fanOn = true;
      sfx.knock();
      toast('👊 Бам! «Ветерок» снова крутится', 'good');
    } else {
      S.fanOn = !S.fanOn;
      sfx.click();
      if (S.fanOn) toast(`🌀 ${FANS[S.fan].name}: включён`, 'info');
    }
    setFanHum(S.fanOn && !S.fanStalled ? (S.fan + 1) * 0.6 : 0);
    bus.emit('fan');
  },
  toggleLamp() {
    if (!has('lamp')) return;
    S.lampOn = !S.lampOn; sfx.click(); bus.emit('lamp');
  },
  waterPlant() {
    if (!has('plant')) return;
    if (S.plantDay === S.day) { toast('🪴 Геннадий уже полит сегодня. Не утопи его!', 'info'); return; }
    S.plantDay = S.day; sfx.water();
    toast('💧 Геннадий доволен! +10% к репутации до конца дня', 'good');
    bus.emit('plant');
  },

  // ---------- кофе и официант ----------
  orderCoffee(itemId, forWorkers = false) {
    if (this.waiterBusy) { toast('🤵 Официант Жорик уже несёт заказ, подожди', 'info'); return false; }
    if (!forWorkers && this.mug && itemId !== 'donut') { toast('☕ В кружке ещё есть кофе — сначала выпей его (нажми на кружку)', 'info'); return false; }
    const price = forWorkers ? TREAT_PRICE : COFFEE.find((c) => c.id === itemId).price;
    if (!spend(price)) { toast('💸 Не хватает денег', 'bad'); sfx.error(); return false; }
    this.waiterBusy = true;
    sfx.ding();
    toast(forWorkers ? '🤵 Жорик несёт кофе коллегам' : '🤵 Жорик принял заказ и уже идёт', 'info');
    bus.emit('waiter', { target: forWorkers ? 'workers' : 'me', item: itemId });
    return true;
  },
  waiterArrived(target, itemId) {
    if (target === 'workers') {
      S.workers.forEach((w) => { w.mood = clamp(w.mood + 45, 0, 100); });
      toast('😊 Коллеги довольны и работают бодрее!', 'good');
      sfx.success();
      bus.emit('workers');
    } else if (itemId === 'donut') {
      const it = COFFEE.find((c) => c.id === 'donut');
      S.energy = clamp(S.energy + it.energy, 0, 100); addRep(it.rep || 0);
      toast('🍩 Ням! Пончик съеден (+15 бодрости)', 'good'); sfx.slurp();
    } else {
      this.mug = itemId;
      toast('☕ Кофе подан! Нажми на кружку, чтобы выпить', 'good');
      bus.emit('mug');
    }
  },
  waiterDone() { this.waiterBusy = false; },
  drink() {
    if (!this.mug) { toast('☕ Кружка пуста. Нажми на колокольчик, чтобы позвать официанта', 'info'); return; }
    const it = COFFEE.find((c) => c.id === this.mug);
    S.energy = clamp(S.energy + it.energy, 0, 100);
    S.stats.coffee++; S.dayStats.coffee++;
    this.mug = null;
    sfx.slurp();
    toast(`${it.icon} ${it.name}: +${it.energy} бодрости`, 'good');
    bus.emit('mug');
  },

  // ---------- коллеги ----------
  upgradeWorker(i) {
    const w = S.workers[i];
    if (w.lvl >= MAX_WORKER_LVL) return;
    const cost = workerCost(w.lvl);
    if (!spend(cost)) { toast('💸 Не хватает денег', 'bad'); sfx.error(); return; }
    w.lvl++; w.mood = clamp(w.mood + 15, 0, 100);
    sfx.levelup();
    const perk = WORKERS[i].perks.find((p) => p.lvl === w.lvl);
    toast(`🎓 ${WORKERS[i].name} — уровень ${w.lvl}!` + (perk ? ` Новый навык: ${perk.text}` : ''), 'good');
    bus.emit('workers'); bus.emit('workerLevel', i);
    save();
  },

  // ---------- магазин ----------
  buy(kind, idx) {
    const tables = { pc: PCS, net: NETS, fan: FANS };
    if (kind === 'item') {
      const it = ITEMS.find((x) => x.id === idx);
      if (!it || has(it.id)) return false;
      if (!spend(it.price)) { toast('💸 Не хватает денег', 'bad'); sfx.error(); return false; }
      S.items[it.id] = true;
      if (it.id === 'plant') S.plantDay = S.day;
      if (it.id === 'lamp') S.lampOn = true;
      sfx.cash(); toast(`📦 Куплено: ${it.name}. Уже на столе!`, 'good');
      bus.emit('items'); save();
      return true;
    }
    const t = tables[kind];
    if (idx !== S[kind] + 1 || !t[idx]) return false;
    if (!spend(t[idx].price)) { toast('💸 Не хватает денег', 'bad'); sfx.error(); return false; }
    S[kind] = idx;
    sfx.cash();
    if (kind === 'fan') { setFanHum(S.fanOn ? (S.fan + 1) * 0.6 : 0); S.fanStalled = false; }
    toast(`📦 Куплено: ${t[idx].name}!`, 'good');
    bus.emit(kind); save();
    return true;
  },

  // ---------- телефон ----------
  ring() {
    const weights = { scam: 3, client: 4, boss: 2, mom: 1.5, pizza: 1.5, cb: rankIdx() >= 1 ? 1.5 : 0 };
    const pool = [];
    CALLS.forEach((c) => { const w = weights[c.id] || 1; for (let i = 0; i < w * 2; i++) pool.push(c); });
    const call = pick(pool);
    this.phone = { call, t: 16, ringT: 0, answered: false };
    bus.emit('phone', true);
  },
  answerPhone() {
    if (!this.phone || this.phone.answered) return null;
    this.phone.answered = true;
    sfx.click();
    bus.emit('phone', false);
    return this.phone.call;
  },
  phoneChoice(opt) {
    if (opt.money) {
      if (opt.money > 0) addMoney(opt.money, 'call');
      else { S.money = Math.max(0, S.money + opt.money); bus.emit('money', opt.money); }
    }
    if (opt.rep) addRep(opt.rep);
    if (opt.energy) S.energy = clamp(S.energy + opt.energy, 0, 100);
    if (opt.scam) this.unlock('scam');
    if (opt.spawnRemote) CM.forceRemoteClient();
    S.stats.calls++; S.dayStats.calls++;
    this.phone = null; this.phoneT = rand(70, 140);
  },

  // ---------- день ----------
  endDay() {
    this.dayEnding = true;
    CM.clearAll();
    bus.emit('dayEnd');
    save();
  },
  newDay() {
    S.day++;
    S.minute = 0;
    S.energy = 100;
    S.heat = 38;
    S.dayStats = { clients: 0, remotes: 0, tasks: 0, earned: 0, coffee: 0, calls: 0 };
    this.mug = null;
    CM.spawnT = 4;
    this.newGoals();
    this.dayEnding = false;
    bus.emit('newDay');
    save();
  },
  newGoals() {
    const m = rank().mult;
    const pool = GOALS.slice().sort(() => Math.random() - 0.5);
    // всегда есть цель по клиентам
    const chosen = [GOALS[0], ...pool.filter((g) => g.id !== 'clients').slice(0, 2)];
    S.goals = chosen.map((g) => {
      const n = g.n(S.day, m);
      return { id: g.id, stat: g.stat, n, text: g.text(n), reward: Math.round(180 * m * (1 + S.day * 0.08) / 10) * 10, done: false, claimed: false };
    });
    this.email('Аркадий Борисович', `Задачи на день ${S.day}`,
      'Коллега, доброе утро!\n\nВот задачи на сегодня. За каждую выполненную — премия. Забирай её здесь же, во вкладке «Цели дня».\n\nНе подведи. Кофе — за свой счёт.\n\n— А.Б., начальник отдела быстрой бухгалтерии');
  },
  checkGoals() {
    let changed = false;
    (S.goals || []).forEach((g) => {
      if (!g.done && (S.dayStats[g.stat] || 0) >= g.n) {
        g.done = true; changed = true;
        toast(`🎯 Цель выполнена: ${g.text}. Забери премию в «Почте»!`, 'good');
        sfx.success();
      }
    });
    if (changed) bus.emit('goals');
  },
  claimGoal(i) {
    const g = S.goals[i];
    if (!g || !g.done || g.claimed) return;
    g.claimed = true;
    addMoney(g.reward, 'bonus');
    sfx.cash();
    bus.emit('goals');
    save();
  },

  // ---------- почта ----------
  email(from, subj, body) {
    S.emails.unshift({ id: Date.now() + Math.random(), from, subj, body, read: false, when: `День ${S.day}, ${clockStr()}` });
    if (S.emails.length > 25) S.emails.length = 25;
    bus.emit('mail');
  },
  welcomeEmail() {
    this.email('Отдел кадров СПЕРМбанка', 'Добро пожаловать в команду!',
      'Поздравляем! Вы приняты в отдел быстрой бухгалтерии СПЕРМбанка.\n\n' +
      'Ваши задачи:\n• переписываться с клиентами в «СПЕРМ.Чате» и выставлять счета за обслуживание;\n' +
      '• помогать клиентам удалённо через «ДальнийСтол»;\n• решать бухгалтерские задачки на скорость;\n' +
      '• прокачивать коллег Валеру и Светлану Петровну, а также своё рабочее место в «СПЕРМ.Маркете».\n\n' +
      'Компьютер у вас пока… исторический. Интернет — через модем. Всё улучшается за деньги.\n\n' +
      'Не забывайте включать вентилятор и пить кофе (колокольчик на столе зовёт официанта Жорика).\n\nУдачи!');
  },

  // ---------- достижения ----------
  unlock(id) {
    if (S.ach[id]) return;
    S.ach[id] = true;
    const a = ACH.find((x) => x.id === id);
    if (a) { bus.emit('ach', a); sfx.levelup(); }
  },
  checkAch() {
    const st = S.stats;
    const c = (cond, id) => { if (cond) this.unlock(id); };
    c(st.clients >= 1, 'first'); c(st.clients >= 10, 'c10'); c(st.clients >= 50, 'c50'); c(st.clients >= 200, 'c200');
    c(st.remotes >= 1, 'remote1'); c(st.remotes >= 20, 'remote20'); c(st.coffee >= 10, 'coffee10');
    c(st.bsod >= 1, 'bsod'); c(S.pc >= 1, 'pc2'); c(S.net >= 2, 'fiber'); c(S.pc >= 4, 'quantum');
    c(st.earned >= 1e6, 'rich'); c(rankIdx() >= 4, 'chief');
    c(S.workers[0].lvl >= 5 && S.workers[1].lvl >= 5, 'team');
  },
};

bus.on('rankup', (r) => {
  G.email('Аркадий Борисович', `Повышение: ${RANKS[r].name}!`,
    `Поздравляю с повышением до должности «${RANKS[r].name}»!\n\nТеперь клиенты платят ×${RANKS[r].mult} от базового тарифа. ` +
    (r === 1 ? 'К тебе начнут приходить клиенты посерьёзнее.' : r === 3 ? 'Теперь тебе доверяют VIP-клиентов. Не опозорь отдел.' : 'Так держать!'));
});
